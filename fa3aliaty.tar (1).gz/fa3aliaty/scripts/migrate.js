const fs = require('fs').promises;
const path = require('path');
const { executeQuery, testConnection } = require('../config/database');

async function runMigrations() {
  try {
    console.log('🔄 Starting database migration...');

    // Test database connection
    const isConnected = await testConnection();
    if (!isConnected) {
      console.error('❌ Database connection failed. Please check your configuration.');
      process.exit(1);
    }

    // Read and execute schema.sql
    const schemaPath = path.join(__dirname, '../database/schema.sql');
    const schemaSQL = await fs.readFile(schemaPath, 'utf8');

    // Split SQL statements (simple split by semicolon)
    const statements = schemaSQL
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));

    console.log(`📝 Executing ${statements.length} SQL statements...`);

    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i];
      try {
        await executeQuery(statement);
        console.log(`✅ Statement ${i + 1}/${statements.length} executed successfully`);
      } catch (error) {
        // Some statements might fail if tables already exist, that's okay
        if (error.code === 'ER_TABLE_EXISTS_ERROR' || error.code === 'ER_DB_CREATE_EXISTS') {
          console.log(`⚠️  Statement ${i + 1}/${statements.length} skipped (already exists)`);
        } else {
          console.error(`❌ Error executing statement ${i + 1}:`, error.message);
          throw error;
        }
      }
    }

    console.log('✅ Database migration completed successfully!');

  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
}

async function seedDatabase() {
  try {
    console.log('🌱 Starting database seeding...');

    // Read and execute seed.sql
    const seedPath = path.join(__dirname, '../database/seed.sql');
    const seedSQL = await fs.readFile(seedPath, 'utf8');

    // Split SQL statements
    const statements = seedSQL
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));

    console.log(`📝 Executing ${statements.length} seed statements...`);

    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i];
      try {
        await executeQuery(statement);
        console.log(`✅ Seed statement ${i + 1}/${statements.length} executed successfully`);
      } catch (error) {
        // Some inserts might fail if data already exists
        if (error.code === 'ER_DUP_ENTRY') {
          console.log(`⚠️  Seed statement ${i + 1}/${statements.length} skipped (duplicate entry)`);
        } else {
          console.error(`❌ Error executing seed statement ${i + 1}:`, error.message);
          // Don't throw error for seed failures, just log them
        }
      }
    }

    console.log('✅ Database seeding completed!');

  } catch (error) {
    console.error('❌ Seeding failed:', error);
    // Don't exit process for seed failures
  }
}

async function createUploadDirectories() {
  try {
    console.log('📁 Creating upload directories...');

    const directories = [
      path.join(__dirname, '../uploads'),
      path.join(__dirname, '../uploads/events'),
      path.join(__dirname, '../uploads/profiles'),
      path.join(__dirname, '../uploads/temp')
    ];

    for (const dir of directories) {
      try {
        await fs.mkdir(dir, { recursive: true });
        console.log(`✅ Created directory: ${dir}`);
      } catch (error) {
        if (error.code !== 'EEXIST') {
          throw error;
        }
        console.log(`⚠️  Directory already exists: ${dir}`);
      }
    }

    console.log('✅ Upload directories created successfully!');

  } catch (error) {
    console.error('❌ Failed to create upload directories:', error);
    throw error;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'migrate':
      await runMigrations();
      break;
    
    case 'seed':
      await seedDatabase();
      break;
    
    case 'setup':
      await createUploadDirectories();
      await runMigrations();
      await seedDatabase();
      break;
    
    case 'reset':
      console.log('🔄 Resetting database...');
      await runMigrations();
      await seedDatabase();
      break;
    
    default:
      console.log(`
Usage: node scripts/migrate.js <command>

Commands:
  migrate  - Run database migrations only
  seed     - Run database seeding only
  setup    - Create directories, run migrations and seed data
  reset    - Reset database (migrate + seed)

Examples:
  npm run migrate
  npm run seed
  node scripts/migrate.js setup
      `);
      break;
  }

  process.exit(0);
}

// Run if called directly
if (require.main === module) {
  main().catch(error => {
    console.error('❌ Script failed:', error);
    process.exit(1);
  });
}

module.exports = {
  runMigrations,
  seedDatabase,
  createUploadDirectories
};
