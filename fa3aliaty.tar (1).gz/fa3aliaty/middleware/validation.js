const { body, param, query, validationResult } = require('express-validator');

// Handle validation errors
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const formattedErrors = errors.array().map(error => ({
      field: error.path,
      message: error.msg,
      value: error.value
    }));
    
    return res.status(400).json({
      error: 'Validation failed',
      message_ar: 'فشل في التحقق من صحة البيانات',
      errors: formattedErrors
    });
  }
  
  next();
}

// User registration validation
const validateUserRegistration = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Valid email is required'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
  body('first_name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('First name must be between 2 and 100 characters'),
  body('last_name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Last name must be between 2 and 100 characters'),
  body('phone')
    .optional()
    .matches(/^\+?[1-9]\d{1,14}$/)
    .withMessage('Valid phone number is required'),
  body('organization_name')
    .optional()
    .trim()
    .isLength({ max: 255 })
    .withMessage('Organization name must not exceed 255 characters'),
  body('organization_type')
    .optional()
    .isIn(['company', 'nonprofit', 'government', 'individual', 'other'])
    .withMessage('Invalid organization type'),
  handleValidationErrors
];

// User login validation
const validateUserLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Valid email is required'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  handleValidationErrors
];

// Event creation validation
const validateEventCreation = [
  body('title_ar')
    .trim()
    .isLength({ min: 5, max: 255 })
    .withMessage('Arabic title must be between 5 and 255 characters'),
  body('title_en')
    .optional()
    .trim()
    .isLength({ max: 255 })
    .withMessage('English title must not exceed 255 characters'),
  body('description_ar')
    .trim()
    .isLength({ min: 20 })
    .withMessage('Arabic description must be at least 20 characters'),
  body('description_en')
    .optional()
    .trim(),
  body('event_type')
    .isIn(['conference', 'workshop', 'seminar', 'exhibition', 'networking', 'cultural', 'sports', 'entertainment', 'other'])
    .withMessage('Invalid event type'),
  body('start_date')
    .isISO8601()
    .toDate()
    .custom((value) => {
      if (new Date(value) <= new Date()) {
        throw new Error('Start date must be in the future');
      }
      return true;
    }),
  body('end_date')
    .isISO8601()
    .toDate()
    .custom((value, { req }) => {
      if (new Date(value) <= new Date(req.body.start_date)) {
        throw new Error('End date must be after start date');
      }
      return true;
    }),
  body('capacity')
    .optional()
    .isInt({ min: 1, max: 10000 })
    .withMessage('Capacity must be between 1 and 10000'),
  body('price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  body('category_id')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Invalid category ID'),
  body('venue_id')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Invalid venue ID'),
  handleValidationErrors
];

// Event update validation (similar to creation but all fields optional)
const validateEventUpdate = [
  body('title_ar')
    .optional()
    .trim()
    .isLength({ min: 5, max: 255 })
    .withMessage('Arabic title must be between 5 and 255 characters'),
  body('title_en')
    .optional()
    .trim()
    .isLength({ max: 255 })
    .withMessage('English title must not exceed 255 characters'),
  body('description_ar')
    .optional()
    .trim()
    .isLength({ min: 20 })
    .withMessage('Arabic description must be at least 20 characters'),
  body('event_type')
    .optional()
    .isIn(['conference', 'workshop', 'seminar', 'exhibition', 'networking', 'cultural', 'sports', 'entertainment', 'other'])
    .withMessage('Invalid event type'),
  body('start_date')
    .optional()
    .isISO8601()
    .toDate(),
  body('end_date')
    .optional()
    .isISO8601()
    .toDate(),
  body('capacity')
    .optional()
    .isInt({ min: 1, max: 10000 })
    .withMessage('Capacity must be between 1 and 10000'),
  body('price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  body('status')
    .optional()
    .isIn(['draft', 'published', 'cancelled', 'completed', 'postponed'])
    .withMessage('Invalid status'),
  handleValidationErrors
];

// Event registration validation
const validateEventRegistration = [
  body('attendee_name')
    .trim()
    .isLength({ min: 2, max: 255 })
    .withMessage('Attendee name must be between 2 and 255 characters'),
  body('attendee_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Valid email is required'),
  body('attendee_phone')
    .optional()
    .matches(/^\+?[1-9]\d{1,14}$/)
    .withMessage('Valid phone number is required'),
  body('attendee_organization')
    .optional()
    .trim()
    .isLength({ max: 255 })
    .withMessage('Organization name must not exceed 255 characters'),
  handleValidationErrors
];

// ID parameter validation
const validateId = [
  param('id')
    .isInt({ min: 1 })
    .withMessage('Valid ID is required'),
  handleValidationErrors
];

// Query parameter validation for events listing
const validateEventQuery = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  query('category')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Category must be a valid ID'),
  query('search')
    .optional()
    .trim()
    .isLength({ min: 2 })
    .withMessage('Search term must be at least 2 characters'),
  query('status')
    .optional()
    .isIn(['draft', 'published', 'cancelled', 'completed', 'postponed'])
    .withMessage('Invalid status'),
  query('sort')
    .optional()
    .isIn(['date_asc', 'date_desc', 'title_asc', 'title_desc', 'created_asc', 'created_desc'])
    .withMessage('Invalid sort option'),
  handleValidationErrors
];

// Password reset validation
const validatePasswordReset = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Valid email is required'),
  handleValidationErrors
];

// New password validation
const validateNewPassword = [
  body('token')
    .notEmpty()
    .withMessage('Reset token is required'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
  handleValidationErrors
];

module.exports = {
  handleValidationErrors,
  validateUserRegistration,
  validateUserLogin,
  validateEventCreation,
  validateEventUpdate,
  validateEventRegistration,
  validateId,
  validateEventQuery,
  validatePasswordReset,
  validateNewPassword
};
