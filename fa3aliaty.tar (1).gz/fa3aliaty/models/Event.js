const { getOne, getMany, insert, update, remove, executeQuery } = require('../config/database');

class Event {
  // Create a new event
  static async create(eventData, organizerId) {
    const {
      category_id,
      venue_id,
      title_ar,
      title_en,
      description_ar,
      description_en,
      short_description_ar,
      short_description_en,
      event_type,
      start_date,
      end_date,
      registration_start,
      registration_end,
      capacity,
      price = 0,
      currency = 'SAR',
      is_free = true,
      is_online = false,
      meeting_url,
      tags,
      images,
      attachments,
      requirements,
      agenda,
      speakers,
      sponsors,
      custom_fields
    } = eventData;

    const query = `
      INSERT INTO events (
        organizer_id, category_id, venue_id, title_ar, title_en, 
        description_ar, description_en, short_description_ar, short_description_en,
        event_type, start_date, end_date, registration_start, registration_end,
        capacity, price, currency, is_free, is_online, meeting_url,
        tags, images, attachments, requirements, agenda, speakers, sponsors, custom_fields
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const eventId = await insert(query, [
      organizerId, category_id, venue_id, title_ar, title_en,
      description_ar, description_en, short_description_ar, short_description_en,
      event_type, start_date, end_date, registration_start, registration_end,
      capacity, price, currency, is_free, is_online, meeting_url,
      JSON.stringify(tags), JSON.stringify(images), JSON.stringify(attachments),
      JSON.stringify(requirements), JSON.stringify(agenda), JSON.stringify(speakers),
      JSON.stringify(sponsors), JSON.stringify(custom_fields)
    ]);

    return eventId;
  }

  // Get event by ID with full details
  static async findById(id, includeOrganizer = false) {
    let query = `
      SELECT e.*, 
             c.name_ar as category_name_ar, c.name_en as category_name_en,
             v.name_ar as venue_name_ar, v.name_en as venue_name_en,
             v.address_ar as venue_address_ar, v.address_en as venue_address_en,
             v.city as venue_city, v.latitude as venue_latitude, v.longitude as venue_longitude
      FROM events e
      LEFT JOIN event_categories c ON e.category_id = c.id
      LEFT JOIN venues v ON e.venue_id = v.id
    `;

    if (includeOrganizer) {
      query += `
        LEFT JOIN users u ON e.organizer_id = u.id
      `;
    }

    query += ' WHERE e.id = ?';

    const event = await getOne(query, [id]);

    if (event) {
      // Parse JSON fields
      event.tags = this.parseJSON(event.tags);
      event.images = this.parseJSON(event.images);
      event.attachments = this.parseJSON(event.attachments);
      event.requirements = this.parseJSON(event.requirements);
      event.agenda = this.parseJSON(event.agenda);
      event.speakers = this.parseJSON(event.speakers);
      event.sponsors = this.parseJSON(event.sponsors);
      event.custom_fields = this.parseJSON(event.custom_fields);
    }

    return event;
  }

  // Get events with filtering and pagination
  static async findMany(filters = {}, pagination = {}) {
    const {
      organizer_id,
      category_id,
      status = 'published',
      search,
      event_type,
      is_free,
      start_date_from,
      start_date_to,
      featured
    } = filters;

    const {
      page = 1,
      limit = 10,
      sort = 'start_date',
      order = 'ASC'
    } = pagination;

    let whereConditions = [];
    let params = [];

    // Build WHERE conditions
    if (organizer_id) {
      whereConditions.push('e.organizer_id = ?');
      params.push(organizer_id);
    }

    if (category_id) {
      whereConditions.push('e.category_id = ?');
      params.push(category_id);
    }

    if (status) {
      whereConditions.push('e.status = ?');
      params.push(status);
    }

    if (event_type) {
      whereConditions.push('e.event_type = ?');
      params.push(event_type);
    }

    if (is_free !== undefined) {
      whereConditions.push('e.is_free = ?');
      params.push(is_free);
    }

    if (featured !== undefined) {
      whereConditions.push('e.featured = ?');
      params.push(featured);
    }

    if (start_date_from) {
      whereConditions.push('e.start_date >= ?');
      params.push(start_date_from);
    }

    if (start_date_to) {
      whereConditions.push('e.start_date <= ?');
      params.push(start_date_to);
    }

    if (search) {
      whereConditions.push('(e.title_ar LIKE ? OR e.title_en LIKE ? OR e.description_ar LIKE ? OR e.description_en LIKE ?)');
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    // Build the query
    let query = `
      SELECT e.*, 
             c.name_ar as category_name_ar, c.name_en as category_name_en,
             v.name_ar as venue_name_ar, v.city as venue_city,
             u.first_name as organizer_first_name, u.last_name as organizer_last_name,
             u.organization_name as organizer_organization
      FROM events e
      LEFT JOIN event_categories c ON e.category_id = c.id
      LEFT JOIN venues v ON e.venue_id = v.id
      LEFT JOIN users u ON e.organizer_id = u.id
    `;

    if (whereConditions.length > 0) {
      query += ' WHERE ' + whereConditions.join(' AND ');
    }

    // Add sorting
    const validSortFields = ['start_date', 'created_at', 'title_ar', 'price', 'views_count'];
    const sortField = validSortFields.includes(sort) ? sort : 'start_date';
    const sortOrder = order.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
    
    query += ` ORDER BY e.${sortField} ${sortOrder}`;

    // Add pagination
    const offset = (page - 1) * limit;
    query += ' LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const events = await getMany(query, params);

    // Parse JSON fields for each event
    events.forEach(event => {
      event.tags = this.parseJSON(event.tags);
      event.images = this.parseJSON(event.images);
      event.speakers = this.parseJSON(event.speakers);
    });

    // Get total count for pagination
    let countQuery = `
      SELECT COUNT(*) as total
      FROM events e
    `;

    if (whereConditions.length > 0) {
      countQuery += ' WHERE ' + whereConditions.join(' AND ');
    }

    const countParams = params.slice(0, -2); // Remove limit and offset
    const totalResult = await getOne(countQuery, countParams);
    const total = totalResult.total;

    return {
      events,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    };
  }

  // Update event
  static async update(id, updateData, organizerId) {
    const allowedFields = [
      'category_id', 'venue_id', 'title_ar', 'title_en', 'description_ar', 'description_en',
      'short_description_ar', 'short_description_en', 'event_type', 'start_date', 'end_date',
      'registration_start', 'registration_end', 'capacity', 'price', 'currency', 'is_free',
      'is_online', 'meeting_url', 'status', 'featured', 'tags', 'images', 'attachments',
      'requirements', 'agenda', 'speakers', 'sponsors', 'custom_fields'
    ];

    const updates = [];
    const values = [];

    Object.keys(updateData).forEach(key => {
      if (allowedFields.includes(key) && updateData[key] !== undefined) {
        updates.push(`${key} = ?`);
        
        // Handle JSON fields
        if (['tags', 'images', 'attachments', 'requirements', 'agenda', 'speakers', 'sponsors', 'custom_fields'].includes(key)) {
          values.push(JSON.stringify(updateData[key]));
        } else {
          values.push(updateData[key]);
        }
      }
    });

    if (updates.length === 0) {
      throw new Error('No valid fields to update');
    }

    values.push(id, organizerId);

    const query = `UPDATE events SET ${updates.join(', ')} WHERE id = ? AND organizer_id = ?`;
    const affectedRows = await update(query, values);
    
    return affectedRows > 0;
  }

  // Delete event
  static async delete(id, organizerId) {
    const query = 'DELETE FROM events WHERE id = ? AND organizer_id = ?';
    const affectedRows = await remove(query, [id, organizerId]);
    
    return affectedRows > 0;
  }

  // Increment view count
  static async incrementViews(id) {
    const query = 'UPDATE events SET views_count = views_count + 1 WHERE id = ?';
    await update(query, [id]);
  }

  // Update registration count
  static async updateRegistrationCount(id) {
    const query = `
      UPDATE events 
      SET registration_count = (
        SELECT COUNT(*) 
        FROM event_registrations 
        WHERE event_id = ? AND status IN ('confirmed', 'attended')
      )
      WHERE id = ?
    `;
    await update(query, [id, id]);
  }

  // Get event categories
  static async getCategories() {
    const query = `
      SELECT id, name_ar, name_en, description_ar, description_en, icon, color
      FROM event_categories 
      WHERE is_active = TRUE 
      ORDER BY sort_order, name_ar
    `;
    return await getMany(query);
  }

  // Get venues
  static async getVenues(city = null) {
    let query = `
      SELECT id, name_ar, name_en, address_ar, address_en, city, capacity, venue_type
      FROM venues 
      WHERE is_active = TRUE
    `;
    
    let params = [];
    if (city) {
      query += ' AND city = ?';
      params.push(city);
    }
    
    query += ' ORDER BY name_ar';
    
    return await getMany(query, params);
  }

  // Helper method to safely parse JSON
  static parseJSON(jsonString) {
    if (!jsonString) return null;
    try {
      return JSON.parse(jsonString);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      return null;
    }
  }

  // Get upcoming events for a user
  static async getUpcomingEvents(organizerId, limit = 5) {
    const query = `
      SELECT id, title_ar, start_date, status, registration_count, views_count
      FROM events 
      WHERE organizer_id = ? AND start_date > NOW() AND status = 'published'
      ORDER BY start_date ASC
      LIMIT ?
    `;
    return await getMany(query, [organizerId, limit]);
  }

  // Get event analytics
  static async getAnalytics(eventId, organizerId) {
    const query = `
      SELECT 
        metric_type,
        COUNT(*) as count,
        DATE(recorded_at) as date
      FROM event_analytics 
      WHERE event_id = ? 
      AND event_id IN (SELECT id FROM events WHERE organizer_id = ?)
      GROUP BY metric_type, DATE(recorded_at)
      ORDER BY date DESC
      LIMIT 30
    `;
    return await getMany(query, [eventId, organizerId]);
  }
}

module.exports = Event;
