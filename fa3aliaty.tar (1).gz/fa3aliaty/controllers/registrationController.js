const Registration = require('../models/Registration');
const Event = require('../models/Event');
const { sendEmail } = require('../utils/email');

class RegistrationController {
  // Register for an event
  static async register(req, res) {
    try {
      const { id: eventId } = req.params;
      const {
        attendee_name,
        attendee_email,
        attendee_phone,
        attendee_organization,
        registration_data
      } = req.body;

      // Check if event exists and is open for registration
      const event = await Event.findById(eventId);
      if (!event) {
        return res.status(404).json({
          error: 'Event not found',
          message_ar: 'الفعالية غير موجودة'
        });
      }

      if (event.status !== 'published') {
        return res.status(400).json({
          error: 'Event is not open for registration',
          message_ar: 'الفعالية غير متاحة للتسجيل'
        });
      }

      // Check registration period
      const now = new Date();
      if (event.registration_start && new Date(event.registration_start) > now) {
        return res.status(400).json({
          error: 'Registration has not started yet',
          message_ar: 'التسجيل لم يبدأ بعد'
        });
      }

      if (event.registration_end && new Date(event.registration_end) < now) {
        return res.status(400).json({
          error: 'Registration period has ended',
          message_ar: 'انتهت فترة التسجيل'
        });
      }

      // Check if already registered
      const existingRegistration = await Registration.isRegistered(eventId, attendee_email);
      if (existingRegistration) {
        return res.status(400).json({
          error: 'Already registered for this event',
          message_ar: 'مسجل مسبقاً في هذه الفعالية',
          registration_status: existingRegistration.status
        });
      }

      // Check capacity
      if (event.capacity) {
        const stats = await Registration.getEventStats(eventId, event.organizer_id);
        if (stats.confirmed_registrations >= event.capacity) {
          return res.status(400).json({
            error: 'Event is full',
            message_ar: 'الفعالية مكتملة العدد'
          });
        }
      }

      // Create registration
      const registrationData = {
        event_id: eventId,
        attendee_name,
        attendee_email,
        attendee_phone,
        attendee_organization,
        registration_data,
        payment_amount: event.is_free ? 0 : event.price
      };

      const result = await Registration.create(registrationData);

      // Update event registration count
      await Event.updateRegistrationCount(eventId);

      // Send confirmation email
      try {
        await sendEmail({
          to: attendee_email,
          subject: `تأكيد التسجيل - ${event.title_ar}`,
          template: 'registration-confirmation',
          data: {
            attendee_name,
            event_title: event.title_ar,
            event_date: new Date(event.start_date).toLocaleDateString('ar-SA'),
            event_time: new Date(event.start_date).toLocaleTimeString('ar-SA'),
            venue_name: event.venue_name_ar,
            venue_address: event.venue_address_ar,
            confirmation_token: result.confirmation_token,
            qr_code: result.qr_code,
            is_free: event.is_free,
            price: event.price
          }
        });
      } catch (emailError) {
        console.error('Failed to send confirmation email:', emailError);
      }

      res.status(201).json({
        message: 'Registration successful',
        message_ar: 'تم التسجيل بنجاح',
        registration_id: result.id,
        confirmation_token: result.confirmation_token,
        qr_code: result.qr_code
      });

    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({
        error: 'Registration failed',
        message_ar: 'فشل في التسجيل'
      });
    }
  }

  // Get registration details
  static async getRegistration(req, res) {
    try {
      const { id } = req.params;

      const registration = await Registration.findById(id);

      if (!registration) {
        return res.status(404).json({
          error: 'Registration not found',
          message_ar: 'التسجيل غير موجود'
        });
      }

      res.json({
        registration
      });

    } catch (error) {
      console.error('Get registration error:', error);
      res.status(500).json({
        error: 'Failed to get registration',
        message_ar: 'فشل في جلب التسجيل'
      });
    }
  }

  // Get registration by confirmation token
  static async getByToken(req, res) {
    try {
      const { token } = req.params;

      const registration = await Registration.findByToken(token);

      if (!registration) {
        return res.status(404).json({
          error: 'Registration not found',
          message_ar: 'التسجيل غير موجود'
        });
      }

      res.json({
        registration
      });

    } catch (error) {
      console.error('Get registration by token error:', error);
      res.status(500).json({
        error: 'Failed to get registration',
        message_ar: 'فشل في جلب التسجيل'
      });
    }
  }

  // Cancel registration
  static async cancel(req, res) {
    try {
      const { id } = req.params;
      const { attendee_email } = req.body;

      const success = await Registration.cancel(id, attendee_email);

      if (!success) {
        return res.status(404).json({
          error: 'Registration not found or you do not have permission to cancel it',
          message_ar: 'التسجيل غير موجود أو ليس لديك صلاحية لإلغائه'
        });
      }

      // Get registration details for email
      const registration = await Registration.findById(id);
      if (registration) {
        // Update event registration count
        await Event.updateRegistrationCount(registration.event_id);

        // Send cancellation email
        try {
          await sendEmail({
            to: registration.attendee_email,
            subject: `إلغاء التسجيل - ${registration.event_title_ar}`,
            template: 'registration-cancellation',
            data: {
              attendee_name: registration.attendee_name,
              event_title: registration.event_title_ar,
              event_date: new Date(registration.start_date).toLocaleDateString('ar-SA')
            }
          });
        } catch (emailError) {
          console.error('Failed to send cancellation email:', emailError);
        }
      }

      res.json({
        message: 'Registration cancelled successfully',
        message_ar: 'تم إلغاء التسجيل بنجاح'
      });

    } catch (error) {
      console.error('Cancel registration error:', error);
      res.status(500).json({
        error: 'Failed to cancel registration',
        message_ar: 'فشل في إلغاء التسجيل'
      });
    }
  }

  // Get registrations by attendee email
  static async getByEmail(req, res) {
    try {
      const { email } = req.params;
      const { status, upcoming_only } = req.query;

      const filters = {
        status,
        upcoming_only: upcoming_only === 'true'
      };

      const registrations = await Registration.getByAttendeeEmail(email, filters);

      res.json({
        registrations
      });

    } catch (error) {
      console.error('Get registrations by email error:', error);
      res.status(500).json({
        error: 'Failed to get registrations',
        message_ar: 'فشل في جلب التسجيلات'
      });
    }
  }

  // Update payment status (for payment gateway webhooks)
  static async updatePaymentStatus(req, res) {
    try {
      const { id } = req.params;
      const { payment_status, payment_reference } = req.body;

      const success = await Registration.updatePaymentStatus(id, payment_status, payment_reference);

      if (!success) {
        return res.status(404).json({
          error: 'Registration not found',
          message_ar: 'التسجيل غير موجود'
        });
      }

      // If payment is successful, confirm the registration
      if (payment_status === 'paid') {
        await Registration.updateStatus(id, 'confirmed');
        
        // Get registration details for email
        const registration = await Registration.findById(id);
        if (registration) {
          // Update event registration count
          await Event.updateRegistrationCount(registration.event_id);

          // Send payment confirmation email
          try {
            await sendEmail({
              to: registration.attendee_email,
              subject: `تأكيد الدفع - ${registration.event_title_ar}`,
              template: 'payment-confirmation',
              data: {
                attendee_name: registration.attendee_name,
                event_title: registration.event_title_ar,
                payment_amount: registration.payment_amount,
                payment_reference
              }
            });
          } catch (emailError) {
            console.error('Failed to send payment confirmation email:', emailError);
          }
        }
      }

      res.json({
        message: 'Payment status updated successfully',
        message_ar: 'تم تحديث حالة الدفع بنجاح'
      });

    } catch (error) {
      console.error('Update payment status error:', error);
      res.status(500).json({
        error: 'Failed to update payment status',
        message_ar: 'فشل في تحديث حالة الدفع'
      });
    }
  }

  // Bulk check-in attendees (for organizers)
  static async bulkCheckIn(req, res) {
    try {
      const { registration_ids } = req.body;
      const organizerId = req.userId;

      if (!registration_ids || !Array.isArray(registration_ids) || registration_ids.length === 0) {
        return res.status(400).json({
          error: 'Registration IDs are required',
          message_ar: 'معرفات التسجيل مطلوبة'
        });
      }

      const updatedCount = await Registration.bulkUpdateStatus(registration_ids, 'attended', organizerId);

      res.json({
        message: `${updatedCount} registrations checked in successfully`,
        message_ar: `تم تسجيل حضور ${updatedCount} مشارك بنجاح`,
        updated_count: updatedCount
      });

    } catch (error) {
      console.error('Bulk check-in error:', error);
      res.status(500).json({
        error: 'Failed to check in attendees',
        message_ar: 'فشل في تسجيل حضور المشاركين'
      });
    }
  }

  // Confirm registration (for email confirmation)
  static async confirm(req, res) {
    try {
      const { token } = req.params;

      const registration = await Registration.findByToken(token);

      if (!registration) {
        return res.status(404).json({
          error: 'Invalid confirmation token',
          message_ar: 'رمز التأكيد غير صالح'
        });
      }

      if (registration.status === 'confirmed') {
        return res.json({
          message: 'Registration already confirmed',
          message_ar: 'التسجيل مؤكد مسبقاً'
        });
      }

      const success = await Registration.updateStatus(registration.id, 'confirmed');

      if (!success) {
        return res.status(500).json({
          error: 'Failed to confirm registration',
          message_ar: 'فشل في تأكيد التسجيل'
        });
      }

      // Update event registration count
      await Event.updateRegistrationCount(registration.event_id);

      res.json({
        message: 'Registration confirmed successfully',
        message_ar: 'تم تأكيد التسجيل بنجاح'
      });

    } catch (error) {
      console.error('Confirm registration error:', error);
      res.status(500).json({
        error: 'Failed to confirm registration',
        message_ar: 'فشل في تأكيد التسجيل'
      });
    }
  }
}

module.exports = RegistrationController;
