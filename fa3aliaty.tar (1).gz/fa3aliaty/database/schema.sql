-- Feaalyati Database Schema
-- Create database
CREATE DATABASE IF NOT EXISTS feaalyati_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE feaalyati_db;

-- Users table (Organizers only based on requirements)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    organization_name VARCHAR(255),
    organization_type ENUM('company', 'nonprofit', 'government', 'individual', 'other') DEFAULT 'individual',
    profile_image VARCHAR(255),
    bio TEXT,
    website VARCHAR(255),
    social_media JSON,
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_token VARCHAR(255),
    password_reset_token VARCHAR(255),
    password_reset_expires DATETIME,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Event categories table
CREATE TABLE event_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_ar VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    description_ar TEXT,
    description_en TEXT,
    icon VARCHAR(100),
    color VARCHAR(7) DEFAULT '#8a2be2',
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_active (is_active),
    INDEX idx_sort (sort_order)
);

-- Venues table
CREATE TABLE venues (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_ar VARCHAR(255) NOT NULL,
    name_en VARCHAR(255),
    address_ar TEXT NOT NULL,
    address_en TEXT,
    city VARCHAR(100) NOT NULL,
    country VARCHAR(100) DEFAULT 'Saudi Arabia',
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    capacity INT,
    venue_type ENUM('indoor', 'outdoor', 'hybrid') DEFAULT 'indoor',
    facilities JSON,
    contact_phone VARCHAR(20),
    contact_email VARCHAR(255),
    website VARCHAR(255),
    images JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_city (city),
    INDEX idx_capacity (capacity),
    INDEX idx_active (is_active)
);

-- Events table
CREATE TABLE events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    organizer_id INT NOT NULL,
    category_id INT,
    venue_id INT,
    title_ar VARCHAR(255) NOT NULL,
    title_en VARCHAR(255),
    description_ar TEXT NOT NULL,
    description_en TEXT,
    short_description_ar VARCHAR(500),
    short_description_en VARCHAR(500),
    event_type ENUM('conference', 'workshop', 'seminar', 'exhibition', 'networking', 'cultural', 'sports', 'entertainment', 'other') NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    registration_start DATETIME,
    registration_end DATETIME,
    capacity INT,
    price DECIMAL(10, 2) DEFAULT 0.00,
    currency VARCHAR(3) DEFAULT 'SAR',
    is_free BOOLEAN DEFAULT TRUE,
    is_online BOOLEAN DEFAULT FALSE,
    meeting_url VARCHAR(500),
    status ENUM('draft', 'published', 'cancelled', 'completed', 'postponed') DEFAULT 'draft',
    featured BOOLEAN DEFAULT FALSE,
    tags JSON,
    images JSON,
    attachments JSON,
    requirements JSON,
    agenda JSON,
    speakers JSON,
    sponsors JSON,
    social_media JSON,
    custom_fields JSON,
    views_count INT DEFAULT 0,
    registration_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (organizer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES event_categories(id) ON DELETE SET NULL,
    FOREIGN KEY (venue_id) REFERENCES venues(id) ON DELETE SET NULL,
    
    INDEX idx_organizer (organizer_id),
    INDEX idx_category (category_id),
    INDEX idx_venue (venue_id),
    INDEX idx_dates (start_date, end_date),
    INDEX idx_status (status),
    INDEX idx_featured (featured),
    INDEX idx_type (event_type),
    INDEX idx_price (price),
    INDEX idx_created (created_at)
);

-- Event registrations table (for attendees)
CREATE TABLE event_registrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    attendee_name VARCHAR(255) NOT NULL,
    attendee_email VARCHAR(255) NOT NULL,
    attendee_phone VARCHAR(20),
    attendee_organization VARCHAR(255),
    registration_data JSON,
    status ENUM('pending', 'confirmed', 'cancelled', 'attended', 'no_show') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'refunded', 'failed') DEFAULT 'pending',
    payment_amount DECIMAL(10, 2) DEFAULT 0.00,
    payment_reference VARCHAR(255),
    confirmation_token VARCHAR(255),
    qr_code VARCHAR(255),
    notes TEXT,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP NULL,
    attended_at TIMESTAMP NULL,
    
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    
    INDEX idx_event (event_id),
    INDEX idx_email (attendee_email),
    INDEX idx_status (status),
    INDEX idx_payment (payment_status),
    INDEX idx_registered (registered_at),
    
    UNIQUE KEY unique_registration (event_id, attendee_email)
);

-- Event analytics table
CREATE TABLE event_analytics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    metric_type ENUM('view', 'registration', 'share', 'click') NOT NULL,
    metric_value INT DEFAULT 1,
    user_agent TEXT,
    ip_address VARCHAR(45),
    referrer VARCHAR(500),
    additional_data JSON,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    
    INDEX idx_event_metric (event_id, metric_type),
    INDEX idx_recorded (recorded_at)
);

-- Notifications table
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_id INT,
    type ENUM('event_reminder', 'registration_confirmation', 'event_update', 'event_cancelled', 'system') NOT NULL,
    title_ar VARCHAR(255) NOT NULL,
    title_en VARCHAR(255),
    message_ar TEXT NOT NULL,
    message_en TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    email_sent BOOLEAN DEFAULT FALSE,
    email_sent_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    
    INDEX idx_user (user_id),
    INDEX idx_event (event_id),
    INDEX idx_read (is_read),
    INDEX idx_created (created_at)
);

-- System settings table
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description_ar TEXT,
    description_en TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_key (setting_key),
    INDEX idx_public (is_public)
);
