// Function to include HTML components
function includeHTML() {
    const elements = document.querySelectorAll('[data-include]');
    
    elements.forEach(element => {
        const file = element.getAttribute('data-include');
        
        fetch(file)
            .then(response => {
                if (response.ok) {
                    return response.text();
                }
                throw new Error(`Could not load ${file}: ${response.status} ${response.statusText}`);
            })
            .then(html => {
                element.innerHTML = html;
                
                // Execute scripts inside the included HTML
                const scripts = element.querySelectorAll('script');
                scripts.forEach(script => {
                    const newScript = document.createElement('script');
                    
                    if (script.src) {
                        newScript.src = script.src;
                    } else {
                        newScript.textContent = script.textContent;
                    }
                    
                    // Remove the original script
                    script.parentNode.removeChild(script);
                    
                    // Add the new script to the document
                    document.head.appendChild(newScript);
                });
            })
            .catch(error => {
                console.error('Error including HTML:', error);
                element.innerHTML = `<p>Error loading component: ${error.message}</p>`;
            });
    });
}

// Run on document load
document.addEventListener('DOMContentLoaded', includeHTML);