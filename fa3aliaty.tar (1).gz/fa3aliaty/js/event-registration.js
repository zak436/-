// Event registration functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get event ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('event');
    
    if (eventId) {
        loadEventDetails(eventId);
    } else {
        showError('معرف الفعالية غير موجود');
        return;
    }
    
    // Handle registration form submission
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', handleRegistration);
    }
});

// Load event details for registration
async function loadEventDetails(eventId) {
    try {
        const response = await window.api.getEvent(eventId);
        const event = response.event;
        
        displayEventInfo(event);
        checkRegistrationEligibility(event);
        
    } catch (error) {
        console.error('Error loading event details:', error);
        showError('فشل في تحميل تفاصيل الفعالية');
    }
}

// Display event information in registration form
function displayEventInfo(event) {
    // Update page title
    document.title = `التسجيل في ${event.title_ar} - فعالياتي`;
    
    // Update event info section
    const eventInfoContainer = document.querySelector('.event-info');
    if (eventInfoContainer) {
        const eventDate = new Date(event.start_date);
        const formattedDate = eventDate.toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const formattedTime = eventDate.toLocaleTimeString('ar-SA', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        eventInfoContainer.innerHTML = `
            <div class="event-summary">
                <h2>${event.title_ar}</h2>
                <div class="event-details">
                    <div class="detail-item">
                        <i class="fas fa-calendar"></i>
                        <span>${formattedDate}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-clock"></i>
                        <span>${formattedTime}</span>
                    </div>
                    ${event.venue_name_ar ? `
                        <div class="detail-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${event.venue_name_ar}</span>
                        </div>
                    ` : ''}
                    <div class="detail-item">
                        <i class="fas fa-tag"></i>
                        <span>${event.is_free ? 'مجاني' : `${event.price} ريال`}</span>
                    </div>
                </div>
                ${event.short_description_ar ? `
                    <p class="event-description">${event.short_description_ar}</p>
                ` : ''}
            </div>
        `;
    }
    
    // Update price information
    const priceInfo = document.querySelector('.price-info');
    if (priceInfo) {
        if (event.is_free) {
            priceInfo.innerHTML = `
                <div class="price-display free">
                    <span class="price">مجاني</span>
                    <span class="price-label">رسوم التسجيل</span>
                </div>
            `;
        } else {
            priceInfo.innerHTML = `
                <div class="price-display paid">
                    <span class="price">${event.price} ريال</span>
                    <span class="price-label">رسوم التسجيل</span>
                </div>
            `;
        }
    }
}

// Check registration eligibility
function checkRegistrationEligibility(event) {
    const now = new Date();
    const startDate = new Date(event.start_date);
    const registrationEnd = event.registration_end ? new Date(event.registration_end) : startDate;
    
    let canRegister = true;
    let message = '';
    
    // Check if event has started
    if (startDate <= now) {
        canRegister = false;
        message = 'لا يمكن التسجيل - الفعالية بدأت بالفعل';
    }
    // Check if registration period ended
    else if (registrationEnd <= now) {
        canRegister = false;
        message = 'انتهت فترة التسجيل لهذه الفعالية';
    }
    // Check if event is published
    else if (event.status !== 'published') {
        canRegister = false;
        message = 'الفعالية غير متاحة للتسجيل حالياً';
    }
    
    if (!canRegister) {
        showRegistrationClosed(message);
    }
}

// Handle registration form submission
async function handleRegistration(e) {
    e.preventDefault();
    
    const submitButton = e.target.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    
    // Show loading state
    submitButton.disabled = true;
    submitButton.textContent = 'جاري التسجيل...';
    
    try {
        // Get form data
        const formData = new FormData(e.target);
        const registrationData = {
            attendee_name: formData.get('attendee_name'),
            attendee_email: formData.get('attendee_email'),
            attendee_phone: formData.get('attendee_phone'),
            attendee_organization: formData.get('attendee_organization'),
            registration_data: {
                special_requirements: formData.get('special_requirements'),
                dietary_restrictions: formData.get('dietary_restrictions'),
                emergency_contact: formData.get('emergency_contact')
            }
        };
        
        // Get event ID
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('event');
        
        // Submit registration
        const response = await window.api.registerForEvent(eventId, registrationData);
        
        // Show success message
        showRegistrationSuccess(response);
        
    } catch (error) {
        console.error('Registration error:', error);
        showRegistrationError(error.message);
        
        // Reset button
        submitButton.disabled = false;
        submitButton.textContent = originalText;
    }
}

// Show registration success
function showRegistrationSuccess(response) {
    const container = document.querySelector('.registration-container');
    
    container.innerHTML = `
        <div class="registration-success">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>تم التسجيل بنجاح!</h2>
            <p>تم تسجيلك في الفعالية بنجاح. ستصلك رسالة تأكيد على بريدك الإلكتروني.</p>
            
            <div class="registration-details">
                <h3>تفاصيل التسجيل:</h3>
                <div class="detail-item">
                    <strong>رقم التسجيل:</strong>
                    <span>${response.registration_id}</span>
                </div>
                <div class="detail-item">
                    <strong>رمز التأكيد:</strong>
                    <span>${response.confirmation_token}</span>
                </div>
            </div>
            
            <div class="success-actions">
                <a href="index.html" class="btn btn-primary">العودة للرئيسية</a>
                <a href="events.html" class="btn btn-secondary">تصفح المزيد من الفعاليات</a>
            </div>
        </div>
    `;
}

// Show registration error
function showRegistrationError(message) {
    // Remove existing error messages
    const existingError = document.querySelector('.registration-error');
    if (existingError) {
        existingError.remove();
    }
    
    // Create error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'registration-error';
    errorDiv.style.cssText = `
        background-color: #fee;
        color: #c33;
        padding: 15px;
        border-radius: 8px;
        margin: 20px 0;
        text-align: center;
        border: 1px solid #fcc;
    `;
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        <span>${message}</span>
    `;
    
    // Insert error message
    const form = document.getElementById('registrationForm');
    form.insertBefore(errorDiv, form.firstChild);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, 5000);
}

// Show registration closed message
function showRegistrationClosed(message) {
    const container = document.querySelector('.registration-container');
    
    container.innerHTML = `
        <div class="registration-closed">
            <div class="closed-icon">
                <i class="fas fa-times-circle"></i>
            </div>
            <h2>التسجيل غير متاح</h2>
            <p>${message}</p>
            
            <div class="closed-actions">
                <a href="events.html" class="btn btn-primary">تصفح فعاليات أخرى</a>
                <a href="index.html" class="btn btn-secondary">العودة للرئيسية</a>
            </div>
        </div>
    `;
}

// Show general error
function showError(message) {
    const container = document.querySelector('.registration-container') || document.body;
    
    container.innerHTML = `
        <div class="error-state">
            <div class="error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2>حدث خطأ</h2>
            <p>${message}</p>
            
            <div class="error-actions">
                <a href="events.html" class="btn btn-primary">تصفح الفعاليات</a>
                <a href="index.html" class="btn btn-secondary">العودة للرئيسية</a>
            </div>
        </div>
    `;
}

// Email validation
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Phone validation (Saudi format)
function validatePhone(phone) {
    const phoneRegex = /^(\+966|966|0)?[5][0-9]{8}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// Add real-time validation
document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.getElementById('attendee_email');
    const phoneInput = document.getElementById('attendee_phone');
    
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            if (this.value && !validateEmail(this.value)) {
                this.setCustomValidity('يرجى إدخال بريد إلكتروني صحيح');
            } else {
                this.setCustomValidity('');
            }
        });
    }
    
    if (phoneInput) {
        phoneInput.addEventListener('blur', function() {
            if (this.value && !validatePhone(this.value)) {
                this.setCustomValidity('يرجى إدخال رقم هاتف صحيح');
            } else {
                this.setCustomValidity('');
            }
        });
    }
});
