// API Service Layer for Feaalyati Frontend
class FeaalyatiAPI {
    constructor() {
        this.baseURL = 'http://localhost:3001/api';
        this.token = localStorage.getItem('authToken');
    }

    // Set authentication token
    setToken(token) {
        this.token = token;
        if (token) {
            localStorage.setItem('authToken', token);
        } else {
            localStorage.removeItem('authToken');
        }
    }

    // Get authentication headers
    getHeaders(includeAuth = true) {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        if (includeAuth && this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        return headers;
    }

    // Generic API request method
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: this.getHeaders(options.auth !== false),
            ...options
        };

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message_ar || data.error || 'حدث خطأ في الطلب');
            }

            return data;
        } catch (error) {
            console.error('API Request Error:', error);
            throw error;
        }
    }

    // Authentication Methods
    async register(userData) {
        return await this.request('/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData),
            auth: false
        });
    }

    async login(credentials) {
        const response = await this.request('/auth/login', {
            method: 'POST',
            body: JSON.stringify(credentials),
            auth: false
        });

        if (response.access_token) {
            this.setToken(response.access_token);
            localStorage.setItem('user', JSON.stringify(response.user));
        }

        return response;
    }

    async logout() {
        try {
            await this.request('/auth/logout', { method: 'POST' });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.setToken(null);
            localStorage.removeItem('user');
            localStorage.removeItem('isLoggedIn');
        }
    }

    async getProfile() {
        return await this.request('/auth/profile');
    }

    async updateProfile(profileData) {
        return await this.request('/users/profile', {
            method: 'PUT',
            body: JSON.stringify(profileData)
        });
    }

    async changePassword(passwordData) {
        return await this.request('/auth/change-password', {
            method: 'POST',
            body: JSON.stringify(passwordData)
        });
    }

    async forgotPassword(email) {
        return await this.request('/auth/forgot-password', {
            method: 'POST',
            body: JSON.stringify({ email }),
            auth: false
        });
    }

    async resetPassword(token, password) {
        return await this.request('/auth/reset-password', {
            method: 'POST',
            body: JSON.stringify({ token, password }),
            auth: false
        });
    }

    // Event Methods
    async getEvents(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return await this.request(`/events?${queryString}`, { auth: false });
    }

    async getEvent(id) {
        return await this.request(`/events/${id}`, { auth: false });
    }

    async createEvent(eventData) {
        return await this.request('/events', {
            method: 'POST',
            body: JSON.stringify(eventData)
        });
    }

    async updateEvent(id, eventData) {
        return await this.request(`/events/${id}`, {
            method: 'PUT',
            body: JSON.stringify(eventData)
        });
    }

    async deleteEvent(id) {
        return await this.request(`/events/${id}`, {
            method: 'DELETE'
        });
    }

    async getOrganizerEvents(params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return await this.request(`/events/organizer/events?${queryString}`);
    }

    async getEventCategories() {
        return await this.request('/events/categories', { auth: false });
    }

    async getVenues(city = null) {
        const params = city ? `?city=${encodeURIComponent(city)}` : '';
        return await this.request(`/events/venues${params}`, { auth: false });
    }

    // Event with file upload
    async createEventWithImages(eventData, images) {
        const formData = new FormData();
        
        // Add event data
        Object.keys(eventData).forEach(key => {
            if (eventData[key] !== null && eventData[key] !== undefined) {
                formData.append(key, eventData[key]);
            }
        });

        // Add images
        if (images && images.length > 0) {
            for (let i = 0; i < images.length; i++) {
                formData.append('images', images[i]);
            }
        }

        const response = await fetch(`${this.baseURL}/events`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`
            },
            body: formData
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message_ar || data.error || 'حدث خطأ في رفع الفعالية');
        }

        return data;
    }

    // Registration Methods
    async registerForEvent(eventId, registrationData) {
        return await this.request(`/registrations/events/${eventId}/register`, {
            method: 'POST',
            body: JSON.stringify(registrationData),
            auth: false
        });
    }

    async getRegistration(id) {
        return await this.request(`/registrations/${id}`, { auth: false });
    }

    async getRegistrationByToken(token) {
        return await this.request(`/registrations/token/${token}`, { auth: false });
    }

    async cancelRegistration(id, email) {
        return await this.request(`/registrations/${id}/cancel`, {
            method: 'PUT',
            body: JSON.stringify({ attendee_email: email }),
            auth: false
        });
    }

    async getRegistrationsByEmail(email) {
        return await this.request(`/registrations/email/${encodeURIComponent(email)}`, { auth: false });
    }

    // Organizer - Event Management
    async getEventRegistrations(eventId, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        return await this.request(`/events/${eventId}/registrations?${queryString}`);
    }

    async getEventStats(eventId) {
        return await this.request(`/events/${eventId}/stats`);
    }

    async updateRegistrationStatus(eventId, registrationId, status) {
        return await this.request(`/events/${eventId}/registrations/${registrationId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });
    }

    async exportEventRegistrations(eventId) {
        const response = await fetch(`${this.baseURL}/events/${eventId}/registrations/export`, {
            headers: {
                'Authorization': `Bearer ${this.token}`
            }
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message_ar || error.error || 'فشل في تصدير البيانات');
        }

        return response.blob();
    }

    // Dashboard Methods
    async getDashboardOverview() {
        return await this.request('/dashboard/overview');
    }

    async getEventsSummary(period = '30') {
        return await this.request(`/dashboard/events-summary?period=${period}`);
    }

    async getRegistrationsAnalytics(period = '30') {
        return await this.request(`/dashboard/registrations-analytics?period=${period}`);
    }

    async getPopularEvents(limit = 10) {
        return await this.request(`/dashboard/popular-events?limit=${limit}`);
    }

    async getRevenueAnalytics(period = '30') {
        return await this.request(`/dashboard/revenue-analytics?period=${period}`);
    }

    // Utility Methods
    isAuthenticated() {
        return !!this.token;
    }

    getCurrentUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    }

    // Health check
    async healthCheck() {
        return await this.request('/health', { auth: false });
    }
}

// Create global API instance
window.api = new FeaalyatiAPI();

// Auto-logout on token expiration
window.addEventListener('storage', (e) => {
    if (e.key === 'authToken' && !e.newValue) {
        // Token was removed, redirect to login if on protected page
        const protectedPages = ['dashboard.html', 'create-event.html', 'my-events.html', 'profile.html'];
        const currentPage = window.location.pathname.split('/').pop();
        
        if (protectedPages.includes(currentPage)) {
            window.location.href = 'login.html';
        }
    }
});

// Check authentication status on page load
document.addEventListener('DOMContentLoaded', () => {
    const protectedPages = ['dashboard.html', 'create-event.html', 'my-events.html', 'profile.html'];
    const authPages = ['login.html', 'signup.html'];
    const currentPage = window.location.pathname.split('/').pop();

    if (protectedPages.includes(currentPage) && !window.api.isAuthenticated()) {
        window.location.href = 'login.html';
    } else if (authPages.includes(currentPage) && window.api.isAuthenticated()) {
        window.location.href = 'dashboard.html';
    }
});
