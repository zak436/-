// RTL Support Example
// This file demonstrates key considerations for RTL in React components

import React from 'react';
import { useRouter } from 'next/router';
import dayjs from 'dayjs';
import 'dayjs/locale/ar';

// Set Arabic locale for dayjs
dayjs.locale('ar');

// Example component showing RTL considerations
export default function RTLExample() {
  return (
    <div className="rtl-demo p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-primary">مثال على دعم الاتجاه من اليمين إلى اليسار (RTL)</h2>
      
      {/* 1. Text alignment */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">محاذاة النص</h3>
        <p className="text-right mb-2">
          هذا النص محاذى إلى اليمين بشكل صحيح للغة العربية. لاحظ أن الفقرات العربية تبدأ من اليمين.
        </p>
        <div className="bg-gray-100 p-4 rounded mb-2 text-left">
          This is left-aligned English text for comparison.
        </div>
        <div className="bg-gray-100 p-4 rounded text-right">
          هذا مثال على كيفية التعامل مع النص المختلط:
          <span className="inline-block" dir="ltr">example@email.com</span>
          أو أرقام مثل <span className="inline-block" dir="ltr">+966 12 345 6789</span>
        </div>
      </section>
      
      {/* 2. Margins and Padding */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">الهوامش والحشو</h3>
        <div className="flex items-center mb-4">
          <div className="bg-primary text-white p-2 rounded-md">
            <span>عنصر</span>
          </div>
          {/* In RTL, we use mr instead of ml for spacing */}
          <div className="mr-4 bg-secondary text-white p-2 rounded-md">
            <span>عنصر مع هامش يمين</span>
          </div>
        </div>
        <p className="text-sm text-gray-600">
          لاحظ استخدام فئة Tailwind <code dir="ltr">mr-4</code> (margin-right) بدلاً من <code dir="ltr">ml-4</code> (margin-left) في الاتجاه RTL.
        </p>
      </section>
      
      {/* 3. Icon Directionality */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">اتجاه الأيقونات</h3>
        <div className="flex flex-col space-y-4">
          <button className="flex items-center bg-primary text-white px-4 py-2 rounded-md w-fit">
            <span>التالي</span>
            {/* Icons need to be flipped for RTL */}
            <svg className="mr-2 h-5 w-5 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </button>
          
          <button className="flex items-center bg-primary text-white px-4 py-2 rounded-md w-fit">
            <svg className="ml-2 h-5 w-5 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>السابق</span>
          </button>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          لاحظ استخدام <code dir="ltr">transform rotate-180</code> لعكس اتجاه أيقونات الأسهم.
        </p>
      </section>
      
      {/* 4. Form Layout */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">تخطيط النماذج</h3>
        <form className="space-y-4">
          <div className="text-right">
            <label htmlFor="name" className="block mb-1 font-medium">الاسم</label>
            <input 
              type="text" 
              id="name" 
              className="w-full p-2 border border-gray-300 rounded-md text-right"
              placeholder="أدخل اسمك"
            />
          </div>
          
          <div className="text-right">
            <label htmlFor="phone" className="block mb-1 font-medium">رقم الهاتف</label>
            <input 
              type="tel" 
              id="phone"
              dir="ltr" // Force LTR for phone numbers
              className="w-full p-2 border border-gray-300 rounded-md text-left"
              placeholder="+966 XX XXX XXXX"
            />
          </div>
          
          <div className="flex items-center">
            <input type="checkbox" id="agree" className="ml-2" />
            <label htmlFor="agree">أوافق على الشروط والأحكام</label>
          </div>
        </form>
      </section>
      
      {/* 5. Date Formatting */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">تنسيق التاريخ</h3>
        <div className="space-y-2">
          <p>
            <span className="font-medium">التاريخ الحالي:</span> {dayjs().format('D MMMM YYYY')}
          </p>
          <p>
            <span className="font-medium">تاريخ فعالية:</span> {dayjs('2024-07-15').format('D MMMM YYYY')}
          </p>
          <p>
            <span className="font-medium">متى سيبدأ:</span> {dayjs('2024-07-15').fromNow()}
          </p>
        </div>
      </section>
      
      {/* 6. Flex Direction */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">اتجاه العناصر المرنة (Flex)</h3>
        <div className="flex items-center justify-end mb-4">
          <span className="text-sm text-gray-600 ml-2">تصاعدي</span>
          <div className="flex items-center space-x-reverse space-x-1">
            <div className="w-4 h-4 bg-gray-200 rounded-full"></div>
            <div className="w-4 h-4 bg-gray-300 rounded-full"></div>
            <div className="w-4 h-4 bg-gray-400 rounded-full"></div>
            <div className="w-4 h-4 bg-gray-500 rounded-full"></div>
            <div className="w-4 h-4 bg-gray-600 rounded-full"></div>
          </div>
        </div>
        <p className="text-sm text-gray-600">
          لاحظ استخدام <code dir="ltr">space-x-reverse</code> مع <code dir="ltr">space-x-1</code> لضبط المساحات بشكل صحيح.
        </p>
      </section>
      
      {/* 7. Grid Layout */}
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">تخطيط الشبكة (Grid)</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-primary-light p-4 rounded text-center text-white">1</div>
          <div className="bg-primary p-4 rounded text-center text-white">2</div>
          <div className="bg-primary-dark p-4 rounded text-center text-white">3</div>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          لاحظ أن تخطيط الشبكة يعمل بشكل طبيعي بغض النظر عن اتجاه RTL أو LTR.
        </p>
      </section>
      
      {/* Tips and Best Practices */}
      <section className="bg-blue-50 p-4 rounded-lg">
        <h3 className="text-lg font-semibold mb-2 text-blue-800">نصائح وأفضل الممارسات</h3>
        <ul className="list-disc list-inside space-y-2 text-blue-700">
          <li>استخدم <code dir="ltr">dir="rtl"</code> على مستوى HTML لضبط اتجاه المستند بالكامل</li>
          <li>استخدم <code dir="ltr">text-right</code> للمحتوى العربي و <code dir="ltr">text-left</code> للمحتوى الإنجليزي</li>
          <li>ضع <code dir="ltr">dir="ltr"</code> للعناصر التي يجب أن تظل LTR مثل البريد الإلكتروني وأرقام الهواتف</li>
          <li>اعكس الأيقونات التي تشير إلى اليمين/اليسار في واجهة المستخدم</li>
          <li>استخدم <code dir="ltr">space-x-reverse</code> مع flex containers</li>
          <li>استخدم <code dir="ltr">mr-X</code> بدلاً من <code dir="ltr">ml-X</code> للهوامش بين العناصر</li>
        </ul>
      </section>
    </div>
  );
}

// Helper function for detecting text direction
export function getTextDirection(text) {
  // RTL characters ranges
  const rtlChars = /[\u0591-\u07FF\u200F\u202B\u202E\uFB1D-\uFDFD\uFE70-\uFEFC]/;
  return rtlChars.test(text) ? 'rtl' : 'ltr';
}

// Component to automatically set direction based on content
export function AutoDirectionText({ children, className = '', ...props }) {
  const direction = getTextDirection(children);
  
  return (
    <span dir={direction} className={className} {...props}>
      {children}
    </span>
  );
}