const Event = require('../models/Event');
const Registration = require('../models/Registration');
const { uploadEventImages } = require('../utils/upload');

class EventController {
  // Create new event
  static async create(req, res) {
    try {
      const organizerId = req.userId;
      const eventData = req.body;

      // Handle image uploads if present
      if (req.files && req.files.length > 0) {
        const imageUrls = req.files.map(file => `/uploads/events/${file.filename}`);
        eventData.images = imageUrls;
      }

      const eventId = await Event.create(eventData, organizerId);

      res.status(201).json({
        message: 'Event created successfully',
        message_ar: 'تم إنشاء الفعالية بنجاح',
        event_id: eventId
      });

    } catch (error) {
      console.error('Create event error:', error);
      res.status(500).json({
        error: 'Failed to create event',
        message_ar: 'فشل في إنشاء الفعالية'
      });
    }
  }

  // Get event by ID
  static async getById(req, res) {
    try {
      const { id } = req.params;
      const includeOrganizer = req.query.include_organizer === 'true';

      const event = await Event.findById(id, includeOrganizer);

      if (!event) {
        return res.status(404).json({
          error: 'Event not found',
          message_ar: 'الفعالية غير موجودة'
        });
      }

      // Increment view count if not the organizer viewing
      if (!req.user || req.user.id !== event.organizer_id) {
        await Event.incrementViews(id);
      }

      res.json({
        event
      });

    } catch (error) {
      console.error('Get event error:', error);
      res.status(500).json({
        error: 'Failed to get event',
        message_ar: 'فشل في جلب الفعالية'
      });
    }
  }

  // Get events with filtering and pagination
  static async getMany(req, res) {
    try {
      const filters = {
        category_id: req.query.category,
        status: req.query.status || 'published',
        search: req.query.search,
        event_type: req.query.type,
        is_free: req.query.is_free ? req.query.is_free === 'true' : undefined,
        start_date_from: req.query.date_from,
        start_date_to: req.query.date_to,
        featured: req.query.featured ? req.query.featured === 'true' : undefined
      };

      const pagination = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 10,
        sort: req.query.sort || 'start_date',
        order: req.query.order || 'ASC'
      };

      const result = await Event.findMany(filters, pagination);

      res.json(result);

    } catch (error) {
      console.error('Get events error:', error);
      res.status(500).json({
        error: 'Failed to get events',
        message_ar: 'فشل في جلب الفعاليات'
      });
    }
  }

  // Get organizer's events
  static async getOrganizerEvents(req, res) {
    try {
      const organizerId = req.userId;
      
      const filters = {
        organizer_id: organizerId,
        status: req.query.status,
        search: req.query.search,
        event_type: req.query.type
      };

      const pagination = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 10,
        sort: req.query.sort || 'created_at',
        order: req.query.order || 'DESC'
      };

      const result = await Event.findMany(filters, pagination);

      res.json(result);

    } catch (error) {
      console.error('Get organizer events error:', error);
      res.status(500).json({
        error: 'Failed to get organizer events',
        message_ar: 'فشل في جلب فعاليات المنظم'
      });
    }
  }

  // Update event
  static async update(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;
      const updateData = req.body;

      // Handle image uploads if present
      if (req.files && req.files.length > 0) {
        const imageUrls = req.files.map(file => `/uploads/events/${file.filename}`);
        updateData.images = imageUrls;
      }

      const success = await Event.update(id, updateData, organizerId);

      if (!success) {
        return res.status(404).json({
          error: 'Event not found or you do not have permission to update it',
          message_ar: 'الفعالية غير موجودة أو ليس لديك صلاحية لتحديثها'
        });
      }

      res.json({
        message: 'Event updated successfully',
        message_ar: 'تم تحديث الفعالية بنجاح'
      });

    } catch (error) {
      console.error('Update event error:', error);
      res.status(500).json({
        error: 'Failed to update event',
        message_ar: 'فشل في تحديث الفعالية'
      });
    }
  }

  // Delete event
  static async delete(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;

      const success = await Event.delete(id, organizerId);

      if (!success) {
        return res.status(404).json({
          error: 'Event not found or you do not have permission to delete it',
          message_ar: 'الفعالية غير موجودة أو ليس لديك صلاحية لحذفها'
        });
      }

      res.json({
        message: 'Event deleted successfully',
        message_ar: 'تم حذف الفعالية بنجاح'
      });

    } catch (error) {
      console.error('Delete event error:', error);
      res.status(500).json({
        error: 'Failed to delete event',
        message_ar: 'فشل في حذف الفعالية'
      });
    }
  }

  // Get event categories
  static async getCategories(req, res) {
    try {
      const categories = await Event.getCategories();

      res.json({
        categories
      });

    } catch (error) {
      console.error('Get categories error:', error);
      res.status(500).json({
        error: 'Failed to get categories',
        message_ar: 'فشل في جلب التصنيفات'
      });
    }
  }

  // Get venues
  static async getVenues(req, res) {
    try {
      const { city } = req.query;
      const venues = await Event.getVenues(city);

      res.json({
        venues
      });

    } catch (error) {
      console.error('Get venues error:', error);
      res.status(500).json({
        error: 'Failed to get venues',
        message_ar: 'فشل في جلب الأماكن'
      });
    }
  }

  // Get event registrations (for organizers)
  static async getEventRegistrations(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;

      const filters = {
        status: req.query.status,
        search: req.query.search,
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 50
      };

      const result = await Registration.getEventRegistrations(id, organizerId, filters);

      res.json(result);

    } catch (error) {
      console.error('Get event registrations error:', error);
      res.status(500).json({
        error: 'Failed to get event registrations',
        message_ar: 'فشل في جلب تسجيلات الفعالية'
      });
    }
  }

  // Get event statistics
  static async getEventStats(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;

      const stats = await Registration.getEventStats(id, organizerId);

      res.json({
        stats
      });

    } catch (error) {
      console.error('Get event stats error:', error);
      res.status(500).json({
        error: 'Failed to get event statistics',
        message_ar: 'فشل في جلب إحصائيات الفعالية'
      });
    }
  }

  // Update registration status
  static async updateRegistrationStatus(req, res) {
    try {
      const { id, registrationId } = req.params;
      const { status } = req.body;
      const organizerId = req.userId;

      const success = await Registration.updateStatus(registrationId, status, organizerId);

      if (!success) {
        return res.status(404).json({
          error: 'Registration not found or you do not have permission to update it',
          message_ar: 'التسجيل غير موجود أو ليس لديك صلاحية لتحديثه'
        });
      }

      // Update event registration count
      await Event.updateRegistrationCount(id);

      res.json({
        message: 'Registration status updated successfully',
        message_ar: 'تم تحديث حالة التسجيل بنجاح'
      });

    } catch (error) {
      console.error('Update registration status error:', error);
      res.status(500).json({
        error: 'Failed to update registration status',
        message_ar: 'فشل في تحديث حالة التسجيل'
      });
    }
  }

  // Export event registrations
  static async exportRegistrations(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;

      const registrations = await Registration.exportRegistrations(id, organizerId);

      if (registrations.length === 0) {
        return res.status(404).json({
          error: 'No registrations found for this event',
          message_ar: 'لا توجد تسجيلات لهذه الفعالية'
        });
      }

      // Set headers for CSV download
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="event-${id}-registrations.csv"`);

      // Create CSV content
      const headers = [
        'اسم المسجل',
        'البريد الإلكتروني',
        'رقم الهاتف',
        'المؤسسة',
        'الحالة',
        'حالة الدفع',
        'المبلغ',
        'تاريخ التسجيل',
        'تاريخ التأكيد',
        'تاريخ الحضور'
      ];

      let csvContent = '\uFEFF' + headers.join(',') + '\n'; // BOM for UTF-8

      registrations.forEach(reg => {
        const row = [
          `"${reg.attendee_name || ''}"`,
          `"${reg.attendee_email || ''}"`,
          `"${reg.attendee_phone || ''}"`,
          `"${reg.attendee_organization || ''}"`,
          `"${reg.status || ''}"`,
          `"${reg.payment_status || ''}"`,
          `"${reg.payment_amount || 0}"`,
          `"${reg.registered_at ? new Date(reg.registered_at).toLocaleString('ar-SA') : ''}"`,
          `"${reg.confirmed_at ? new Date(reg.confirmed_at).toLocaleString('ar-SA') : ''}"`,
          `"${reg.attended_at ? new Date(reg.attended_at).toLocaleString('ar-SA') : ''}"`
        ];
        csvContent += row.join(',') + '\n';
      });

      res.send(csvContent);

    } catch (error) {
      console.error('Export registrations error:', error);
      res.status(500).json({
        error: 'Failed to export registrations',
        message_ar: 'فشل في تصدير التسجيلات'
      });
    }
  }

  // Get upcoming events for organizer
  static async getUpcomingEvents(req, res) {
    try {
      const organizerId = req.userId;
      const limit = parseInt(req.query.limit) || 5;

      const events = await Event.getUpcomingEvents(organizerId, limit);

      res.json({
        events
      });

    } catch (error) {
      console.error('Get upcoming events error:', error);
      res.status(500).json({
        error: 'Failed to get upcoming events',
        message_ar: 'فشل في جلب الفعاليات القادمة'
      });
    }
  }

  // Get event analytics
  static async getEventAnalytics(req, res) {
    try {
      const { id } = req.params;
      const organizerId = req.userId;

      const analytics = await Event.getAnalytics(id, organizerId);

      res.json({
        analytics
      });

    } catch (error) {
      console.error('Get event analytics error:', error);
      res.status(500).json({
        error: 'Failed to get event analytics',
        message_ar: 'فشل في جلب تحليلات الفعالية'
      });
    }
  }
}

module.exports = EventController;
