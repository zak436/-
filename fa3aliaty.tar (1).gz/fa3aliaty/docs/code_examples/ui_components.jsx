// UI Components Examples using React and Tailwind CSS
// These are reusable components that follow the UI/UX guidelines

// Button Component with different variants
import React from 'react';
import { cva } from 'class-variance-authority';

// Button variants using class-variance-authority for flexibility
const buttonVariants = cva(
  "rounded-full font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all duration-300 inline-flex items-center justify-center",
  {
    variants: {
      intent: {
        primary: "bg-primary text-white hover:bg-primary-dark focus:ring-primary",
        secondary: "bg-white border-2 border-primary text-primary hover:bg-primary hover:text-white focus:ring-primary",
        danger: "bg-red-600 text-white hover:bg-red-700 focus:ring-red-500",
        success: "bg-green-600 text-white hover:bg-green-700 focus:ring-green-500",
      },
      size: {
        sm: "text-sm py-1.5 px-3",
        md: "text-base py-2 px-5",
        lg: "text-lg py-3 px-8",
      },
      fullWidth: {
        true: "w-full",
        false: "",
      },
      disabled: {
        true: "opacity-50 cursor-not-allowed",
        false: "",
      },
    },
    defaultVariants: {
      intent: "primary",
      size: "md",
      fullWidth: false,
      disabled: false,
    },
  }
);

export const Button = ({
  children,
  intent,
  size,
  fullWidth,
  disabled,
  className,
  ...props
}) => {
  return (
    <button
      className={buttonVariants({ intent, size, fullWidth, disabled, className })}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
};

// Form Input Component with RTL support
export const Input = ({
  label,
  id,
  error,
  helperText,
  icon,
  ...props
}) => {
  return (
    <div className="mb-4 text-right">
      {label && (
        <label htmlFor={id} className="block mb-2 font-semibold text-gray-700">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            {icon}
          </div>
        )}
        <input
          id={id}
          className={`
            w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 transition-colors
            ${icon ? 'pr-10' : ''}
            ${error 
              ? 'border-red-500 focus:border-red-500 focus:ring-red-200' 
              : 'border-gray-300 focus:border-primary focus:ring-primary-light'}
          `}
          dir="rtl"
          {...props}
        />
      </div>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
      {helperText && !error && <p className="mt-1 text-sm text-gray-500">{helperText}</p>}
    </div>
  );
};

// Select Component with RTL support
export const Select = ({
  label,
  id,
  options,
  error,
  helperText,
  ...props
}) => {
  return (
    <div className="mb-4 text-right">
      {label && (
        <label htmlFor={id} className="block mb-2 font-semibold text-gray-700">
          {label}
        </label>
      )}
      <select
        id={id}
        className={`
          w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 transition-colors
          ${error 
            ? 'border-red-500 focus:border-red-500 focus:ring-red-200' 
            : 'border-gray-300 focus:border-primary focus:ring-primary-light'}
        `}
        dir="rtl"
        {...props}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
      {helperText && !error && <p className="mt-1 text-sm text-gray-500">{helperText}</p>}
    </div>
  );
};

// Confirmation Modal Component
export const ConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "تأكيد",
  cancelText = "إلغاء",
  variant = "danger"
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="w-full max-w-md p-6 mx-auto bg-white rounded-lg shadow-lg" onClick={(e) => e.stopPropagation()}>
        <h2 className="mb-4 text-xl font-bold text-gray-800">{title}</h2>
        <p className="mb-6 text-gray-600">{message}</p>
        <div className="flex justify-end space-x-4 space-x-reverse">
          <Button
            intent="secondary"
            onClick={onClose}
          >
            {cancelText}
          </Button>
          <Button
            intent={variant}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmText}
          </Button>
        </div>
      </div>
    </div>
  );
};

// Card Component for Events
export const EventCard = ({
  title,
  date,
  location,
  imageUrl,
  status,
  attendeeCount,
  onClick
}) => {
  const statusColors = {
    upcoming: 'bg-blue-100 text-blue-800',
    ongoing: 'bg-green-100 text-green-800',
    completed: 'bg-gray-100 text-gray-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  return (
    <div className="overflow-hidden transition-transform bg-white rounded-lg shadow-md hover:shadow-lg hover:-translate-y-1" onClick={onClick}>
      {imageUrl && (
        <div className="h-48 overflow-hidden">
          <img src={imageUrl} alt={title} className="object-cover w-full h-full" />
        </div>
      )}
      <div className="p-4">
        <div className="flex justify-between mb-2">
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[status] || statusColors.upcoming}`}>
            {status === 'upcoming' && 'قادمة'}
            {status === 'ongoing' && 'جارية'}
            {status === 'completed' && 'مكتملة'}
            {status === 'cancelled' && 'ملغية'}
          </span>
          {attendeeCount !== undefined && (
            <span className="flex items-center text-sm text-gray-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              {attendeeCount}
            </span>
          )}
        </div>
        <h3 className="mb-2 text-lg font-bold text-gray-800">{title}</h3>
        {date && (
          <div className="flex items-center mb-1 text-sm text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            {date}
          </div>
        )}
        {location && (
          <div className="flex items-center mb-3 text-sm text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            {location}
          </div>
        )}
        <Button intent="primary" size="sm" fullWidth>
          عرض التفاصيل
        </Button>
      </div>
    </div>
  );
};

// Pagination Component
export const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  // Generate array of page numbers to display
  const getPageNumbers = () => {
    const pages = [];
    
    // Always show first page
    pages.push(1);
    
    // Calculate range around current page
    let rangeStart = Math.max(2, currentPage - 1);
    let rangeEnd = Math.min(totalPages - 1, currentPage + 1);
    
    // Add ellipsis after first page if needed
    if (rangeStart > 2) {
      pages.push('...');
    }
    
    // Add pages in range
    for (let i = rangeStart; i <= rangeEnd; i++) {
      pages.push(i);
    }
    
    // Add ellipsis before last page if needed
    if (rangeEnd < totalPages - 1) {
      pages.push('...');
    }
    
    // Always show last page if there's more than one page
    if (totalPages > 1) {
      pages.push(totalPages);
    }
    
    return pages;
  };
  
  return (
    <div className="flex justify-center mt-8 space-x-2 space-x-reverse rtl">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <span className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
          السابق
        </span>
      </button>
      
      {getPageNumbers().map((page, index) => (
        <button
          key={index}
          onClick={() => typeof page === 'number' ? onPageChange(page) : null}
          disabled={page === '...'}
          className={`px-3 py-2 text-sm font-medium border rounded-md
            ${page === currentPage
              ? 'border-primary bg-primary text-white'
              : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'}
            ${page === '...' ? 'cursor-default' : ''}
          `}
        >
          {page}
        </button>
      ))}
      
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <span className="flex items-center">
          التالي
          <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </span>
      </button>
    </div>
  );
};