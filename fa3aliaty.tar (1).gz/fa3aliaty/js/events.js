// Events listing and management
document.addEventListener('DOMContentLoaded', function() {
    // Load events on page load
    loadEvents();
    
    // Search functionality
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = document.querySelector('.search-input').value;
            loadEvents({ search: searchTerm });
        });
    }
    
    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            loadEvents({ category: category !== 'all' ? category : null });
        });
    });
    
    // Load categories for filters
    loadCategories();
});

// Load events from API
async function loadEvents(filters = {}) {
    try {
        showLoadingState();
        
        const params = {
            page: filters.page || 1,
            limit: filters.limit || 12,
            search: filters.search,
            category: filters.category,
            status: 'published',
            sort: 'start_date',
            order: 'ASC'
        };
        
        // Remove undefined values
        Object.keys(params).forEach(key => {
            if (params[key] === undefined || params[key] === null) {
                delete params[key];
            }
        });
        
        const response = await window.api.getEvents(params);
        displayEvents(response.events);
        displayPagination(response.pagination);
        
    } catch (error) {
        console.error('Error loading events:', error);
        showErrorState('فشل في تحميل الفعاليات');
    }
}

// Display events in the grid
function displayEvents(events) {
    const eventsContainer = document.querySelector('.events-grid') || 
                           document.querySelector('.featured-events') ||
                           document.querySelector('.events-container');
    
    if (!eventsContainer) {
        console.error('Events container not found');
        return;
    }
    
    if (!events || events.length === 0) {
        eventsContainer.innerHTML = `
            <div class="no-events">
                <i class="fas fa-calendar-times"></i>
                <h3>لا توجد فعاليات</h3>
                <p>لم يتم العثور على فعاليات تطابق البحث</p>
            </div>
        `;
        return;
    }
    
    const eventsHTML = events.map(event => createEventCard(event)).join('');
    eventsContainer.innerHTML = eventsHTML;
    
    // Add click events to event cards
    addEventCardListeners();
}

// Create event card HTML
function createEventCard(event) {
    const eventDate = new Date(event.start_date);
    const formattedDate = eventDate.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    const formattedTime = eventDate.toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const imageUrl = event.images && event.images.length > 0 
        ? event.images[0] 
        : 'images/default-event.jpg';
    
    const priceText = event.is_free ? 'مجاني' : `${event.price} ريال`;
    
    return `
        <div class="event-card" data-event-id="${event.id}">
            <div class="event-image">
                <img src="${imageUrl}" alt="${event.title_ar}" onerror="this.src='images/default-event.jpg'">
                <div class="event-badge ${event.is_free ? 'free' : 'paid'}">${priceText}</div>
                ${event.featured ? '<div class="featured-badge">مميز</div>' : ''}
            </div>
            <div class="event-content">
                <div class="event-category">${event.category_name_ar || 'فعالية'}</div>
                <h3 class="event-title">${event.title_ar}</h3>
                <p class="event-description">${event.short_description_ar || event.description_ar?.substring(0, 100) + '...' || ''}</p>
                
                <div class="event-details">
                    <div class="event-date">
                        <i class="fas fa-calendar"></i>
                        <span>${formattedDate}</span>
                    </div>
                    <div class="event-time">
                        <i class="fas fa-clock"></i>
                        <span>${formattedTime}</span>
                    </div>
                    ${event.venue_name_ar ? `
                        <div class="event-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${event.venue_name_ar}</span>
                        </div>
                    ` : ''}
                </div>
                
                <div class="event-stats">
                    <span class="registrations">
                        <i class="fas fa-users"></i>
                        ${event.registration_count || 0} مسجل
                    </span>
                    <span class="views">
                        <i class="fas fa-eye"></i>
                        ${event.views_count || 0} مشاهدة
                    </span>
                </div>
                
                <div class="event-actions">
                    <button class="btn btn-primary register-btn" data-event-id="${event.id}">
                        سجل الآن
                    </button>
                    <button class="btn btn-outline view-details-btn" data-event-id="${event.id}">
                        عرض التفاصيل
                    </button>
                </div>
            </div>
        </div>
    `;
}

// Add event listeners to event cards
function addEventCardListeners() {
    // View details buttons
    const viewDetailsButtons = document.querySelectorAll('.view-details-btn');
    viewDetailsButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const eventId = this.getAttribute('data-event-id');
            window.location.href = `event-detail.html?id=${eventId}`;
        });
    });
    
    // Register buttons
    const registerButtons = document.querySelectorAll('.register-btn');
    registerButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const eventId = this.getAttribute('data-event-id');
            window.location.href = `register.html?event=${eventId}`;
        });
    });
    
    // Event card click
    const eventCards = document.querySelectorAll('.event-card');
    eventCards.forEach(card => {
        card.addEventListener('click', function() {
            const eventId = this.getAttribute('data-event-id');
            window.location.href = `event-detail.html?id=${eventId}`;
        });
    });
}

// Load categories for filters
async function loadCategories() {
    try {
        const response = await window.api.getEventCategories();
        displayCategoryFilters(response.categories);
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Display category filters
function displayCategoryFilters(categories) {
    const filtersContainer = document.querySelector('.event-filters');
    if (!filtersContainer || !categories) return;
    
    const filtersHTML = `
        <button class="filter-btn active" data-category="all">الكل</button>
        ${categories.map(category => `
            <button class="filter-btn" data-category="${category.id}">
                ${category.name_ar}
            </button>
        `).join('')}
    `;
    
    filtersContainer.innerHTML = filtersHTML;
    
    // Re-add event listeners
    const filterButtons = filtersContainer.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            loadEvents({ category: category !== 'all' ? category : null });
        });
    });
}

// Display pagination
function displayPagination(pagination) {
    const paginationContainer = document.querySelector('.pagination');
    if (!paginationContainer || !pagination) return;
    
    const { page, totalPages, hasNext, hasPrev } = pagination;
    
    let paginationHTML = '';
    
    // Previous button
    if (hasPrev) {
        paginationHTML += `<button class="pagination-btn" data-page="${page - 1}">السابق</button>`;
    }
    
    // Page numbers
    for (let i = Math.max(1, page - 2); i <= Math.min(totalPages, page + 2); i++) {
        paginationHTML += `
            <button class="pagination-btn ${i === page ? 'active' : ''}" data-page="${i}">
                ${i}
            </button>
        `;
    }
    
    // Next button
    if (hasNext) {
        paginationHTML += `<button class="pagination-btn" data-page="${page + 1}">التالي</button>`;
    }
    
    paginationContainer.innerHTML = paginationHTML;
    
    // Add click events
    const paginationButtons = paginationContainer.querySelectorAll('.pagination-btn');
    paginationButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const newPage = parseInt(this.getAttribute('data-page'));
            loadEvents({ page: newPage });
        });
    });
}

// Show loading state
function showLoadingState() {
    const eventsContainer = document.querySelector('.events-grid') || 
                           document.querySelector('.featured-events') ||
                           document.querySelector('.events-container');
    
    if (eventsContainer) {
        eventsContainer.innerHTML = `
            <div class="loading-state">
                <i class="fas fa-spinner fa-spin"></i>
                <p>جاري تحميل الفعاليات...</p>
            </div>
        `;
    }
}

// Show error state
function showErrorState(message) {
    const eventsContainer = document.querySelector('.events-grid') || 
                           document.querySelector('.featured-events') ||
                           document.querySelector('.events-container');
    
    if (eventsContainer) {
        eventsContainer.innerHTML = `
            <div class="error-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>خطأ في التحميل</h3>
                <p>${message}</p>
                <button class="btn btn-primary" onclick="loadEvents()">إعادة المحاولة</button>
            </div>
        `;
    }
}
