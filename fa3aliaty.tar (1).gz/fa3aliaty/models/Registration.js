const { getOne, getMany, insert, update, remove } = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class Registration {
  // Create a new registration
  static async create(registrationData) {
    const {
      event_id,
      attendee_name,
      attendee_email,
      attendee_phone,
      attendee_organization,
      registration_data,
      payment_amount = 0
    } = registrationData;

    // Generate confirmation token and QR code
    const confirmation_token = uuidv4();
    const qr_code = `event-${event_id}-${confirmation_token}`;

    const query = `
      INSERT INTO event_registrations (
        event_id, attendee_name, attendee_email, attendee_phone,
        attendee_organization, registration_data, payment_amount,
        confirmation_token, qr_code
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const registrationId = await insert(query, [
      event_id,
      attendee_name,
      attendee_email,
      attendee_phone,
      attendee_organization,
      JSON.stringify(registration_data),
      payment_amount,
      confirmation_token,
      qr_code
    ]);

    return { id: registrationId, confirmation_token, qr_code };
  }

  // Find registration by ID
  static async findById(id) {
    const query = `
      SELECT r.*, 
             e.title_ar as event_title_ar, e.title_en as event_title_en,
             e.start_date, e.end_date, e.organizer_id,
             v.name_ar as venue_name_ar, v.address_ar as venue_address_ar
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      LEFT JOIN venues v ON e.venue_id = v.id
      WHERE r.id = ?
    `;

    const registration = await getOne(query, [id]);

    if (registration && registration.registration_data) {
      registration.registration_data = this.parseJSON(registration.registration_data);
    }

    return registration;
  }

  // Find registration by confirmation token
  static async findByToken(token) {
    const query = `
      SELECT r.*, 
             e.title_ar as event_title_ar, e.title_en as event_title_en,
             e.start_date, e.end_date
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE r.confirmation_token = ?
    `;

    const registration = await getOne(query, [token]);

    if (registration && registration.registration_data) {
      registration.registration_data = this.parseJSON(registration.registration_data);
    }

    return registration;
  }

  // Get registrations for an event (for organizers)
  static async getEventRegistrations(eventId, organizerId, filters = {}) {
    const { status, search, page = 1, limit = 50 } = filters;

    let whereConditions = ['r.event_id = ?', 'e.organizer_id = ?'];
    let params = [eventId, organizerId];

    if (status) {
      whereConditions.push('r.status = ?');
      params.push(status);
    }

    if (search) {
      whereConditions.push('(r.attendee_name LIKE ? OR r.attendee_email LIKE ? OR r.attendee_organization LIKE ?)');
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    let query = `
      SELECT r.id, r.attendee_name, r.attendee_email, r.attendee_phone,
             r.attendee_organization, r.status, r.payment_status, r.payment_amount,
             r.registered_at, r.confirmed_at, r.attended_at, r.qr_code
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY r.registered_at DESC
    `;

    // Add pagination
    const offset = (page - 1) * limit;
    query += ' LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const registrations = await getMany(query, params);

    // Get total count
    let countQuery = `
      SELECT COUNT(*) as total
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE ${whereConditions.join(' AND ')}
    `;

    const countParams = params.slice(0, -2); // Remove limit and offset
    const totalResult = await getOne(countQuery, countParams);
    const total = totalResult.total;

    return {
      registrations,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    };
  }

  // Update registration status
  static async updateStatus(id, status, organizerId = null) {
    let query = 'UPDATE event_registrations SET status = ?';
    let params = [status];

    // Add timestamp based on status
    if (status === 'confirmed') {
      query += ', confirmed_at = NOW()';
    } else if (status === 'attended') {
      query += ', attended_at = NOW()';
    }

    query += ' WHERE id = ?';
    params.push(id);

    // If organizer ID is provided, ensure they own the event
    if (organizerId) {
      query += ' AND event_id IN (SELECT id FROM events WHERE organizer_id = ?)';
      params.push(organizerId);
    }

    const affectedRows = await update(query, params);
    return affectedRows > 0;
  }

  // Update payment status
  static async updatePaymentStatus(id, paymentStatus, paymentReference = null) {
    let query = 'UPDATE event_registrations SET payment_status = ?';
    let params = [paymentStatus];

    if (paymentReference) {
      query += ', payment_reference = ?';
      params.push(paymentReference);
    }

    query += ' WHERE id = ?';
    params.push(id);

    const affectedRows = await update(query, params);
    return affectedRows > 0;
  }

  // Cancel registration
  static async cancel(id, attendeeEmail = null) {
    let query = 'UPDATE event_registrations SET status = "cancelled" WHERE id = ?';
    let params = [id];

    // If attendee email is provided, ensure they own the registration
    if (attendeeEmail) {
      query += ' AND attendee_email = ?';
      params.push(attendeeEmail);
    }

    const affectedRows = await update(query, params);
    return affectedRows > 0;
  }

  // Check if user is already registered for an event
  static async isRegistered(eventId, attendeeEmail) {
    const query = `
      SELECT id, status 
      FROM event_registrations 
      WHERE event_id = ? AND attendee_email = ? AND status != 'cancelled'
    `;
    
    const registration = await getOne(query, [eventId, attendeeEmail]);
    return registration;
  }

  // Get registration statistics for an event
  static async getEventStats(eventId, organizerId) {
    const query = `
      SELECT 
        COUNT(*) as total_registrations,
        COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_registrations,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_registrations,
        COUNT(CASE WHEN status = 'attended' THEN 1 END) as attended_registrations,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_registrations,
        COUNT(CASE WHEN payment_status = 'paid' THEN 1 END) as paid_registrations,
        COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN payment_amount ELSE 0 END), 0) as total_revenue
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE r.event_id = ? AND e.organizer_id = ?
    `;

    const stats = await getOne(query, [eventId, organizerId]);
    return stats || {
      total_registrations: 0,
      confirmed_registrations: 0,
      pending_registrations: 0,
      attended_registrations: 0,
      cancelled_registrations: 0,
      paid_registrations: 0,
      total_revenue: 0
    };
  }

  // Get registrations by attendee email
  static async getByAttendeeEmail(email, filters = {}) {
    const { status, upcoming_only = false } = filters;

    let whereConditions = ['r.attendee_email = ?'];
    let params = [email];

    if (status) {
      whereConditions.push('r.status = ?');
      params.push(status);
    }

    if (upcoming_only) {
      whereConditions.push('e.start_date > NOW()');
    }

    const query = `
      SELECT r.id, r.status, r.payment_status, r.registered_at, r.confirmation_token,
             e.id as event_id, e.title_ar, e.title_en, e.start_date, e.end_date,
             e.is_online, e.meeting_url,
             v.name_ar as venue_name_ar, v.address_ar as venue_address_ar
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      LEFT JOIN venues v ON e.venue_id = v.id
      WHERE ${whereConditions.join(' AND ')}
      ORDER BY e.start_date ASC
    `;

    return await getMany(query, params);
  }

  // Bulk update registration status (for check-in)
  static async bulkUpdateStatus(registrationIds, status, organizerId) {
    if (!registrationIds || registrationIds.length === 0) {
      return 0;
    }

    const placeholders = registrationIds.map(() => '?').join(',');
    let query = `UPDATE event_registrations SET status = ?`;
    let params = [status];

    if (status === 'attended') {
      query += ', attended_at = NOW()';
    }

    query += ` WHERE id IN (${placeholders})`;
    params.push(...registrationIds);

    // Ensure organizer owns the events
    query += ' AND event_id IN (SELECT id FROM events WHERE organizer_id = ?)';
    params.push(organizerId);

    const affectedRows = await update(query, params);
    return affectedRows;
  }

  // Helper method to safely parse JSON
  static parseJSON(jsonString) {
    if (!jsonString) return null;
    try {
      return JSON.parse(jsonString);
    } catch (error) {
      console.error('Error parsing JSON:', error);
      return null;
    }
  }

  // Export registrations to CSV format (returns data, not file)
  static async exportRegistrations(eventId, organizerId) {
    const query = `
      SELECT r.attendee_name, r.attendee_email, r.attendee_phone,
             r.attendee_organization, r.status, r.payment_status,
             r.payment_amount, r.registered_at, r.confirmed_at, r.attended_at
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE r.event_id = ? AND e.organizer_id = ?
      ORDER BY r.registered_at DESC
    `;

    return await getMany(query, [eventId, organizerId]);
  }

  // Get recent registrations for dashboard
  static async getRecentRegistrations(organizerId, limit = 10) {
    const query = `
      SELECT r.id, r.attendee_name, r.attendee_email, r.status, r.registered_at,
             e.id as event_id, e.title_ar as event_title
      FROM event_registrations r
      JOIN events e ON r.event_id = e.id
      WHERE e.organizer_id = ?
      ORDER BY r.registered_at DESC
      LIMIT ?
    `;

    return await getMany(query, [organizerId, limit]);
  }
}

module.exports = Registration;
