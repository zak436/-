const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Event = require('../models/Event');
const Registration = require('../models/Registration');
const { authenticateToken, requireOrganizer } = require('../middleware/auth');

// Protected routes - require authentication
router.use(authenticateToken);
router.use(requireOrganizer);

// Get dashboard overview
router.get('/overview', async (req, res) => {
  try {
    const organizerId = req.userId;

    // Get user statistics
    const userStats = await User.getStats(organizerId);

    // Get upcoming events
    const upcomingEvents = await Event.getUpcomingEvents(organizerId, 5);

    // Get recent registrations
    const recentRegistrations = await Registration.getRecentRegistrations(organizerId, 10);

    // Calculate additional metrics
    const currentDate = new Date();
    const thirtyDaysAgo = new Date(currentDate.getTime() - (30 * 24 * 60 * 60 * 1000));

    // Get events created in the last 30 days
    const recentEventsResult = await Event.findMany(
      {
        organizer_id: organizerId,
        start_date_from: thirtyDaysAgo.toISOString()
      },
      { page: 1, limit: 100 }
    );

    const monthlyStats = {
      events_this_month: recentEventsResult.events.length,
      registrations_this_month: recentRegistrations.filter(reg => 
        new Date(reg.registered_at) >= thirtyDaysAgo
      ).length
    };

    res.json({
      overview: {
        ...userStats,
        ...monthlyStats,
        upcoming_events: upcomingEvents,
        recent_registrations: recentRegistrations
      }
    });

  } catch (error) {
    console.error('Dashboard overview error:', error);
    res.status(500).json({
      error: 'Failed to get dashboard overview',
      message_ar: 'فشل في جلب نظرة عامة على لوحة التحكم'
    });
  }
});

// Get events summary
router.get('/events-summary', async (req, res) => {
  try {
    const organizerId = req.userId;
    const { period = '30' } = req.query; // days

    const daysAgo = parseInt(period);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    // Get events by status
    const eventsByStatus = await Promise.all([
      Event.findMany({ organizer_id: organizerId, status: 'published' }, { page: 1, limit: 1000 }),
      Event.findMany({ organizer_id: organizerId, status: 'draft' }, { page: 1, limit: 1000 }),
      Event.findMany({ organizer_id: organizerId, status: 'cancelled' }, { page: 1, limit: 1000 }),
      Event.findMany({ organizer_id: organizerId, status: 'completed' }, { page: 1, limit: 1000 })
    ]);

    const summary = {
      published: eventsByStatus[0].pagination.total,
      draft: eventsByStatus[1].pagination.total,
      cancelled: eventsByStatus[2].pagination.total,
      completed: eventsByStatus[3].pagination.total,
      total: eventsByStatus.reduce((sum, result) => sum + result.pagination.total, 0)
    };

    res.json({ summary });

  } catch (error) {
    console.error('Events summary error:', error);
    res.status(500).json({
      error: 'Failed to get events summary',
      message_ar: 'فشل في جلب ملخص الفعاليات'
    });
  }
});

// Get registrations analytics
router.get('/registrations-analytics', async (req, res) => {
  try {
    const organizerId = req.userId;
    const { period = '30' } = req.query; // days

    const daysAgo = parseInt(period);
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysAgo);

    // Get all organizer's events
    const eventsResult = await Event.findMany(
      { organizer_id: organizerId },
      { page: 1, limit: 1000 }
    );

    const eventIds = eventsResult.events.map(event => event.id);

    if (eventIds.length === 0) {
      return res.json({
        analytics: {
          total_registrations: 0,
          confirmed_registrations: 0,
          pending_registrations: 0,
          cancelled_registrations: 0,
          attended_registrations: 0,
          daily_registrations: []
        }
      });
    }

    // Get registration statistics for all events
    const registrationStats = await Promise.all(
      eventIds.map(eventId => Registration.getEventStats(eventId, organizerId))
    );

    // Aggregate statistics
    const totalStats = registrationStats.reduce((acc, stats) => ({
      total_registrations: acc.total_registrations + stats.total_registrations,
      confirmed_registrations: acc.confirmed_registrations + stats.confirmed_registrations,
      pending_registrations: acc.pending_registrations + stats.pending_registrations,
      cancelled_registrations: acc.cancelled_registrations + stats.cancelled_registrations,
      attended_registrations: acc.attended_registrations + stats.attended_registrations,
      total_revenue: acc.total_revenue + stats.total_revenue
    }), {
      total_registrations: 0,
      confirmed_registrations: 0,
      pending_registrations: 0,
      cancelled_registrations: 0,
      attended_registrations: 0,
      total_revenue: 0
    });

    res.json({
      analytics: totalStats
    });

  } catch (error) {
    console.error('Registrations analytics error:', error);
    res.status(500).json({
      error: 'Failed to get registrations analytics',
      message_ar: 'فشل في جلب تحليلات التسجيلات'
    });
  }
});

// Get popular events
router.get('/popular-events', async (req, res) => {
  try {
    const organizerId = req.userId;
    const { limit = 10 } = req.query;

    const eventsResult = await Event.findMany(
      { organizer_id: organizerId },
      { 
        page: 1, 
        limit: parseInt(limit),
        sort: 'views_count',
        order: 'DESC'
      }
    );

    res.json({
      popular_events: eventsResult.events.map(event => ({
        id: event.id,
        title_ar: event.title_ar,
        title_en: event.title_en,
        views_count: event.views_count,
        registration_count: event.registration_count,
        start_date: event.start_date,
        status: event.status
      }))
    });

  } catch (error) {
    console.error('Popular events error:', error);
    res.status(500).json({
      error: 'Failed to get popular events',
      message_ar: 'فشل في جلب الفعاليات الشائعة'
    });
  }
});

// Get revenue analytics
router.get('/revenue-analytics', async (req, res) => {
  try {
    const organizerId = req.userId;
    const { period = '30' } = req.query; // days

    // Get all organizer's events
    const eventsResult = await Event.findMany(
      { organizer_id: organizerId },
      { page: 1, limit: 1000 }
    );

    const eventIds = eventsResult.events.map(event => event.id);

    if (eventIds.length === 0) {
      return res.json({
        revenue: {
          total_revenue: 0,
          paid_events: 0,
          free_events: 0,
          average_ticket_price: 0
        }
      });
    }

    // Get revenue statistics
    const revenueStats = await Promise.all(
      eventIds.map(eventId => Registration.getEventStats(eventId, organizerId))
    );

    const totalRevenue = revenueStats.reduce((sum, stats) => sum + stats.total_revenue, 0);
    const paidEvents = eventsResult.events.filter(event => !event.is_free).length;
    const freeEvents = eventsResult.events.filter(event => event.is_free).length;
    const averageTicketPrice = paidEvents > 0 ? 
      eventsResult.events
        .filter(event => !event.is_free)
        .reduce((sum, event) => sum + event.price, 0) / paidEvents : 0;

    res.json({
      revenue: {
        total_revenue: totalRevenue,
        paid_events: paidEvents,
        free_events: freeEvents,
        average_ticket_price: averageTicketPrice
      }
    });

  } catch (error) {
    console.error('Revenue analytics error:', error);
    res.status(500).json({
      error: 'Failed to get revenue analytics',
      message_ar: 'فشل في جلب تحليلات الإيرادات'
    });
  }
});

module.exports = router;
