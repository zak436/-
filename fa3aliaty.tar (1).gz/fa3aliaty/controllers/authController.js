const User = require('../models/User');
const { generateToken, generateRefreshToken } = require('../config/auth');
const { sendEmail } = require('../utils/email');

class AuthController {
  // Register new organizer
  static async register(req, res) {
    try {
      const {
        email,
        password,
        first_name,
        last_name,
        phone,
        organization_name,
        organization_type,
        bio,
        website
      } = req.body;

      // Check if email already exists
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({
          error: 'Email already registered',
          message_ar: 'البريد الإلكتروني مسجل مسبقاً'
        });
      }

      // Create new user
      const result = await User.create({
        email,
        password,
        first_name,
        last_name,
        phone,
        organization_name,
        organization_type,
        bio,
        website
      });

      // Send verification email
      try {
        await sendEmail({
          to: email,
          subject: 'تأكيد البريد الإلكتروني - فعالياتي',
          template: 'email-verification',
          data: {
            name: `${first_name} ${last_name}`,
            verification_token: result.email_verification_token,
            verification_url: `${process.env.FRONTEND_URL}/verify-email?token=${result.email_verification_token}`
          }
        });
      } catch (emailError) {
        console.error('Failed to send verification email:', emailError);
        // Don't fail registration if email fails
      }

      res.status(201).json({
        message: 'Registration successful. Please check your email for verification.',
        message_ar: 'تم التسجيل بنجاح. يرجى التحقق من بريدك الإلكتروني للتأكيد.',
        user_id: result.id,
        email_verification_required: true
      });

    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({
        error: 'Registration failed',
        message_ar: 'فشل في التسجيل'
      });
    }
  }

  // Login organizer
  static async login(req, res) {
    try {
      const { email, password } = req.body;

      // Find user by email
      const user = await User.findByEmail(email);
      if (!user) {
        return res.status(401).json({
          error: 'Invalid email or password',
          message_ar: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        });
      }

      // Check if user is active
      if (user.status !== 'active') {
        return res.status(401).json({
          error: 'Account is not active',
          message_ar: 'الحساب غير نشط'
        });
      }

      // Verify password
      const isValidPassword = await User.verifyPassword(password, user.password_hash);
      if (!isValidPassword) {
        return res.status(401).json({
          error: 'Invalid email or password',
          message_ar: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        });
      }

      // Generate tokens
      const tokenPayload = {
        userId: user.id,
        email: user.email,
        name: `${user.first_name} ${user.last_name}`
      };

      const accessToken = generateToken(tokenPayload);
      const refreshToken = generateRefreshToken(tokenPayload);

      // Remove sensitive data
      delete user.password_hash;

      res.json({
        message: 'Login successful',
        message_ar: 'تم تسجيل الدخول بنجاح',
        user,
        access_token: accessToken,
        refresh_token: refreshToken,
        token_type: 'Bearer'
      });

    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({
        error: 'Login failed',
        message_ar: 'فشل في تسجيل الدخول'
      });
    }
  }

  // Verify email
  static async verifyEmail(req, res) {
    try {
      const { token } = req.body;

      if (!token) {
        return res.status(400).json({
          error: 'Verification token is required',
          message_ar: 'رمز التحقق مطلوب'
        });
      }

      const success = await User.verifyEmail(token);
      
      if (!success) {
        return res.status(400).json({
          error: 'Invalid or expired verification token',
          message_ar: 'رمز التحقق غير صالح أو منتهي الصلاحية'
        });
      }

      res.json({
        message: 'Email verified successfully',
        message_ar: 'تم تأكيد البريد الإلكتروني بنجاح'
      });

    } catch (error) {
      console.error('Email verification error:', error);
      res.status(500).json({
        error: 'Email verification failed',
        message_ar: 'فشل في تأكيد البريد الإلكتروني'
      });
    }
  }

  // Request password reset
  static async requestPasswordReset(req, res) {
    try {
      const { email } = req.body;

      const token = await User.setPasswordResetToken(email);
      
      if (!token) {
        // Don't reveal if email exists or not for security
        return res.json({
          message: 'If the email exists, a password reset link has been sent.',
          message_ar: 'إذا كان البريد الإلكتروني موجود، فقد تم إرسال رابط إعادة تعيين كلمة المرور.'
        });
      }

      // Send password reset email
      try {
        const user = await User.findByEmail(email);
        await sendEmail({
          to: email,
          subject: 'إعادة تعيين كلمة المرور - فعالياتي',
          template: 'password-reset',
          data: {
            name: `${user.first_name} ${user.last_name}`,
            reset_token: token,
            reset_url: `${process.env.FRONTEND_URL}/reset-password?token=${token}`
          }
        });
      } catch (emailError) {
        console.error('Failed to send password reset email:', emailError);
      }

      res.json({
        message: 'If the email exists, a password reset link has been sent.',
        message_ar: 'إذا كان البريد الإلكتروني موجود، فقد تم إرسال رابط إعادة تعيين كلمة المرور.'
      });

    } catch (error) {
      console.error('Password reset request error:', error);
      res.status(500).json({
        error: 'Password reset request failed',
        message_ar: 'فشل في طلب إعادة تعيين كلمة المرور'
      });
    }
  }

  // Reset password
  static async resetPassword(req, res) {
    try {
      const { token, password } = req.body;

      const success = await User.resetPassword(token, password);
      
      if (!success) {
        return res.status(400).json({
          error: 'Invalid or expired reset token',
          message_ar: 'رمز إعادة التعيين غير صالح أو منتهي الصلاحية'
        });
      }

      res.json({
        message: 'Password reset successfully',
        message_ar: 'تم إعادة تعيين كلمة المرور بنجاح'
      });

    } catch (error) {
      console.error('Password reset error:', error);
      res.status(500).json({
        error: 'Password reset failed',
        message_ar: 'فشل في إعادة تعيين كلمة المرور'
      });
    }
  }

  // Change password (for authenticated users)
  static async changePassword(req, res) {
    try {
      const { current_password, new_password } = req.body;
      const userId = req.userId;

      // Get user with password hash
      const user = await User.findByEmail(req.user.email);
      if (!user) {
        return res.status(404).json({
          error: 'User not found',
          message_ar: 'المستخدم غير موجود'
        });
      }

      // Verify current password
      const isValidPassword = await User.verifyPassword(current_password, user.password_hash);
      if (!isValidPassword) {
        return res.status(400).json({
          error: 'Current password is incorrect',
          message_ar: 'كلمة المرور الحالية غير صحيحة'
        });
      }

      // Update password
      const success = await User.updatePassword(userId, new_password);
      
      if (!success) {
        return res.status(500).json({
          error: 'Failed to update password',
          message_ar: 'فشل في تحديث كلمة المرور'
        });
      }

      res.json({
        message: 'Password changed successfully',
        message_ar: 'تم تغيير كلمة المرور بنجاح'
      });

    } catch (error) {
      console.error('Change password error:', error);
      res.status(500).json({
        error: 'Password change failed',
        message_ar: 'فشل في تغيير كلمة المرور'
      });
    }
  }

  // Get current user profile
  static async getProfile(req, res) {
    try {
      const user = await User.findById(req.userId);
      
      if (!user) {
        return res.status(404).json({
          error: 'User not found',
          message_ar: 'المستخدم غير موجود'
        });
      }

      res.json({
        user
      });

    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({
        error: 'Failed to get profile',
        message_ar: 'فشل في جلب الملف الشخصي'
      });
    }
  }

  // Logout (client-side token removal, but we can log it)
  static async logout(req, res) {
    try {
      // In a more sophisticated setup, you might want to blacklist the token
      // For now, we'll just return a success message
      
      res.json({
        message: 'Logged out successfully',
        message_ar: 'تم تسجيل الخروج بنجاح'
      });

    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({
        error: 'Logout failed',
        message_ar: 'فشل في تسجيل الخروج'
      });
    }
  }
}

module.exports = AuthController;
