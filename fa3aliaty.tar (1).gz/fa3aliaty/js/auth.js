// Authentication related functionality

document.addEventListener('DOMContentLoaded', function() {
    // Check for URL parameters to auto-select account type
    const urlParams = new URLSearchParams(window.location.search);
    const accountType = urlParams.get('type');
    
    if (accountType === 'organizer') {
        // Auto-select organizer account type if parameter is present
        const organizerRadio = document.querySelector('#organizer-radio') || document.querySelector('input[value="organizer"]');
        if (organizerRadio) {
            organizerRadio.checked = true;
            
            // Trigger change event to update the form
            organizerRadio.dispatchEvent(new Event('change'));
            
            // Show organizer fields if they exist
            const organizerFields = document.getElementById('organizer-fields');
            if (organizerFields) {
                organizerFields.style.display = 'block';
            }
            
            // Set the hidden input value
            const hiddenInput = document.getElementById('account_type');
            if (hiddenInput) {
                hiddenInput.value = 'organizer';
            }
            
            // Update the form's redirect attribute
            const form = document.querySelector('.auth-form');
            if (form) {
                form.setAttribute('data-redirect', 'dashboard.html');
            }
            
            // Update button text
            const submitButton = document.querySelector('.auth-btn');
            if (submitButton) {
                submitButton.textContent = 'إنشاء حساب منظم';
            }
        }
    }
    // Toggle password visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    if (togglePasswordButtons) {
        togglePasswordButtons.forEach(button => {
            button.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                
                // Toggle icon
                const icon = this.querySelector('i');
                if (type === 'text') {
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    }
    
    // Account type selection in signup and login
    const accountTypeRadios = document.querySelectorAll('input[name="account_type"], input[name="login_account_type"]');
    if (accountTypeRadios.length > 0) {
        accountTypeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                // Update hidden input value
                const hiddenInput = document.getElementById('account_type');
                if (hiddenInput) {
                    hiddenInput.value = this.value;
                }
                
                // Show/hide organizer specific fields if on signup page
                const organizerFields = document.getElementById('organizer-fields');
                if (organizerFields) {
                    if (this.value === 'organizer') {
                        organizerFields.style.display = 'block';
                    } else {
                        organizerFields.style.display = 'none';
                    }
                }
                
                // Change button text based on account type (now always organizer)
                const submitButton = document.querySelector('.auth-btn');
                if (submitButton) {
                    if (document.querySelector('h1').textContent.includes('تسجيل الدخول')) {
                        // Login page
                        submitButton.textContent = 'تسجيل الدخول كمنظم';
                    } else {
                        // Signup page
                        submitButton.textContent = 'إنشاء حساب منظم';
                    }
                }
                
                // Change redirect URL (now always dashboard for organizers)
                const form = document.querySelector('.auth-form');
                if (form) {
                    form.setAttribute('data-redirect', 'dashboard.html');
                }
            });
        });
        
        // Trigger change event on the checked radio button to initialize the form
        const checkedRadio = document.querySelector('input[name="account_type"]:checked, input[name="login_account_type"]:checked');
        if (checkedRadio) {
            checkedRadio.dispatchEvent(new Event('change'));
        }
    }
    
    // Form validation
    const authForms = document.querySelectorAll('.auth-form');
    
    authForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            let isValid = true;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            // Clear previous errors
            form.querySelectorAll('.form-error').forEach(error => {
                error.textContent = '';
            });
            
            // Validate email
            const emailInput = form.querySelector('input[type="email"]');
            if (emailInput && !emailRegex.test(emailInput.value)) {
                const errorElement = emailInput.nextElementSibling;
                if (errorElement && errorElement.classList.contains('form-error')) {
                    errorElement.textContent = 'يرجى إدخال بريد إلكتروني صحيح';
                }
                isValid = false;
            }
            
            // Validate password
            const passwordInput = form.querySelector('input[type="password"][name="password"]');
            if (passwordInput && passwordInput.value.length < 8) {
                const errorElement = passwordInput.parentElement.nextElementSibling;
                if (errorElement && errorElement.classList.contains('form-error')) {
                    errorElement.textContent = 'يجب أن تتكون كلمة المرور من 8 أحرف على الأقل';
                }
                isValid = false;
            }
            
            // Validate password confirmation
            const passwordConfirmInput = form.querySelector('input[name="password_confirm"]');
            if (passwordConfirmInput && passwordInput && passwordConfirmInput.value !== passwordInput.value) {
                const errorElement = passwordConfirmInput.parentElement.nextElementSibling;
                if (errorElement && errorElement.classList.contains('form-error')) {
                    errorElement.textContent = 'كلمات المرور غير متطابقة';
                }
                isValid = false;
            }
            
            // If the form is valid, submit to backend
            if (isValid) {
                const submitButton = form.querySelector('.auth-btn');

                if (submitButton) {
                    const originalText = submitButton.textContent;
                    submitButton.disabled = true;
                    submitButton.textContent = 'جاري التحميل...';

                    // Determine if this is login or signup
                    const isLogin = form.querySelector('h1').textContent.includes('تسجيل الدخول');

                    try {
                        if (isLogin) {
                            // Handle login
                            await handleLogin(form);
                        } else {
                            // Handle signup
                            await handleSignup(form);
                        }
                    } catch (error) {
                        // Show error message
                        showFormError(form, error.message);
                        submitButton.disabled = false;
                        submitButton.textContent = originalText;
                    }
                }
            }
        });
    });
    
    // Remember me functionality
    const rememberCheckbox = document.querySelector('#remember-me');
    if (rememberCheckbox) {
        // Check if we have a saved email
        const savedEmail = localStorage.getItem('rememberedEmail');
        if (savedEmail) {
            const emailInput = document.querySelector('input[type="email"]');
            if (emailInput) {
                emailInput.value = savedEmail;
                rememberCheckbox.checked = true;
            }
        }
        
        // Save email when form is submitted if remember me is checked
        const loginForm = rememberCheckbox.closest('form');
        if (loginForm) {
            loginForm.addEventListener('submit', function() {
                const emailInput = loginForm.querySelector('input[type="email"]');
                if (emailInput && rememberCheckbox.checked) {
                    localStorage.setItem('rememberedEmail', emailInput.value);
                } else {
                    localStorage.removeItem('rememberedEmail');
                }
            });
        }
    }
    
    // Social login buttons (for demo purposes)
    const socialButtons = document.querySelectorAll('.social-btn');
    if (socialButtons) {
        socialButtons.forEach(button => {
            button.addEventListener('click', function() {
                alert('هذه الميزة غير متاحة في النسخة التجريبية.');
            });
        });
    }
    
    // Authentication helper functions
    async function handleLogin(form) {
        const formData = new FormData(form);
        const credentials = {
            email: formData.get('email'),
            password: formData.get('password')
        };

        const response = await window.api.login(credentials);

        // Set logged in state
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userType', 'organizer');

        // Show success message
        const submitButton = form.querySelector('.auth-btn');
        submitButton.textContent = 'تم بنجاح!';

        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
    }

    async function handleSignup(form) {
        const formData = new FormData(form);
        const userData = {
            email: formData.get('email'),
            password: formData.get('password'),
            first_name: formData.get('first_name') || formData.get('fullname')?.split(' ')[0] || '',
            last_name: formData.get('last_name') || formData.get('fullname')?.split(' ').slice(1).join(' ') || '',
            phone: formData.get('phone'),
            organization_name: formData.get('organization_name'),
            organization_type: formData.get('organization_type') || 'individual'
        };

        const response = await window.api.register(userData);

        // Show success message
        const submitButton = form.querySelector('.auth-btn');
        submitButton.textContent = 'تم التسجيل بنجاح!';

        // Show email verification message
        showSuccessMessage(form, 'تم إنشاء الحساب بنجاح! يرجى التحقق من بريدك الإلكتروني لتأكيد الحساب.');

        // Redirect to login after delay
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 3000);
    }

    function showFormError(form, message) {
        // Remove existing error messages
        const existingError = form.querySelector('.auth-error');
        if (existingError) {
            existingError.remove();
        }

        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'auth-error';
        errorDiv.style.cssText = `
            background-color: #fee;
            color: #c33;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
            border: 1px solid #fcc;
        `;
        errorDiv.textContent = message;

        // Insert error message at the top of the form
        form.insertBefore(errorDiv, form.firstChild);
    }

    function showSuccessMessage(form, message) {
        // Remove existing messages
        const existingMessage = form.querySelector('.auth-success');
        if (existingMessage) {
            existingMessage.remove();
        }

        // Create success message element
        const successDiv = document.createElement('div');
        successDiv.className = 'auth-success';
        successDiv.style.cssText = `
            background-color: #efe;
            color: #363;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
            border: 1px solid #cfc;
        `;
        successDiv.textContent = message;

        // Insert success message at the top of the form
        form.insertBefore(successDiv, form.firstChild);
    }
});