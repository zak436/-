const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs').promises;

// Create email transporter
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: process.env.EMAIL_PORT || 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD
    },
    tls: {
      rejectUnauthorized: false
    }
  });
};

// Email templates
const emailTemplates = {
  'email-verification': {
    subject: 'تأكيد البريد الإلكتروني - فعالياتي',
    template: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #8a2be2;">فعالياتي</h1>
        </div>
        
        <h2 style="color: #333;">مرحباً {{name}}</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #555;">
          شكراً لك على التسجيل في منصة فعالياتي. لإكمال عملية التسجيل، يرجى تأكيد بريدك الإلكتروني بالنقر على الرابط أدناه:
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{verification_url}}" style="background-color: #8a2be2; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
            تأكيد البريد الإلكتروني
          </a>
        </div>
        
        <p style="font-size: 14px; color: #777;">
          إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد الإلكتروني.
        </p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
        <p style="font-size: 12px; color: #999; text-align: center;">
          © 2024 فعالياتي. جميع الحقوق محفوظة.
        </p>
      </div>
    `
  },

  'password-reset': {
    subject: 'إعادة تعيين كلمة المرور - فعالياتي',
    template: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #8a2be2;">فعالياتي</h1>
        </div>
        
        <h2 style="color: #333;">مرحباً {{name}}</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #555;">
          تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك. انقر على الرابط أدناه لإعادة تعيين كلمة المرور:
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="{{reset_url}}" style="background-color: #ff69b4; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
            إعادة تعيين كلمة المرور
          </a>
        </div>
        
        <p style="font-size: 14px; color: #777;">
          هذا الرابط صالح لمدة ساعة واحدة فقط. إذا لم تطلب إعادة تعيين كلمة المرور، يرجى تجاهل هذا البريد الإلكتروني.
        </p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
        <p style="font-size: 12px; color: #999; text-align: center;">
          © 2024 فعالياتي. جميع الحقوق محفوظة.
        </p>
      </div>
    `
  },

  'registration-confirmation': {
    subject: 'تأكيد التسجيل - {{event_title}}',
    template: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #8a2be2;">فعالياتي</h1>
        </div>
        
        <h2 style="color: #333;">مرحباً {{attendee_name}}</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #555;">
          تم تأكيد تسجيلك بنجاح في الفعالية التالية:
        </p>
        
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #8a2be2; margin-top: 0;">{{event_title}}</h3>
          <p><strong>التاريخ:</strong> {{event_date}}</p>
          <p><strong>الوقت:</strong> {{event_time}}</p>
          {{#if venue_name}}
          <p><strong>المكان:</strong> {{venue_name}}</p>
          <p><strong>العنوان:</strong> {{venue_address}}</p>
          {{/if}}
          {{#unless is_free}}
          <p><strong>السعر:</strong> {{price}} ريال سعودي</p>
          {{/unless}}
        </div>
        
        <p style="font-size: 14px; color: #777;">
          رمز التأكيد: <strong>{{confirmation_token}}</strong>
        </p>
        
        <p style="font-size: 14px; color: #777;">
          احتفظ بهذا البريد الإلكتروني كتأكيد لحضورك.
        </p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
        <p style="font-size: 12px; color: #999; text-align: center;">
          © 2024 فعالياتي. جميع الحقوق محفوظة.
        </p>
      </div>
    `
  },

  'registration-cancellation': {
    subject: 'إلغاء التسجيل - {{event_title}}',
    template: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #8a2be2;">فعالياتي</h1>
        </div>
        
        <h2 style="color: #333;">مرحباً {{attendee_name}}</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #555;">
          تم إلغاء تسجيلك في الفعالية التالية:
        </p>
        
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #8a2be2; margin-top: 0;">{{event_title}}</h3>
          <p><strong>التاريخ:</strong> {{event_date}}</p>
        </div>
        
        <p style="font-size: 14px; color: #777;">
          نأسف لعدم تمكنك من الحضور. نتطلع لرؤيتك في فعالياتنا القادمة.
        </p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
        <p style="font-size: 12px; color: #999; text-align: center;">
          © 2024 فعالياتي. جميع الحقوق محفوظة.
        </p>
      </div>
    `
  },

  'payment-confirmation': {
    subject: 'تأكيد الدفع - {{event_title}}',
    template: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #8a2be2;">فعالياتي</h1>
        </div>
        
        <h2 style="color: #333;">مرحباً {{attendee_name}}</h2>
        
        <p style="font-size: 16px; line-height: 1.6; color: #555;">
          تم تأكيد دفعتك بنجاح للفعالية:
        </p>
        
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #8a2be2; margin-top: 0;">{{event_title}}</h3>
          <p><strong>المبلغ المدفوع:</strong> {{payment_amount}} ريال سعودي</p>
          <p><strong>رقم المرجع:</strong> {{payment_reference}}</p>
        </div>
        
        <p style="font-size: 14px; color: #777;">
          شكراً لك على الدفع. تم تأكيد تسجيلك في الفعالية.
        </p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        
        <p style="font-size: 12px; color: #999; text-align: center;">
          © 2024 فعالياتي. جميع الحقوق محفوظة.
        </p>
      </div>
    `
  }
};

// Simple template engine (replace {{variable}} with data)
function renderTemplate(template, data) {
  let rendered = template;
  
  // Replace simple variables
  Object.keys(data).forEach(key => {
    const regex = new RegExp(`{{${key}}}`, 'g');
    rendered = rendered.replace(regex, data[key] || '');
  });
  
  // Handle conditional blocks {{#if variable}}...{{/if}}
  rendered = rendered.replace(/{{#if\s+(\w+)}}([\s\S]*?){{\/if}}/g, (match, variable, content) => {
    return data[variable] ? content : '';
  });
  
  // Handle negative conditional blocks {{#unless variable}}...{{/unless}}
  rendered = rendered.replace(/{{#unless\s+(\w+)}}([\s\S]*?){{\/unless}}/g, (match, variable, content) => {
    return !data[variable] ? content : '';
  });
  
  return rendered;
}

// Send email function
async function sendEmail({ to, subject, template, data = {} }) {
  try {
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
      console.warn('Email credentials not configured. Email not sent.');
      return false;
    }

    const transporter = createTransporter();
    
    // Get template
    const emailTemplate = emailTemplates[template];
    if (!emailTemplate) {
      throw new Error(`Email template '${template}' not found`);
    }
    
    // Render template
    const htmlContent = renderTemplate(emailTemplate.template, data);
    const emailSubject = renderTemplate(subject || emailTemplate.subject, data);
    
    // Send email
    const mailOptions = {
      from: `"فعالياتي" <${process.env.EMAIL_USER}>`,
      to,
      subject: emailSubject,
      html: htmlContent
    };
    
    const result = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', result.messageId);
    return true;
    
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
}

// Send bulk emails
async function sendBulkEmails(emails) {
  const results = [];
  
  for (const emailData of emails) {
    try {
      await sendEmail(emailData);
      results.push({ success: true, email: emailData.to });
    } catch (error) {
      results.push({ success: false, email: emailData.to, error: error.message });
    }
  }
  
  return results;
}

// Test email configuration
async function testEmailConfig() {
  try {
    const transporter = createTransporter();
    await transporter.verify();
    console.log('Email configuration is valid');
    return true;
  } catch (error) {
    console.error('Email configuration test failed:', error);
    return false;
  }
}

module.exports = {
  sendEmail,
  sendBulkEmails,
  testEmailConfig
};
