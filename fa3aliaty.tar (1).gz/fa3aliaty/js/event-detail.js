// Event detail page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get event ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('id');
    
    if (eventId) {
        loadEventDetail(eventId);
    } else {
        showError('معرف الفعالية غير موجود');
    }
});

// Load event details
async function loadEventDetail(eventId) {
    try {
        showLoadingState();
        
        const response = await window.api.getEvent(eventId);
        const event = response.event;
        
        displayEventDetail(event);
        setupRegistrationButton(event);
        
    } catch (error) {
        console.error('Error loading event detail:', error);
        showError('فشل في تحميل تفاصيل الفعالية');
    }
}

// Display event details
function displayEventDetail(event) {
    // Update page title
    document.title = `${event.title_ar} - فعالياتي`;
    
    // Update event header
    updateEventHeader(event);
    
    // Update event content
    updateEventContent(event);
    
    // Update event sidebar
    updateEventSidebar(event);
}

// Update event header
function updateEventHeader(event) {
    const eventHeader = document.querySelector('.event-header');
    if (!eventHeader) return;
    
    const eventDate = new Date(event.start_date);
    const formattedDate = eventDate.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    const formattedTime = eventDate.toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // Set background image if available
    if (event.images && event.images.length > 0) {
        eventHeader.style.backgroundImage = `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('${event.images[0]}')`;
    }
    
    eventHeader.innerHTML = `
        <div class="container">
            <div class="event-header-content">
                <div class="event-category">${event.category_name_ar || 'فعالية'}</div>
                <h1 class="event-title">${event.title_ar}</h1>
                <div class="event-meta">
                    <div class="meta-item">
                        <i class="fas fa-calendar"></i>
                        <span>${formattedDate}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-clock"></i>
                        <span>${formattedTime}</span>
                    </div>
                    ${event.venue_name_ar ? `
                        <div class="meta-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${event.venue_name_ar}</span>
                        </div>
                    ` : ''}
                    <div class="meta-item">
                        <i class="fas fa-users"></i>
                        <span>${event.registration_count || 0} مسجل</span>
                    </div>
                </div>
                <div class="event-price">
                    ${event.is_free ? 
                        '<span class="price free">مجاني</span>' : 
                        `<span class="price paid">${event.price} ريال</span>`
                    }
                </div>
            </div>
        </div>
    `;
}

// Update event content
function updateEventContent(event) {
    const eventContent = document.querySelector('.event-content');
    if (!eventContent) return;
    
    eventContent.innerHTML = `
        <div class="event-description">
            <h2>وصف الفعالية</h2>
            <div class="description-text">
                ${event.description_ar ? event.description_ar.replace(/\n/g, '<br>') : 'لا يوجد وصف متاح'}
            </div>
        </div>
        
        ${event.agenda && event.agenda.length > 0 ? `
            <div class="event-agenda">
                <h2>جدول الفعالية</h2>
                <div class="agenda-list">
                    ${event.agenda.map(item => `
                        <div class="agenda-item">
                            <div class="agenda-time">${item.time}</div>
                            <div class="agenda-content">
                                <h4>${item.title}</h4>
                                <p>${item.description}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}
        
        ${event.speakers && event.speakers.length > 0 ? `
            <div class="event-speakers">
                <h2>المتحدثون</h2>
                <div class="speakers-grid">
                    ${event.speakers.map(speaker => `
                        <div class="speaker-card">
                            <div class="speaker-image">
                                <img src="${speaker.image || 'images/default-avatar.jpg'}" alt="${speaker.name}">
                            </div>
                            <div class="speaker-info">
                                <h4>${speaker.name}</h4>
                                <p class="speaker-title">${speaker.title}</p>
                                <p class="speaker-bio">${speaker.bio}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}
        
        ${event.images && event.images.length > 1 ? `
            <div class="event-gallery">
                <h2>صور الفعالية</h2>
                <div class="gallery-grid">
                    ${event.images.map(image => `
                        <div class="gallery-item">
                            <img src="${image}" alt="صورة الفعالية" onclick="openImageModal('${image}')">
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}
    `;
}

// Update event sidebar
function updateEventSidebar(event) {
    const eventSidebar = document.querySelector('.event-sidebar');
    if (!eventSidebar) return;
    
    const eventDate = new Date(event.start_date);
    const endDate = new Date(event.end_date);
    
    eventSidebar.innerHTML = `
        <div class="event-info-card">
            <h3>معلومات الفعالية</h3>
            
            <div class="info-item">
                <i class="fas fa-calendar-alt"></i>
                <div>
                    <strong>تاريخ البداية</strong>
                    <span>${eventDate.toLocaleDateString('ar-SA')}</span>
                </div>
            </div>
            
            <div class="info-item">
                <i class="fas fa-clock"></i>
                <div>
                    <strong>وقت البداية</strong>
                    <span>${eventDate.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
            </div>
            
            <div class="info-item">
                <i class="fas fa-hourglass-end"></i>
                <div>
                    <strong>وقت الانتهاء</strong>
                    <span>${endDate.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
            </div>
            
            ${event.venue_name_ar ? `
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <strong>المكان</strong>
                        <span>${event.venue_name_ar}</span>
                        ${event.venue_address_ar ? `<small>${event.venue_address_ar}</small>` : ''}
                    </div>
                </div>
            ` : ''}
            
            ${event.capacity ? `
                <div class="info-item">
                    <i class="fas fa-users"></i>
                    <div>
                        <strong>السعة</strong>
                        <span>${event.capacity} شخص</span>
                    </div>
                </div>
            ` : ''}
            
            <div class="info-item">
                <i class="fas fa-tag"></i>
                <div>
                    <strong>السعر</strong>
                    <span>${event.is_free ? 'مجاني' : `${event.price} ريال`}</span>
                </div>
            </div>
            
            ${event.organizer_first_name ? `
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div>
                        <strong>المنظم</strong>
                        <span>${event.organizer_first_name} ${event.organizer_last_name}</span>
                        ${event.organizer_organization ? `<small>${event.organizer_organization}</small>` : ''}
                    </div>
                </div>
            ` : ''}
        </div>
        
        ${event.tags && event.tags.length > 0 ? `
            <div class="event-tags-card">
                <h3>العلامات</h3>
                <div class="tags-list">
                    ${event.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
            </div>
        ` : ''}
        
        <div class="share-card">
            <h3>شارك الفعالية</h3>
            <div class="share-buttons">
                <button class="share-btn facebook" onclick="shareOnFacebook()">
                    <i class="fab fa-facebook-f"></i>
                    فيسبوك
                </button>
                <button class="share-btn twitter" onclick="shareOnTwitter()">
                    <i class="fab fa-twitter"></i>
                    تويتر
                </button>
                <button class="share-btn whatsapp" onclick="shareOnWhatsApp()">
                    <i class="fab fa-whatsapp"></i>
                    واتساب
                </button>
                <button class="share-btn copy" onclick="copyEventLink()">
                    <i class="fas fa-link"></i>
                    نسخ الرابط
                </button>
            </div>
        </div>
    `;
}

// Setup registration button
function setupRegistrationButton(event) {
    const registerButton = document.querySelector('.register-button');
    if (!registerButton) return;
    
    const now = new Date();
    const startDate = new Date(event.start_date);
    const registrationEnd = event.registration_end ? new Date(event.registration_end) : startDate;
    
    // Check if registration is available
    if (event.status !== 'published') {
        registerButton.innerHTML = 'الفعالية غير متاحة';
        registerButton.disabled = true;
        registerButton.classList.add('disabled');
    } else if (startDate <= now) {
        registerButton.innerHTML = 'انتهت الفعالية';
        registerButton.disabled = true;
        registerButton.classList.add('disabled');
    } else if (registrationEnd <= now) {
        registerButton.innerHTML = 'انتهت فترة التسجيل';
        registerButton.disabled = true;
        registerButton.classList.add('disabled');
    } else {
        registerButton.innerHTML = 'سجل الآن';
        registerButton.disabled = false;
        registerButton.classList.remove('disabled');
        registerButton.onclick = () => {
            window.location.href = `register.html?event=${event.id}`;
        };
    }
}

// Share functions
function shareOnFacebook() {
    const url = encodeURIComponent(window.location.href);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
}

function shareOnTwitter() {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(document.title);
    window.open(`https://twitter.com/intent/tweet?url=${url}&text=${text}`, '_blank');
}

function shareOnWhatsApp() {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(`${document.title} - ${url}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
}

function copyEventLink() {
    navigator.clipboard.writeText(window.location.href).then(() => {
        // Show success message
        const copyBtn = document.querySelector('.share-btn.copy');
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="fas fa-check"></i> تم النسخ';
        setTimeout(() => {
            copyBtn.innerHTML = originalText;
        }, 2000);
    });
}

// Image modal
function openImageModal(imageSrc) {
    const modal = document.createElement('div');
    modal.className = 'image-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        cursor: pointer;
    `;
    
    modal.innerHTML = `
        <img src="${imageSrc}" style="max-width: 90%; max-height: 90%; object-fit: contain;">
        <button style="position: absolute; top: 20px; right: 20px; background: none; border: none; color: white; font-size: 30px; cursor: pointer;">&times;</button>
    `;
    
    modal.onclick = () => modal.remove();
    document.body.appendChild(modal);
}

// Show loading state
function showLoadingState() {
    const container = document.querySelector('.event-detail-container') || document.body;
    container.innerHTML = `
        <div class="loading-state">
            <i class="fas fa-spinner fa-spin"></i>
            <p>جاري تحميل تفاصيل الفعالية...</p>
        </div>
    `;
}

// Show error state
function showError(message) {
    const container = document.querySelector('.event-detail-container') || document.body;
    container.innerHTML = `
        <div class="error-state">
            <i class="fas fa-exclamation-triangle"></i>
            <h2>حدث خطأ</h2>
            <p>${message}</p>
            <a href="events.html" class="btn btn-primary">تصفح الفعاليات</a>
        </div>
    `;
}
