-- Feaalyati Database Seed Data
USE feaalyati_db;

-- Insert event categories
INSERT INTO event_categories (name_ar, name_en, description_ar, description_en, icon, color, sort_order) VALUES
('مؤتمرات', 'Conferences', 'مؤتمرات مهنية وأكاديمية', 'Professional and academic conferences', 'fas fa-users', '#8a2be2', 1),
('ورش عمل', 'Workshops', 'ورش عمل تدريبية وتعليمية', 'Training and educational workshops', 'fas fa-tools', '#ff69b4', 2),
('ندوات', 'Seminars', 'ندوات ومحاضرات تثقيفية', 'Educational seminars and lectures', 'fas fa-chalkboard-teacher', '#00bcd4', 3),
('معارض', 'Exhibitions', 'معارض تجارية وفنية', 'Trade and art exhibitions', 'fas fa-store', '#4caf50', 4),
('فعاليات تواصل', 'Networking', 'فعاليات التواصل المهني', 'Professional networking events', 'fas fa-handshake', '#ff9800', 5),
('فعاليات ثقافية', 'Cultural', 'فعاليات ثقافية وتراثية', 'Cultural and heritage events', 'fas fa-theater-masks', '#9c27b0', 6),
('فعاليات رياضية', 'Sports', 'فعاليات وبطولات رياضية', 'Sports events and tournaments', 'fas fa-running', '#f44336', 7),
('ترفيه', 'Entertainment', 'فعاليات ترفيهية وحفلات', 'Entertainment events and concerts', 'fas fa-music', '#e91e63', 8),
('أخرى', 'Other', 'فعاليات أخرى متنوعة', 'Other miscellaneous events', 'fas fa-calendar-alt', '#607d8b', 9);

-- Insert sample venues
INSERT INTO venues (name_ar, name_en, address_ar, address_en, city, latitude, longitude, capacity, venue_type, facilities, contact_phone, contact_email) VALUES
('مركز الرياض الدولي للمؤتمرات والمعارض', 'Riyadh International Convention & Exhibition Center', 'طريق الملك عبدالعزيز، الرياض', 'King Abdulaziz Road, Riyadh', 'الرياض', 24.7136, 46.6753, 5000, 'indoor', '["مواقف سيارات", "واي فاي مجاني", "مطاعم", "قاعات اجتماعات"]', '+966112345678', 'info@ricec.com'),
('فندق الفيصلية', 'Al Faisaliah Hotel', 'طريق الملك فهد، الرياض', 'King Fahd Road, Riyadh', 'الرياض', 24.6877, 46.6857, 800, 'indoor', '["مواقف سيارات", "واي فاي مجاني", "مطاعم", "خدمة الغرف"]', '+966114567890', 'events@alfaisaliah.com'),
('مركز الملك عبدالعزيز التاريخي', 'King Abdulaziz Historical Center', 'حي المربع، الرياض', 'Al Murabba District, Riyadh', 'الرياض', 24.6408, 46.7728, 1200, 'indoor', '["مواقف سيارات", "واي فاي مجاني", "مكتبة", "متحف"]', '+966117891234', 'info@kaahc.gov.sa'),
('جامعة الملك سعود', 'King Saud University', 'طريق الملك عبدالله، الرياض', 'King Abdullah Road, Riyadh', 'الرياض', 24.7277, 46.6186, 2000, 'indoor', '["مواقف سيارات", "واي فاي مجاني", "مكتبة", "مختبرات"]', '+966114678901', 'events@ksu.edu.sa'),
('منتزه الملك عبدالله', 'King Abdullah Park', 'حي الملقا، الرياض', 'Al Malqa District, Riyadh', 'الرياض', 24.7539, 46.6181, 3000, 'outdoor', '["مواقف سيارات", "مناطق خضراء", "ملاعب", "مطاعم"]', '+966115678912', 'info@kap.gov.sa');

-- Insert sample organizer user
INSERT INTO users (email, password_hash, first_name, last_name, phone, organization_name, organization_type, bio, email_verified, status) VALUES
('admin@feaalyati.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.s5uuIy', 'أحمد', 'المحمد', '+966501234567', 'فعالياتي', 'company', 'منظم فعاليات محترف مع خبرة أكثر من 10 سنوات في تنظيم المؤتمرات والفعاليات الكبرى', TRUE, 'active'),
('organizer1@example.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.s5uuIy', 'فاطمة', 'العلي', '+966502345678', 'شركة الإبداع للفعاليات', 'company', 'متخصصة في تنظيم الفعاليات التقنية والمؤتمرات المهنية', TRUE, 'active'),
('organizer2@example.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.s5uuIy', 'محمد', 'السعد', '+966503456789', 'مؤسسة التطوير الثقافي', 'nonprofit', 'منظم فعاليات ثقافية وتراثية هادفة لخدمة المجتمع', TRUE, 'active');

-- Insert sample events
INSERT INTO events (organizer_id, category_id, venue_id, title_ar, title_en, description_ar, description_en, short_description_ar, short_description_en, event_type, start_date, end_date, registration_start, registration_end, capacity, price, is_free, status, featured, tags, images) VALUES
(1, 1, 1, 'مؤتمر التكنولوجيا والابتكار 2024', 'Technology and Innovation Conference 2024', 'مؤتمر سنوي يجمع رواد التكنولوجيا والابتكار لمناقشة أحدث التطورات في مجال التقنية والذكاء الاصطناعي والتحول الرقمي. يشارك في المؤتمر نخبة من الخبراء والمتخصصين من داخل المملكة وخارجها.', 'Annual conference bringing together technology and innovation leaders to discuss the latest developments in technology, artificial intelligence, and digital transformation.', 'مؤتمر سنوي يجمع رواد التكنولوجيا والابتكار', 'Annual technology and innovation conference', 'conference', '2024-03-15 09:00:00', '2024-03-17 17:00:00', '2024-02-01 00:00:00', '2024-03-10 23:59:59', 500, 299.00, FALSE, 'published', TRUE, '["تكنولوجيا", "ابتكار", "ذكاء اصطناعي", "تحول رقمي"]', '["tech-conference-1.jpg", "tech-conference-2.jpg"]'),

(2, 2, 2, 'ورشة تطوير تطبيقات الجوال', 'Mobile App Development Workshop', 'ورشة عمل مكثفة لتعلم تطوير تطبيقات الجوال باستخدام أحدث التقنيات والأدوات. تشمل الورشة التطبيق العملي وبناء تطبيق حقيقي خلال الورشة.', 'Intensive workshop for learning mobile app development using the latest technologies and tools.', 'ورشة عمل مكثفة لتعلم تطوير تطبيقات الجوال', 'Intensive mobile app development workshop', 'workshop', '2024-02-20 10:00:00', '2024-02-22 16:00:00', '2024-01-15 00:00:00', '2024-02-15 23:59:59', 50, 150.00, FALSE, 'published', FALSE, '["تطوير", "تطبيقات", "جوال", "برمجة"]', '["mobile-workshop-1.jpg"]'),

(3, 6, 3, 'معرض التراث السعودي', 'Saudi Heritage Exhibition', 'معرض يستعرض التراث السعودي الأصيل من خلال عرض القطع التراثية والحرف اليدوية والأزياء الشعبية. يهدف المعرض إلى التعريف بالثقافة السعودية العريقة.', 'Exhibition showcasing authentic Saudi heritage through traditional artifacts, handicrafts, and folk costumes.', 'معرض يستعرض التراث السعودي الأصيل', 'Exhibition showcasing authentic Saudi heritage', 'exhibition', '2024-04-01 10:00:00', '2024-04-07 22:00:00', '2024-03-01 00:00:00', '2024-03-25 23:59:59', 200, 0.00, TRUE, 'published', TRUE, '["تراث", "ثقافة", "سعودي", "معرض"]', '["heritage-exhibition-1.jpg", "heritage-exhibition-2.jpg"]'),

(1, 3, 4, 'ندوة ريادة الأعمال للشباب', 'Youth Entrepreneurship Seminar', 'ندوة تهدف إلى تشجيع الشباب على ريادة الأعمال وتقديم النصائح والإرشادات للبدء في المشاريع التجارية الناجحة.', 'Seminar aimed at encouraging youth entrepreneurship and providing advice for starting successful businesses.', 'ندوة تهدف إلى تشجيع الشباب على ريادة الأعمال', 'Seminar encouraging youth entrepreneurship', 'seminar', '2024-02-28 14:00:00', '2024-02-28 18:00:00', '2024-02-10 00:00:00', '2024-02-25 23:59:59', 100, 0.00, TRUE, 'published', FALSE, '["ريادة أعمال", "شباب", "مشاريع", "تطوير"]', '["entrepreneurship-seminar-1.jpg"]');

-- Insert sample registrations
INSERT INTO event_registrations (event_id, attendee_name, attendee_email, attendee_phone, attendee_organization, status, payment_status, payment_amount, registered_at) VALUES
(1, 'سارة أحمد الزهراني', 'sara.alzahrani@email.com', '+966501111111', 'شركة التقنية المتقدمة', 'confirmed', 'paid', 299.00, '2024-02-05 10:30:00'),
(1, 'خالد محمد العتيبي', 'khalid.alotaibi@email.com', '+966502222222', 'جامعة الملك فهد', 'confirmed', 'paid', 299.00, '2024-02-06 14:15:00'),
(1, 'نورا عبدالله القحطاني', 'nora.alqahtani@email.com', '+966503333333', 'مستقلة', 'pending', 'pending', 299.00, '2024-02-07 09:45:00'),
(2, 'أحمد سعد الغامدي', 'ahmed.alghamdi@email.com', '+966504444444', 'شركة الحلول الذكية', 'confirmed', 'paid', 150.00, '2024-01-20 16:20:00'),
(3, 'فاطمة علي الشهري', 'fatima.alshahri@email.com', '+966505555555', 'وزارة الثقافة', 'confirmed', 'paid', 0.00, '2024-03-05 11:10:00'),
(4, 'عبدالرحمن يوسف الدوسري', 'abdulrahman.aldosari@email.com', '+966506666666', 'طالب جامعي', 'confirmed', 'paid', 0.00, '2024-02-15 13:30:00');

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, setting_type, description_ar, description_en, is_public) VALUES
('site_name_ar', 'فعالياتي', 'string', 'اسم الموقع باللغة العربية', 'Site name in Arabic', TRUE),
('site_name_en', 'Feaalyati', 'string', 'اسم الموقع باللغة الإنجليزية', 'Site name in English', TRUE),
('contact_email', 'info@feaalyati.com', 'string', 'البريد الإلكتروني للتواصل', 'Contact email address', TRUE),
('contact_phone', '+966123456789', 'string', 'رقم الهاتف للتواصل', 'Contact phone number', TRUE),
('max_event_capacity', '10000', 'number', 'الحد الأقصى لسعة الفعالية', 'Maximum event capacity', FALSE),
('registration_reminder_days', '3', 'number', 'عدد الأيام قبل إرسال تذكير التسجيل', 'Days before sending registration reminder', FALSE),
('event_approval_required', 'false', 'boolean', 'هل تحتاج الفعاليات لموافقة قبل النشر', 'Whether events need approval before publishing', FALSE);
