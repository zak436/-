# 🚀 Feaalyati Integration Setup Guide

## Quick Start Instructions

### 1. **Backend Setup**

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your database and email settings

# Setup database and start server
npm run setup
npm run dev
```

### 2. **Frontend Integration Status**

✅ **Completed Integrations:**

- **Authentication System**
  - Login/Signup forms connected to backend API
  - JWT token management
  - Auto-redirect for protected pages
  - User profile management

- **Event Management**
  - Event creation with image upload
  - Event listing with real data
  - Event details page
  - Dashboard with real statistics

- **Registration System**
  - Event registration form
  - Email confirmations
  - Registration management

- **API Service Layer**
  - Centralized API communication (`js/api.js`)
  - Error handling and loading states
  - Authentication middleware

### 3. **Updated Files**

**New Files Created:**
- `js/api.js` - Main API service layer
- `js/events.js` - Events listing functionality
- `js/event-registration.js` - Registration handling
- `js/event-detail.js` - Event details page

**Updated Files:**
- `js/auth.js` - Connected to backend API
- `js/dashboard.js` - Real data from backend
- `js/create-event.js` - Backend integration
- `login.html`, `signup.html` - Added API script
- `dashboard.html` - Added API script
- `create-event.html` - Added API script
- `index.html` - Dynamic auth buttons

### 4. **Backend API Endpoints**

**Authentication:**
- `POST /api/auth/register` - Register organizer
- `POST /api/auth/login` - Login
- `GET /api/auth/profile` - Get profile
- `POST /api/auth/logout` - Logout

**Events:**
- `GET /api/events` - List events
- `GET /api/events/:id` - Get event details
- `POST /api/events` - Create event
- `PUT /api/events/:id` - Update event
- `DELETE /api/events/:id` - Delete event

**Registrations:**
- `POST /api/registrations/events/:id/register` - Register for event
- `GET /api/registrations/:id` - Get registration details

**Dashboard:**
- `GET /api/dashboard/overview` - Dashboard statistics
- `GET /api/dashboard/events-summary` - Events summary

### 5. **Testing the Integration**

1. **Start the backend:**
   ```bash
   npm run dev
   ```

2. **Open your frontend** (serve via local server)

3. **Test the flow:**
   - Register a new organizer account
   - Login with the account
   - Create a new event
   - View the dashboard
   - Browse events on the main page

### 6. **Environment Configuration**

Make sure your `.env` file has:

```env
# Server
PORT=3001
NODE_ENV=development

# Database
DB_HOST=localhost
DB_PORT=3306
DB_NAME=feaalyati_db
DB_USER=root
DB_PASSWORD=your_password

# JWT
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRES_IN=7d

# Email (for notifications)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASSWORD=your_app_password

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

### 7. **Frontend Server Setup**

Since this is a static frontend, you can serve it using:

```bash
# Using Python
python -m http.server 3000

# Using Node.js
npx serve -p 3000

# Using PHP
php -S localhost:3000
```

### 8. **Key Features Working**

✅ **User Authentication**
- Organizer registration and login
- JWT token management
- Protected routes

✅ **Event Management**
- Create events with images
- Edit and delete events
- View event statistics

✅ **Dashboard**
- Real-time statistics
- Recent events
- Registration analytics

✅ **Event Registration**
- Public event registration
- Email confirmations
- Registration management

✅ **File Uploads**
- Event images (up to 5 per event)
- Profile images
- Automatic image processing

### 9. **Next Steps**

To complete the integration:

1. **Add API scripts to remaining pages:**
   - `events.html` - Add events listing
   - `event-detail.html` - Add event details
   - `register.html` - Add registration form

2. **Enhance UI feedback:**
   - Loading spinners
   - Success/error messages
   - Form validation

3. **Add missing pages:**
   - My Events page for organizers
   - Registration management
   - Profile settings

### 10. **Troubleshooting**

**Common Issues:**

1. **CORS Errors:**
   - Make sure backend is running on port 3001
   - Frontend should be on port 3000

2. **Database Connection:**
   - Check MySQL is running
   - Verify database credentials in `.env`

3. **Authentication Issues:**
   - Clear localStorage and try again
   - Check JWT token in browser dev tools

4. **API Errors:**
   - Check browser console for errors
   - Verify backend logs

### 11. **Production Deployment**

For production:

1. **Backend:**
   - Set `NODE_ENV=production`
   - Use production database
   - Configure proper email service
   - Set up SSL certificates

2. **Frontend:**
   - Update API base URL in `js/api.js`
   - Minify and optimize assets
   - Set up CDN for images

---

## 🎉 Integration Complete!

Your Feaalyati platform now has a fully functional backend integrated with the frontend. Users can register as organizers, create events, manage registrations, and view analytics through a beautiful Arabic interface.

The system supports:
- ✅ Arabic language and RTL layout
- ✅ Organizer-only registration (no regular users)
- ✅ Comprehensive event management
- ✅ Real-time dashboard analytics
- ✅ Email notifications
- ✅ File upload and processing
- ✅ Secure authentication
- ✅ Mobile-responsive design

Start the backend server and test the complete flow!
