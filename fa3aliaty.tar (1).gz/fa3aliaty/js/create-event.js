document.addEventListener('DOMContentLoaded', function() {
    // Total number of steps
    const totalSteps = 15;
    
    // Step titles
    const stepTitles = [
        'نوع الفعالية',
        'حجم الصالة',
        'اختيار الصالة',
        'عدد المدعوين',
        'وقت الفعالية',
        'الزينة',
        'صالة أطفال',
        'مسابقات وجوائز',
        'الضيافة',
        'كراج سيارات',
        'انترنت مجاني',
        'دعاية وإعلان',
        'الجهات الراعية',
        'الأمن والسلامة',
        'نهاية العملية'
    ];
    
    // Generate progress steps
    const progressSteps = document.getElementById('progressSteps');
    for (let i = 1; i <= totalSteps; i++) {
        const stepIndicator = document.createElement('div');
        stepIndicator.className = 'step-indicator';
        stepIndicator.setAttribute('data-step', i);
        stepIndicator.textContent = i;
        
        // Add tooltip/label for step title
        const stepLabel = document.createElement('div');
        stepLabel.className = 'step-label';
        stepLabel.textContent = stepTitles[i-1];
        stepIndicator.appendChild(stepLabel);
        
        progressSteps.appendChild(stepIndicator);
    }
    
    // Set first step as active
    updateStepIndicators(1);
    
    // Next button click event
    const nextButtons = document.querySelectorAll('.next-btn');
    nextButtons.forEach(button => {
        button.addEventListener('click', function() {
            const nextStep = parseInt(this.getAttribute('data-next'));
            goToStep(nextStep);
        });
    });
    
    // Previous button click event
    const prevButtons = document.querySelectorAll('.prev-btn');
    prevButtons.forEach(button => {
        button.addEventListener('click', function() {
            const prevStep = parseInt(this.getAttribute('data-prev'));
            goToStep(prevStep);
        });
    });
    
    // Make step indicators clickable
    const stepIndicators = document.querySelectorAll('.step-indicator');
    stepIndicators.forEach(indicator => {
        indicator.addEventListener('click', function() {
            const step = parseInt(this.getAttribute('data-step'));
            goToStep(step);
        });
    });
    
    // Go to specific step
    function goToStep(stepNumber) {
        // Hide all steps
        const formSteps = document.querySelectorAll('.form-step');
        formSteps.forEach(step => {
            step.classList.remove('active');
        });
        
        // Show target step
        const targetStep = document.getElementById('step' + stepNumber);
        targetStep.classList.add('active');
        
        // Update progress bar and step indicators
        updateStepIndicators(stepNumber);
        
        // Scroll to top of form
        window.scrollTo({
            top: document.querySelector('.wizard-container').offsetTop - 100,
            behavior: 'smooth'
        });
    }
    
    // Update step indicators and progress bar
    function updateStepIndicators(currentStep) {
        const stepIndicators = document.querySelectorAll('.step-indicator');
        const progressBar = document.getElementById('progressBar');
        
        // Calculate progress percentage
        const progressPercentage = ((currentStep - 1) / (totalSteps - 1)) * 100;
        progressBar.style.width = progressPercentage + '%';
        
        // Update step indicators
        stepIndicators.forEach((indicator, index) => {
            const step = index + 1;
            
            // Reset all classes
            indicator.classList.remove('active', 'completed');
            
            if (step < currentStep) {
                // Previous steps
                indicator.classList.add('completed');
            } else if (step === currentStep) {
                // Current step
                indicator.classList.add('active');
            }
        });
    }
    
    // Toggle conditional fields
    
    // 1. Event Category - Show "Other" field when "Other" is selected
    const eventCategory = document.getElementById('eventCategory');
    const otherCategoryGroup = document.getElementById('otherCategoryGroup');
    
    eventCategory.addEventListener('change', function() {
        if (this.value === 'other') {
            otherCategoryGroup.style.display = 'block';
        } else {
            otherCategoryGroup.style.display = 'none';
        }
    });
    
    // 2. Decoration - Show custom details when "Custom" is selected
    const decorationOptions = document.querySelectorAll('input[name="decoration"]');
    const customDecorGroup = document.getElementById('customDecorGroup');
    
    decorationOptions.forEach(option => {
        option.addEventListener('change', function() {
            if (this.value === 'custom') {
                customDecorGroup.style.display = 'block';
            } else {
                customDecorGroup.style.display = 'none';
            }
        });
    });
    
    // 3. Children Room toggle
    const childrenRoomToggle = document.getElementById('childrenRoom');
    const childrenRoomFields = document.getElementById('childrenRoomFields');
    
    childrenRoomToggle.addEventListener('change', function() {
        if (this.checked) {
            childrenRoomFields.classList.add('show');
        } else {
            childrenRoomFields.classList.remove('show');
        }
    });
    
    // 4. Contests toggle
    const hasContestsToggle = document.getElementById('hasContests');
    const contestsFields = document.getElementById('contestsFields');
    
    hasContestsToggle.addEventListener('change', function() {
        if (this.checked) {
            contestsFields.classList.add('show');
        } else {
            contestsFields.classList.remove('show');
        }
    });
    
    // 5. Catering - Show custom details when "Custom" is selected
    const cateringOptions = document.querySelectorAll('input[name="catering"]');
    const customCateringGroup = document.getElementById('customCateringGroup');
    
    cateringOptions.forEach(option => {
        option.addEventListener('change', function() {
            if (this.value === 'custom') {
                customCateringGroup.style.display = 'block';
            } else {
                customCateringGroup.style.display = 'none';
            }
        });
    });
    
    // 6. Parking toggle
    const hasParkingToggle = document.getElementById('hasParking');
    const parkingFields = document.getElementById('parkingFields');
    
    hasParkingToggle.addEventListener('change', function() {
        if (this.checked) {
            parkingFields.classList.add('show');
        } else {
            parkingFields.classList.remove('show');
        }
    });
    
    // 7. Free WiFi toggle
    const hasFreeWifiToggle = document.getElementById('hasFreeWifi');
    const wifiFields = document.getElementById('wifiFields');
    
    hasFreeWifiToggle.addEventListener('change', function() {
        if (this.checked) {
            wifiFields.classList.add('show');
        } else {
            wifiFields.classList.remove('show');
        }
    });
    
    // 8. Sponsors toggle
    const hasSponsorsToggle = document.getElementById('hasSponsors');
    const sponsorsFields = document.getElementById('sponsorsFields');
    
    hasSponsorsToggle.addEventListener('change', function() {
        if (this.checked) {
            sponsorsFields.classList.add('show');
        } else {
            sponsorsFields.classList.remove('show');
        }
    });
    
    // File upload handling
    const eventImages = document.getElementById('event_images');
    const sponsorLogo = document.getElementById('sponsorLogo');

    // Handle event images upload
    if (eventImages) {
        const eventImagesFileName = eventImages.parentElement.querySelector('.file-name');
        eventImages.addEventListener('change', function() {
            if (this.files.length > 0) {
                if (this.files.length === 1) {
                    eventImagesFileName.textContent = this.files[0].name;
                } else {
                    eventImagesFileName.textContent = `تم اختيار ${this.files.length} صور`;
                }

                // Validate file count
                if (this.files.length > 5) {
                    alert('يمكنك اختيار حتى 5 صور فقط');
                    this.value = '';
                    eventImagesFileName.textContent = 'لم يتم اختيار ملفات';
                }
            } else {
                eventImagesFileName.textContent = 'لم يتم اختيار ملفات';
            }
        });
    }

    // Handle sponsor logo upload
    if (sponsorLogo) {
        const fileName = sponsorLogo.parentElement.querySelector('.file-name');
        sponsorLogo.addEventListener('change', function() {
            if (this.files.length > 0) {
                if (this.files.length === 1) {
                    fileName.textContent = this.files[0].name;
                } else {
                    fileName.textContent = `تم اختيار ${this.files.length} ملفات`;
                }
            } else {
                fileName.textContent = 'لم يتم اختيار ملفات';
            }
        });
    }
    
    // Radio option highlighting
    const radioOptions = document.querySelectorAll('.radio-option');
    
    radioOptions.forEach(option => {
        const radioInput = option.querySelector('input[type="radio"]');
        
        radioInput.addEventListener('change', function() {
            // Remove selected class from all options in the same group
            const name = this.getAttribute('name');
            document.querySelectorAll(`input[name="${name}"]`).forEach(input => {
                input.closest('.radio-option').classList.remove('selected');
            });
            
            // Add selected class to the clicked option
            if (this.checked) {
                option.classList.add('selected');
            }
        });
    });
    
    // Simulate venue options based on date selection
    const eventDate = document.getElementById('eventDate');
    const venueOptions = document.getElementById('venueOptions');
    
    eventDate.addEventListener('change', function() {
        // Clear previous options
        venueOptions.innerHTML = '';
        
        // Simulate venue options (in a real app, these would come from an API based on date and size)
        const venues = [
            { id: 1, name: 'قاعة الأميرات', location: 'الرياض - حي العليا' },
            { id: 2, name: 'قاعة النخبة', location: 'الرياض - حي الملز' },
            { id: 3, name: 'قاعة الملكية', location: 'الرياض - حي النزهة' }
        ];
        
        venues.forEach(venue => {
            const venueOption = document.createElement('label');
            venueOption.className = 'radio-option';
            venueOption.innerHTML = `
                <input type="radio" name="venue" value="${venue.id}" required>
                <div>
                    <strong>${venue.name}</strong>
                    <div>${venue.location}</div>
                </div>
            `;
            venueOptions.appendChild(venueOption);
        });
        
        // Re-attach event listeners for the new radio options
        const newRadioOptions = venueOptions.querySelectorAll('.radio-option');
        newRadioOptions.forEach(option => {
            const radioInput = option.querySelector('input[type="radio"]');
            
            radioInput.addEventListener('change', function() {
                newRadioOptions.forEach(opt => opt.classList.remove('selected'));
                if (this.checked) {
                    option.classList.add('selected');
                }
            });
        });
    });
    
    // Add animation effects to steps
    const formSteps = document.querySelectorAll('.form-step');
    formSteps.forEach(step => {
        const stepIcon = step.querySelector('.step-icon');
        if (stepIcon) {
            stepIcon.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.1)';
                this.style.transition = 'transform 0.3s ease';
            });
            
            stepIcon.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        }
    });
    
    // Form submission
    const eventForm = document.getElementById('eventForm');

    eventForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Show loading state
        const submitButton = eventForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.disabled = true;
        submitButton.textContent = 'جاري إنشاء الفعالية...';

        try {
            // Collect form data
            const formData = new FormData(eventForm);
            const eventData = await processFormData(formData);

            // Get uploaded images
            const imageFiles = formData.getAll('event_images');

            // Create event via API
            const response = await window.api.createEventWithImages(eventData, imageFiles);

            // Show success message
            submitButton.textContent = 'تم إنشاء الفعالية بنجاح!';

            // Redirect to event details or dashboard
            setTimeout(() => {
                window.location.href = `event-detail.html?id=${response.event_id}`;
            }, 1500);

        } catch (error) {
            console.error('Error creating event:', error);

            // Show error message
            showErrorMessage(error.message);

            // Reset button
            submitButton.disabled = false;
            submitButton.textContent = originalText;
        }
    });
    
    // Function to create HTML content for the new event
    function createEventDetailPage(eventData) {
        // Build event object from form data
        const newEvent = {
            id: 'new',
            title: eventData.eventTitle || 'فعالية جديدة',
            banner: eventData.eventBanner || 'https://picsum.photos/1200/400',
            shortDescription: eventData.eventDescription || 'وصف الفعالية الجديدة',
            date: eventData.eventDate || new Date().toISOString().split('T')[0],
            time: eventData.eventTime || '09:00',
            duration: eventData.eventDuration || '2',
            location: eventData.venueLocation || 'موقع الفعالية',
            category: eventData.eventCategory || 'عام',
            organizerName: eventData.organizerName || 'منظم الفعالية',
            description: eventData.eventDetailedDescription || 'تفاصيل الفعالية',
            services: getSelectedServices(eventData),
            gallery: eventData.eventGallery ? eventData.eventGallery.split(',') : [],
            hasParking: eventData.hasParking === 'on',
            hasFreeWifi: eventData.hasFreeWifi === 'on',
            hasChildrenRoom: eventData.childrenRoom === 'on',
            hasContests: eventData.hasContests === 'on'
        };
        
        // Store the new event in localStorage to be used in event-detail.html
        localStorage.setItem('currentEvent', JSON.stringify(newEvent));
    }
    
    // Helper function to get selected services
    function getSelectedServices(eventData) {
        const services = [];
        
        if (eventData.hasFreeWifi === 'on') services.push({ icon: 'wifi', name: 'واي فاي مجاني' });
        if (eventData.catering === 'drinks' || eventData.catering === 'snacks' || eventData.catering === 'buffet') 
            services.push({ icon: 'coffee', name: 'استراحة قهوة' });
        if (eventData.catering === 'buffet') 
            services.push({ icon: 'utensils', name: 'وجبات غداء' });
        if (eventData.hasParking === 'on') 
            services.push({ icon: 'parking', name: 'مواقف مجانية' });
        if (eventData.childrenRoom === 'on') 
            services.push({ icon: 'child', name: 'منطقة أطفال' });
        
        // Add more default services
        services.push({ icon: 'wheelchair', name: 'تسهيلات لذوي الإعاقة' });
        
        if (eventData.safetyRequirements && eventData.safetyRequirements.includes('firstaid'))
            services.push({ icon: 'medkit', name: 'إسعافات أولية' });
            
        return services;
    }

    // Process form data for API submission
    async function processFormData(formData) {
        const eventData = {};

        // Basic event information
        eventData.title_ar = formData.get('eventTitle') || formData.get('event_title');
        eventData.description_ar = formData.get('eventDescription') || formData.get('event_description');
        eventData.short_description_ar = formData.get('eventShortDescription') || eventData.description_ar?.substring(0, 200);

        // Event type and category
        eventData.event_type = mapEventCategory(formData.get('eventCategory'));
        eventData.category_id = await getCategoryId(formData.get('eventCategory'));

        // Date and time
        const eventDate = formData.get('eventDate');
        const eventTime = formData.get('eventTime') || '09:00';
        const eventDuration = formData.get('eventDuration') || '2';

        if (eventDate) {
            eventData.start_date = `${eventDate}T${eventTime}:00`;

            // Calculate end date
            const startDate = new Date(eventData.start_date);
            startDate.setHours(startDate.getHours() + parseInt(eventDuration));
            eventData.end_date = startDate.toISOString();
        }

        // Venue and capacity
        eventData.venue_id = formData.get('venue');
        eventData.capacity = parseInt(formData.get('guestCount')) || null;

        // Pricing
        eventData.is_free = !formData.get('eventPrice') || formData.get('eventPrice') === '0';
        eventData.price = eventData.is_free ? 0 : parseFloat(formData.get('eventPrice')) || 0;

        // Additional features as custom fields
        eventData.custom_fields = {
            decoration: formData.get('decoration'),
            custom_decoration: formData.get('customDecoration'),
            children_room: formData.get('childrenRoom') === 'on',
            children_activities: formData.get('childrenActivities'),
            contests: formData.get('hasContests') === 'on',
            contest_details: formData.get('contestDetails'),
            catering: formData.get('catering'),
            custom_catering: formData.get('customCatering'),
            parking: formData.get('hasParking') === 'on',
            parking_details: formData.get('parkingDetails'),
            wifi: formData.get('hasFreeWifi') === 'on',
            wifi_details: formData.get('wifiDetails'),
            advertising: formData.get('advertising'),
            sponsors: formData.get('hasSponsors') === 'on',
            sponsor_details: formData.get('sponsorDetails'),
            safety_requirements: formData.getAll('safetyRequirements')
        };

        // Tags
        const tags = [];
        if (eventData.custom_fields.children_room) tags.push('أطفال');
        if (eventData.custom_fields.wifi) tags.push('واي فاي مجاني');
        if (eventData.custom_fields.parking) tags.push('مواقف مجانية');
        if (eventData.custom_fields.contests) tags.push('مسابقات');
        eventData.tags = tags;

        return eventData;
    }

    // Map frontend categories to backend event types
    function mapEventCategory(category) {
        const categoryMap = {
            'conference': 'conference',
            'workshop': 'workshop',
            'seminar': 'seminar',
            'exhibition': 'exhibition',
            'networking': 'networking',
            'cultural': 'cultural',
            'sports': 'sports',
            'entertainment': 'entertainment',
            'other': 'other'
        };

        return categoryMap[category] || 'other';
    }

    // Get category ID from backend
    async function getCategoryId(categoryName) {
        try {
            const response = await window.api.getEventCategories();
            const category = response.categories.find(cat =>
                cat.name_en.toLowerCase() === categoryName?.toLowerCase() ||
                cat.name_ar === categoryName
            );
            return category ? category.id : null;
        } catch (error) {
            console.error('Error getting categories:', error);
            return null;
        }
    }

    // Show error message
    function showErrorMessage(message) {
        // Remove existing error messages
        const existingError = document.querySelector('.event-error');
        if (existingError) {
            existingError.remove();
        }

        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'event-error';
        errorDiv.style.cssText = `
            background-color: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            border: 1px solid #fcc;
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            min-width: 300px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;
        errorDiv.textContent = message;

        // Add close button
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '×';
        closeBtn.style.cssText = `
            background: none;
            border: none;
            font-size: 20px;
            color: #c33;
            cursor: pointer;
            float: left;
            margin-right: 10px;
        `;
        closeBtn.onclick = () => errorDiv.remove();
        errorDiv.appendChild(closeBtn);

        // Insert error message
        document.body.appendChild(errorDiv);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.remove();
            }
        }, 5000);
    }
});