# Feaalyati Backend API

A comprehensive backend API for the Feaalyati events platform, built with Node.js, Express, and MySQL.

## Features

- **User Management**: Organizer registration, authentication, and profile management
- **Event Management**: Full CRUD operations for events with image uploads
- **Registration System**: Event registration with email confirmations
- **Dashboard Analytics**: Comprehensive statistics and insights
- **File Uploads**: Image processing and storage for events and profiles
- **Email Notifications**: Automated emails for registrations and confirmations
- **Arabic Language Support**: Full RTL support with Arabic content
- **Security**: JWT authentication, input validation, and rate limiting

## Tech Stack

- **Runtime**: Node.js 16+
- **Framework**: Express.js
- **Database**: MySQL 8.0+
- **Authentication**: JWT (JSON Web Tokens)
- **File Upload**: Multer + Sharp for image processing
- **Email**: Nodemailer
- **Validation**: Express-validator
- **Security**: Helmet, CORS, Rate limiting

## Project Structure

```
├── config/
│   ├── auth.js          # JWT configuration
│   └── database.js      # Database connection and utilities
├── controllers/
│   ├── authController.js
│   ├── eventController.js
│   └── registrationController.js
├── middleware/
│   ├── auth.js          # Authentication middleware
│   └── validation.js    # Input validation rules
├── models/
│   ├── User.js
│   ├── Event.js
│   └── Registration.js
├── routes/
│   ├── auth.js
│   ├── events.js
│   ├── registrations.js
│   ├── users.js
│   └── dashboard.js
├── utils/
│   ├── email.js         # Email templates and sending
│   └── upload.js        # File upload utilities
├── database/
│   ├── schema.sql       # Database schema
│   └── seed.sql         # Sample data
├── scripts/
│   └── migrate.js       # Database migration script
├── uploads/             # File upload directory
└── server.js           # Main application entry point
```

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd feaalyati-backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Configuration**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file with your configuration:
   ```env
   # Server
   PORT=3001
   NODE_ENV=development
   
   # Database
   DB_HOST=localhost
   DB_PORT=3306
   DB_NAME=feaalyati_db
   DB_USER=root
   DB_PASSWORD=your_password
   
   # JWT
   JWT_SECRET=your_super_secret_jwt_key
   JWT_EXPIRES_IN=7d
   
   # Email
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_USER=your_email@gmail.com
   EMAIL_PASSWORD=your_app_password
   
   # Frontend URL
   FRONTEND_URL=http://localhost:3000
   ```

4. **Database Setup**
   ```bash
   # Create database and run migrations with seed data
   npm run setup
   
   # Or run individually:
   npm run migrate  # Run migrations only
   npm run seed     # Seed data only
   ```

5. **Start the server**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new organizer
- `POST /api/auth/login` - Login organizer
- `POST /api/auth/verify-email` - Verify email address
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password
- `GET /api/auth/profile` - Get current user profile
- `POST /api/auth/change-password` - Change password
- `POST /api/auth/logout` - Logout

### Events
- `GET /api/events` - Get events (public)
- `GET /api/events/:id` - Get event details
- `GET /api/events/categories` - Get event categories
- `GET /api/events/venues` - Get venues
- `POST /api/events` - Create event (organizer)
- `PUT /api/events/:id` - Update event (organizer)
- `DELETE /api/events/:id` - Delete event (organizer)
- `GET /api/events/organizer/events` - Get organizer's events
- `GET /api/events/:id/registrations` - Get event registrations
- `GET /api/events/:id/stats` - Get event statistics

### Registrations
- `POST /api/registrations/events/:id/register` - Register for event
- `GET /api/registrations/:id` - Get registration details
- `GET /api/registrations/token/:token` - Get registration by token
- `GET /api/registrations/confirm/:token` - Confirm registration
- `PUT /api/registrations/:id/cancel` - Cancel registration
- `GET /api/registrations/email/:email` - Get registrations by email

### Users
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `POST /api/users/profile/image` - Upload profile image
- `GET /api/users/stats` - Get user statistics

### Dashboard
- `GET /api/dashboard/overview` - Dashboard overview
- `GET /api/dashboard/events-summary` - Events summary
- `GET /api/dashboard/registrations-analytics` - Registration analytics
- `GET /api/dashboard/popular-events` - Popular events
- `GET /api/dashboard/revenue-analytics` - Revenue analytics

## Database Schema

The database includes the following main tables:

- **users**: Organizer accounts and profiles
- **events**: Event information and details
- **event_categories**: Event classification
- **venues**: Event locations
- **event_registrations**: User registrations for events
- **event_analytics**: Event view and interaction tracking
- **notifications**: System notifications
- **system_settings**: Application configuration

## File Uploads

The API supports image uploads for:
- Event images (up to 5 images per event)
- User profile images

Images are automatically processed and resized using Sharp.

## Email System

Automated emails are sent for:
- Email verification
- Password reset
- Registration confirmation
- Payment confirmation
- Registration cancellation

## Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Input validation and sanitization
- Rate limiting
- CORS protection
- Helmet security headers
- File upload restrictions

## Development

### Running Tests
```bash
npm test
```

### Database Operations
```bash
# Reset database
npm run reset

# Run migrations only
npm run migrate

# Seed data only
npm run seed
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| PORT | Server port | 3001 |
| NODE_ENV | Environment | development |
| DB_HOST | Database host | localhost |
| DB_PORT | Database port | 3306 |
| DB_NAME | Database name | feaalyati_db |
| DB_USER | Database user | root |
| DB_PASSWORD | Database password | - |
| JWT_SECRET | JWT secret key | - |
| JWT_EXPIRES_IN | JWT expiration | 7d |
| EMAIL_HOST | SMTP host | smtp.gmail.com |
| EMAIL_PORT | SMTP port | 587 |
| EMAIL_USER | SMTP username | - |
| EMAIL_PASSWORD | SMTP password | - |
| FRONTEND_URL | Frontend URL | http://localhost:3000 |
| MAX_FILE_SIZE | Max upload size | 5242880 (5MB) |

## Production Deployment

1. Set `NODE_ENV=production`
2. Configure production database
3. Set up proper email service
4. Configure reverse proxy (nginx)
5. Set up SSL certificates
6. Configure file storage (AWS S3, etc.)
7. Set up monitoring and logging

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please contact the development team or create an issue in the repository.
