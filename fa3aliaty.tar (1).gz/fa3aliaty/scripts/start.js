#!/usr/bin/env node

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function checkEnvFile() {
  const envPath = path.join(__dirname, '../.env');
  if (!fs.existsSync(envPath)) {
    log('⚠️  .env file not found!', 'yellow');
    log('📝 Please copy .env.example to .env and configure your settings:', 'cyan');
    log('   cp .env.example .env', 'cyan');
    return false;
  }
  return true;
}

function runCommand(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: true,
      ...options
    });

    child.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Command failed with exit code ${code}`));
      }
    });

    child.on('error', reject);
  });
}

async function setupDatabase() {
  try {
    log('🔄 Setting up database...', 'blue');
    await runCommand('npm', ['run', 'setup']);
    log('✅ Database setup completed!', 'green');
  } catch (error) {
    log('❌ Database setup failed:', 'red');
    log(error.message, 'red');
    throw error;
  }
}

async function startServer() {
  try {
    log('🚀 Starting development server...', 'blue');
    await runCommand('npm', ['run', 'dev']);
  } catch (error) {
    log('❌ Server failed to start:', 'red');
    log(error.message, 'red');
    throw error;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  log('🎉 Welcome to Feaalyati Backend!', 'magenta');
  log('=====================================', 'magenta');

  // Check environment file
  if (!checkEnvFile()) {
    process.exit(1);
  }

  switch (command) {
    case 'setup':
      log('🔧 Running initial setup...', 'cyan');
      await setupDatabase();
      log('✅ Setup completed! You can now start the server with: npm run dev', 'green');
      break;

    case 'dev':
    case 'start':
    default:
      log('🔍 Checking if database is set up...', 'cyan');
      
      // Check if we need to run setup first
      try {
        await runCommand('node', ['-e', `
          const { testConnection } = require('./config/database');
          testConnection().then(success => {
            if (!success) process.exit(1);
          }).catch(() => process.exit(1));
        `]);
        
        log('✅ Database connection successful!', 'green');
        await startServer();
      } catch (error) {
        log('⚠️  Database not accessible. Running setup first...', 'yellow');
        await setupDatabase();
        await startServer();
      }
      break;
  }
}

// Handle process termination
process.on('SIGINT', () => {
  log('\n👋 Goodbye!', 'cyan');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('\n👋 Server terminated!', 'cyan');
  process.exit(0);
});

// Run the script
if (require.main === module) {
  main().catch(error => {
    log('❌ Script failed:', 'red');
    log(error.message, 'red');
    process.exit(1);
  });
}

module.exports = { main };
