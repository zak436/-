const express = require('express');
const path = require('path');
const router = express.Router();
const User = require('../models/User');
const { authenticateToken } = require('../middleware/auth');
const { uploadProfileImage, handleUploadError, processProfileImage } = require('../utils/upload');

// Protected routes - require authentication
router.use(authenticateToken);

// Get user profile
router.get('/profile', async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message_ar: 'المستخدم غير موجود'
      });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      error: 'Failed to get profile',
      message_ar: 'فشل في جلب الملف الشخصي'
    });
  }
});

// Update user profile
router.put('/profile', async (req, res) => {
  try {
    const userId = req.userId;
    const updateData = req.body;

    // Remove sensitive fields that shouldn't be updated here
    delete updateData.email;
    delete updateData.password;
    delete updateData.password_hash;

    const success = await User.updateProfile(userId, updateData);
    
    if (!success) {
      return res.status(400).json({
        error: 'No valid fields to update',
        message_ar: 'لا توجد حقول صالحة للتحديث'
      });
    }

    res.json({
      message: 'Profile updated successfully',
      message_ar: 'تم تحديث الملف الشخصي بنجاح'
    });

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      error: 'Failed to update profile',
      message_ar: 'فشل في تحديث الملف الشخصي'
    });
  }
});

// Upload profile image
router.post('/profile/image', 
  uploadProfileImage.single('image'),
  handleUploadError,
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          error: 'No image file provided',
          message_ar: 'لم يتم توفير ملف صورة'
        });
      }

      const userId = req.userId;
      
      // Process the image
      const processedPath = await processProfileImage(req.file.path);
      const imagePath = `/uploads/profiles/${path.basename(processedPath)}`;
      
      // Update user profile image
      const success = await User.updateProfileImage(userId, imagePath);
      
      if (!success) {
        return res.status(500).json({
          error: 'Failed to update profile image',
          message_ar: 'فشل في تحديث صورة الملف الشخصي'
        });
      }

      res.json({
        message: 'Profile image updated successfully',
        message_ar: 'تم تحديث صورة الملف الشخصي بنجاح',
        image_url: imagePath
      });

    } catch (error) {
      console.error('Upload profile image error:', error);
      res.status(500).json({
        error: 'Failed to upload profile image',
        message_ar: 'فشل في رفع صورة الملف الشخصي'
      });
    }
  }
);

// Get user statistics
router.get('/stats', async (req, res) => {
  try {
    const userId = req.userId;
    const stats = await User.getStats(userId);

    res.json({ stats });
  } catch (error) {
    console.error('Get user stats error:', error);
    res.status(500).json({
      error: 'Failed to get user statistics',
      message_ar: 'فشل في جلب إحصائيات المستخدم'
    });
  }
});

// Deactivate account
router.delete('/account', async (req, res) => {
  try {
    const userId = req.userId;
    const success = await User.deactivate(userId);
    
    if (!success) {
      return res.status(500).json({
        error: 'Failed to deactivate account',
        message_ar: 'فشل في إلغاء تفعيل الحساب'
      });
    }

    res.json({
      message: 'Account deactivated successfully',
      message_ar: 'تم إلغاء تفعيل الحساب بنجاح'
    });

  } catch (error) {
    console.error('Deactivate account error:', error);
    res.status(500).json({
      error: 'Failed to deactivate account',
      message_ar: 'فشل في إلغاء تفعيل الحساب'
    });
  }
});

module.exports = router;
