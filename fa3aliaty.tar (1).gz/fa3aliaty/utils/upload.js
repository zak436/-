const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');

// Ensure upload directories exist
const ensureDirectoryExists = (dirPath) => {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
};

// Initialize upload directories
const uploadPaths = {
  events: path.join(__dirname, '../uploads/events'),
  profiles: path.join(__dirname, '../uploads/profiles'),
  temp: path.join(__dirname, '../uploads/temp')
};

Object.values(uploadPaths).forEach(ensureDirectoryExists);

// File filter function
const fileFilter = (req, file, cb) => {
  // Check file type
  const allowedTypes = /jpeg|jpg|png|gif|webp/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb(new Error('Only image files are allowed (jpeg, jpg, png, gif, webp)'));
  }
};

// Storage configuration for event images
const eventImageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadPaths.events);
  },
  filename: (req, file, cb) => {
    const uniqueName = `event-${uuidv4()}-${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

// Storage configuration for profile images
const profileImageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadPaths.profiles);
  },
  filename: (req, file, cb) => {
    const uniqueName = `profile-${uuidv4()}-${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

// Multer configurations
const uploadEventImages = multer({
  storage: eventImageStorage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024, // 5MB default
    files: 5 // Maximum 5 images per event
  },
  fileFilter
});

const uploadProfileImage = multer({
  storage: profileImageStorage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024, // 5MB default
    files: 1 // Only one profile image
  },
  fileFilter
});

// Image processing functions
const processEventImage = async (filePath, options = {}) => {
  try {
    const {
      width = 800,
      height = 600,
      quality = 80
    } = options;

    const processedPath = filePath.replace(/\.[^/.]+$/, '_processed.jpg');

    await sharp(filePath)
      .resize(width, height, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality })
      .toFile(processedPath);

    // Remove original file
    fs.unlinkSync(filePath);

    return processedPath;
  } catch (error) {
    console.error('Image processing error:', error);
    throw error;
  }
};

const processProfileImage = async (filePath, options = {}) => {
  try {
    const {
      size = 300,
      quality = 85
    } = options;

    const processedPath = filePath.replace(/\.[^/.]+$/, '_processed.jpg');

    await sharp(filePath)
      .resize(size, size, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality })
      .toFile(processedPath);

    // Remove original file
    fs.unlinkSync(filePath);

    return processedPath;
  } catch (error) {
    console.error('Profile image processing error:', error);
    throw error;
  }
};

// Generate thumbnail
const generateThumbnail = async (filePath, thumbnailPath, size = 200) => {
  try {
    await sharp(filePath)
      .resize(size, size, {
        fit: 'cover',
        position: 'center'
      })
      .jpeg({ quality: 70 })
      .toFile(thumbnailPath);

    return thumbnailPath;
  } catch (error) {
    console.error('Thumbnail generation error:', error);
    throw error;
  }
};

// Delete file
const deleteFile = (filePath) => {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  } catch (error) {
    console.error('File deletion error:', error);
    return false;
  }
};

// Clean up old files (for maintenance)
const cleanupOldFiles = (directory, maxAgeInDays = 30) => {
  try {
    const files = fs.readdirSync(directory);
    const maxAge = maxAgeInDays * 24 * 60 * 60 * 1000; // Convert to milliseconds
    const now = Date.now();

    files.forEach(file => {
      const filePath = path.join(directory, file);
      const stats = fs.statSync(filePath);
      
      if (now - stats.mtime.getTime() > maxAge) {
        fs.unlinkSync(filePath);
        console.log(`Deleted old file: ${file}`);
      }
    });
  } catch (error) {
    console.error('Cleanup error:', error);
  }
};

// Middleware for handling upload errors
const handleUploadError = (error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'File too large',
        message_ar: 'حجم الملف كبير جداً',
        max_size: `${(parseInt(process.env.MAX_FILE_SIZE) || 5242880) / 1024 / 1024}MB`
      });
    }
    
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        error: 'Too many files',
        message_ar: 'عدد الملفات كبير جداً'
      });
    }
    
    if (error.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({
        error: 'Unexpected file field',
        message_ar: 'حقل ملف غير متوقع'
      });
    }
  }
  
  if (error.message.includes('Only image files are allowed')) {
    return res.status(400).json({
      error: 'Invalid file type',
      message_ar: 'نوع الملف غير مدعوم',
      allowed_types: 'jpeg, jpg, png, gif, webp'
    });
  }
  
  return res.status(500).json({
    error: 'Upload failed',
    message_ar: 'فشل في رفع الملف'
  });
};

// Get file info
const getFileInfo = (filePath) => {
  try {
    if (!fs.existsSync(filePath)) {
      return null;
    }
    
    const stats = fs.statSync(filePath);
    return {
      size: stats.size,
      created: stats.birthtime,
      modified: stats.mtime,
      extension: path.extname(filePath),
      name: path.basename(filePath)
    };
  } catch (error) {
    console.error('Get file info error:', error);
    return null;
  }
};

// Validate image dimensions
const validateImageDimensions = async (filePath, minWidth = 100, minHeight = 100, maxWidth = 4000, maxHeight = 4000) => {
  try {
    const metadata = await sharp(filePath).metadata();
    
    if (metadata.width < minWidth || metadata.height < minHeight) {
      throw new Error(`Image too small. Minimum dimensions: ${minWidth}x${minHeight}`);
    }
    
    if (metadata.width > maxWidth || metadata.height > maxHeight) {
      throw new Error(`Image too large. Maximum dimensions: ${maxWidth}x${maxHeight}`);
    }
    
    return true;
  } catch (error) {
    console.error('Image validation error:', error);
    throw error;
  }
};

module.exports = {
  uploadEventImages,
  uploadProfileImage,
  processEventImage,
  processProfileImage,
  generateThumbnail,
  deleteFile,
  cleanupOldFiles,
  handleUploadError,
  getFileInfo,
  validateImageDimensions,
  uploadPaths
};
