document.addEventListener('DOMContentLoaded', async function() {
    // Check authentication
    if (!window.api.isAuthenticated()) {
        window.location.href = 'login.html';
        return;
    }

    try {
        // Load user data from API
        await loadUserData();

        // Load dashboard statistics
        await loadDashboardStats();

        // Load recent events
        await loadRecentEvents();

    } catch (error) {
        console.error('Dashboard loading error:', error);
        showErrorMessage('فشل في تحميل بيانات لوحة التحكم');
    }

    // Logout button event listener
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function(e) {
            e.preventDefault();

            try {
                await window.api.logout();
                window.location.href = 'index.html';
            } catch (error) {
                console.error('Logout error:', error);
                // Force logout even if API call fails
                localStorage.clear();
                window.location.href = 'index.html';
            }
        });
    }

    // Card click events
    const dashboardCards = document.querySelectorAll('.dashboard-card');
    dashboardCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Add a subtle animation effect when clicked
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
        });
    });
});

// Load user data from API
async function loadUserData() {
    try {
        const response = await window.api.getProfile();
        const user = response.user;

        // Set user name and initial in the UI
        const userName = `${user.first_name} ${user.last_name}`;
        const userInitial = user.first_name.charAt(0);

        const userNameElement = document.querySelector('.user-name');
        const userAvatarElement = document.querySelector('.user-avatar');

        if (userNameElement) userNameElement.textContent = userName;
        if (userAvatarElement) userAvatarElement.textContent = userInitial;

        // Update organization info if available
        const orgElement = document.querySelector('.user-organization');
        if (orgElement && user.organization_name) {
            orgElement.textContent = user.organization_name;
        }

    } catch (error) {
        console.error('Error loading user data:', error);
        throw error;
    }
}

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const response = await window.api.getDashboardOverview();
        const overview = response.overview;

        // Update stats with real data
        updateStats({
            activeEvents: overview.published_events || 0,
            totalRegistrants: overview.total_registrations || 0,
            completedEvents: overview.total_events || 0,
            newRegistrations: overview.registrations_this_month || 0
        });

    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        // Fallback to demo data
        updateStats({
            activeEvents: 0,
            totalRegistrants: 0,
            completedEvents: 0,
            newRegistrations: 0
        });
    }
}

// Load recent events
async function loadRecentEvents() {
    try {
        const response = await window.api.getOrganizerEvents({
            limit: 5,
            sort: 'created_at',
            order: 'DESC'
        });

        displayRecentEvents(response.events);

    } catch (error) {
        console.error('Error loading recent events:', error);
    }
}

// Display recent events in the dashboard
function displayRecentEvents(events) {
    const recentEventsContainer = document.querySelector('.recent-events');

    if (!recentEventsContainer || !events || events.length === 0) {
        return;
    }

    const eventsHTML = events.map(event => `
        <div class="recent-event-item">
            <div class="event-info">
                <h4>${event.title_ar}</h4>
                <p class="event-date">${formatDate(event.start_date)}</p>
                <span class="event-status status-${event.status}">${getStatusText(event.status)}</span>
            </div>
            <div class="event-stats">
                <span class="registrations">${event.registration_count || 0} مسجل</span>
                <span class="views">${event.views_count || 0} مشاهدة</span>
            </div>
        </div>
    `).join('');

    recentEventsContainer.innerHTML = eventsHTML;
}

// Helper function to format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Helper function to get status text in Arabic
function getStatusText(status) {
    const statusMap = {
        'draft': 'مسودة',
        'published': 'منشور',
        'cancelled': 'ملغي',
        'completed': 'مكتمل',
        'postponed': 'مؤجل'
    };
    return statusMap[status] || status;
}

// Show error message
function showErrorMessage(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'dashboard-error';
    errorDiv.style.cssText = `
        background-color: #fee;
        color: #c33;
        padding: 15px;
        border-radius: 8px;
        margin: 20px;
        text-align: center;
        border: 1px solid #fcc;
    `;
    errorDiv.textContent = message;

    const container = document.querySelector('.dashboard-content') || document.body;
    container.insertBefore(errorDiv, container.firstChild);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (errorDiv.parentNode) {
            errorDiv.remove();
        }
    }, 5000);
}

// Function to update stats
function updateStats(data) {
    const statsElements = {
        activeEvents: document.getElementById('active-events'),
        totalRegistrants: document.getElementById('total-registrants'),
        completedEvents: document.getElementById('completed-events'),
        newRegistrations: document.getElementById('new-registrations')
    };
    
    // Update the stats with the provided data
    for (const [key, element] of Object.entries(statsElements)) {
        if (element && data[key] !== undefined) {
            // Create a counting animation
            const target = data[key];
            const duration = 1500; // 1.5 seconds
            const startTime = performance.now();
            const startValue = 0;
            
            function updateCounter(currentTime) {
                const elapsedTime = currentTime - startTime;
                const progress = Math.min(elapsedTime / duration, 1);
                
                // Use easeOutQuad for smoother animation
                const easeProgress = 1 - (1 - progress) * (1 - progress);
                const currentValue = Math.floor(startValue + (target - startValue) * easeProgress);
                
                element.textContent = currentValue;
                
                if (progress < 1) {
                    requestAnimationFrame(updateCounter);
                }
            }
            
            requestAnimationFrame(updateCounter);
        }
    }
}