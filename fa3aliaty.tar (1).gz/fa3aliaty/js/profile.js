// Profile page functionality

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    if (!isLoggedIn) {
        // Redirect to login page if not logged in
        window.location.href = 'login.html';
        return;
    }
    
    // Load user profile data
    // In a real application, this would come from an API
    const profileData = {
        name: 'أحمد محمد',
        email: 'ahmed.mohammed@example.com',
        phone: '+966 55 123 4567',
        bio: 'مطور ويب ومنظم فعاليات',
        avatar: 'images/user-avatar.jpg'
    };
    
    // Populate profile data
    const profileNameElements = document.querySelectorAll('.profile-name');
    const profileEmailElements = document.querySelectorAll('.profile-email');
    const profilePhoneElements = document.querySelectorAll('.profile-phone');
    const profileBioElements = document.querySelectorAll('.profile-bio');
    const profileAvatarElements = document.querySelectorAll('.profile-avatar');
    
    profileNameElements.forEach(element => {
        element.textContent = profileData.name;
    });
    
    profileEmailElements.forEach(element => {
        element.textContent = profileData.email;
    });
    
    profilePhoneElements.forEach(element => {
        element.textContent = profileData.phone;
    });
    
    profileBioElements.forEach(element => {
        element.textContent = profileData.bio;
    });
    
    profileAvatarElements.forEach(element => {
        element.src = profileData.avatar;
    });
    
    // Edit profile form
    const editProfileForm = document.getElementById('edit-profile-form');
    
    if (editProfileForm) {
        // Populate form with profile data
        editProfileForm.querySelector('#name').value = profileData.name;
        editProfileForm.querySelector('#email').value = profileData.email;
        editProfileForm.querySelector('#phone').value = profileData.phone;
        editProfileForm.querySelector('#bio').value = profileData.bio;
        
        // Handle form submission
        editProfileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = editProfileForm.querySelector('#name').value;
            const email = editProfileForm.querySelector('#email').value;
            const phone = editProfileForm.querySelector('#phone').value;
            const bio = editProfileForm.querySelector('#bio').value;
            
            // Update profile data (in a real app, this would be sent to an API)
            const updatedProfile = {
                ...profileData,
                name,
                email,
                phone,
                bio
            };
            
            // Show loading state
            const submitButton = editProfileForm.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'جاري الحفظ...';
            
            // Simulate API call
            setTimeout(() => {
                // Update UI with new data
                profileNameElements.forEach(element => {
                    element.textContent = updatedProfile.name;
                });
                
                profileEmailElements.forEach(element => {
                    element.textContent = updatedProfile.email;
                });
                
                profilePhoneElements.forEach(element => {
                    element.textContent = updatedProfile.phone;
                });
                
                profileBioElements.forEach(element => {
                    element.textContent = updatedProfile.bio;
                });
                
                // Show success message
                submitButton.textContent = 'تم الحفظ بنجاح';
                
                // Reset button after a delay
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = 'حفظ التغييرات';
                    
                    // Close modal if it exists
                    const modal = document.querySelector('.profile-edit-modal');
                    if (modal) {
                        modal.style.display = 'none';
                    }
                }, 1500);
            }, 1500);
        });
    }
    
    // Change password form
    const changePasswordForm = document.getElementById('change-password-form');
    
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const currentPassword = changePasswordForm.querySelector('#current-password').value;
            const newPassword = changePasswordForm.querySelector('#new-password').value;
            const confirmPassword = changePasswordForm.querySelector('#confirm-password').value;
            
            // Validate passwords
            const errorElement = changePasswordForm.querySelector('.form-error');
            
            if (newPassword.length < 8) {
                errorElement.textContent = 'يجب أن تتكون كلمة المرور الجديدة من 8 أحرف على الأقل';
                return;
            }
            
            if (newPassword !== confirmPassword) {
                errorElement.textContent = 'كلمات المرور غير متطابقة';
                return;
            }
            
            // Clear previous errors
            errorElement.textContent = '';
            
            // Show loading state
            const submitButton = changePasswordForm.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'جاري التغيير...';
            
            // Simulate API call
            setTimeout(() => {
                // Show success message
                submitButton.textContent = 'تم تغيير كلمة المرور بنجاح';
                
                // Reset form
                changePasswordForm.reset();
                
                // Reset button after a delay
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = 'تغيير كلمة المرور';
                    
                    // Close modal if it exists
                    const modal = document.querySelector('.password-modal');
                    if (modal) {
                        modal.style.display = 'none';
                    }
                }, 1500);
            }, 1500);
        });
    }
    
    // Toggle password visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    
    if (togglePasswordButtons) {
        togglePasswordButtons.forEach(button => {
            button.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                
                // Toggle icon
                const icon = this.querySelector('i');
                if (type === 'text') {
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    }
});