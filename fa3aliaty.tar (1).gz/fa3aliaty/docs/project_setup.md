# إعداد مشروع فعالياتي بإستخدام Next.js و Tailwind CSS

هذا الدليل يوضح كيفية إعداد وبدء مشروع فعالياتي باستخدام التقنيات الموصى بها.

## متطلبات النظام

- Node.js (الإصدار 14.0.0 أو أحدث)
- npm (الإصدار 7.0.0 أو أحدث) أو yarn
- Git

## الخطوة 1: إنشاء مشروع Next.js

```bash
npx create-next-app@latest feaalyati --typescript
cd feaalyati
```

## الخطوة 2: إضافة Tailwind CSS

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### تكوين Tailwind CSS

قم بتحديث ملف `tailwind.config.js`:

```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#8B5FBF',
          light: '#A67AC7',
          dark: '#704899',
        },
        secondary: {
          DEFAULT: '#E91E63',
          light: '#F48FB1',
          dark: '#C2185B',
        },
        accent: {
          DEFAULT: '#FF9800',
          light: '#FFB74D',
          dark: '#F57C00',
        },
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
```

### إضافة Cairo Font

قم بتحديث ملف `globals.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap');

@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --foreground-rgb: 0, 0, 0;
  --background-rgb: 248, 249, 250;
}

body {
  color: rgb(var(--foreground-rgb));
  background: rgb(var(--background-rgb));
  font-family: 'Cairo', sans-serif;
}

/* RTL Specific Styles */
html {
  direction: rtl;
}
```

## الخطوة 3: إعداد الملفات والدليل

قم بإنشاء هيكل ملفات المشروع:

```bash
mkdir -p src/components/ui
mkdir -p src/components/layouts
mkdir -p src/components/forms
mkdir -p src/components/events
mkdir -p src/hooks
mkdir -p src/utils
mkdir -p src/store
mkdir -p src/pages/api
mkdir -p public/images
```

## الخطوة 4: تثبيت حزم إضافية

```bash
# مكتبات أساسية
npm install zustand axios react-hook-form zod @hookform/resolvers dayjs
feaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md                  # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configurationfeaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md             feaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md             feaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md             feaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md            feaalyati/
├── backend/                      # Node.js + Express + MySQL backend
│   ├── config/                   # Configuration files
│   │   ├── database.js           # Database connection configuration
│   │   ├── auth.js               # Authentication configuration (JWT)
│   │   └── email.js              # Email service configuration
│   │
│   ├── controllers/              # Business logic
│   │   ├── authController.js     # Authentication logic
│   │   ├── userController.js     # User management
│   │   ├── eventController.js    # Event CRUD operations
│   │   ├── registrationController.js # Registration handling
│   │   ├── dashboardController.js # Dashboard data
│   │   ├── categoryController.js  # Event categories
│   │   └── venueController.js     # Venue management
│   │
│   ├── middleware/               # Express middleware
│   │   ├── auth.js               # JWT verification
│   │   ├── validation.js         # Request validation
│   │   ├── upload.js             # File upload handling
│   │   └── errorHandler.js       # Global error handling
│   │
│   ├── models/                   # Database models
│   │   ├── User.js               # User model
│   │   ├── Event.js              # Event model
│   │   ├── Registration.js       # Registration model
│   │   ├── Category.js           # Category model
│   │   ├── Venue.js              # Venue model
│   │   └── Notification.js       # Notification model
│   │
│   ├── routes/                   # API routes
│   │   ├── auth.js               # Authentication routes
│   │   ├── users.js              # User routes
│   │   ├── events.js             # Event routes
│   │   ├── registrations.js      # Registration routes
│   │   ├── dashboard.js          # Dashboard routes
│   │   ├── categories.js         # Category routes
│   │   └── venues.js             # Venue routes
│   │
│   ├── services/                 # External services
│   │   ├── emailService.js       # Email sending service
│   │   ├── storageService.js     # File storage service
│   │   └── paymentService.js     # Payment processing (if needed)
│   │
│   ├── utils/                    # Utility functions
│   │   ├── validators.js         # Input validation helpers
│   │   ├── formatters.js         # Data formatting helpers
│   │   └── logger.js             # Logging utility
│   │
│   ├── database/                 # Database scripts
│   │   ├── schema.sql            # Database schema
│   │   ├── migrations/           # Database migrations
│   │   └── seeds/                # Seed data
│   │
│   ├── uploads/                  # File upload directory
│   │   ├── events/               # Event images
│   │   └── users/                # User profile images
│   │
│   ├── .env                      # Environment variables
│   ├── .env.example              # Example environment variables
│   ├── package.json              # Node.js dependencies
│   └── server.js                 # Entry point
│
├── frontend/                     # Next.js frontend
│   ├── public/                   # Static files
│   │   ├── images/               # Static images
│   │   ├── fonts/                # Font files
│   │   └── locales/              # Translation files
│   │
│   ├── src/                      # Source code
│   │   ├── app/                  # Next.js App Router
│   │   │   ├── (auth)/           # Authentication routes
│   │   │   │   ├── login/        # Login page
│   │   │   │   └── register/     # Registration page
│   │   │   ├── dashboard/        # Dashboard pages
│   │   │   ├── events/           # Event pages
│   │   │   ├── profile/          # User profile
│   │   │   └── layout.tsx        # Root layout
│   │   │
│   │   ├── components/           # React components
│   │   │   ├── ui/               # UI components
│   │   │   ├── forms/            # Form components
│   │   │   ├── events/           # Event-related components
│   │   │   ├── dashboard/        # Dashboard components
│   │   │   └── layouts/          # Layout components
│   │   │
│   │   ├── hooks/                # Custom React hooks
│   │   │   ├── useAuth.ts        # Authentication hook
│   │   │   ├── useEvents.ts      # Events data hook
│   │   │   └── useForm.ts        # Form handling hook
│   │   │
│   │   ├── lib/                  # Library code
│   │   │   ├── api.ts            # API client
│   │   │   ├── validation.ts     # Form validation
│   │   │   └── utils.ts          # Utility functions
│   │   │
│   │   ├── store/                # State management
│   │   │   ├── authStore.ts      # Authentication state
│   │   │   ├── eventStore.ts     # Events state
│   │   │   └── uiStore.ts        # UI state
│   │   │
│   │   └── types/                # TypeScript type definitions
│   │       ├── user.ts           # User types
│   │       ├── event.ts          # Event types
│   │       └── api.ts            # API response types
│   │
│   ├── .env.local                # Environment variables
│   ├── next.config.js            # Next.js configuration
│   ├── tailwind.config.js        # Tailwind CSS configuration
│   ├── tsconfig.json             # TypeScript configuration
│   └── package.json              # Frontend dependencies
│
├── docs/                         # Documentation
│   ├── api/                      # API documentation
│   ├── setup.md                  # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configuration      # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configuration     # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configuration     # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configuration     # Setup instructions
│   ├── deployment.md             # Deployment guide
│   └── ui_guidelines.md          # UI guidelines
│
├── scripts/                      # Utility scripts
│   ├── setup.sh                  # Setup script
│   └── deploy.sh                 # Deployment script
│
├── .gitignore                    # Git ignore file
├── README.md                     # Project overview
└── docker-compose.yml            # Docker configuration
# مكونات UI
npm install @headlessui/react @radix-ui/react-dialog class-variance-authority clsx

# أدوات مساعدة
npm install react-icons

# أدوات تطوير
npm install -D eslint-plugin-tailwindcss prettier eslint-config-prettier
```

## الخطوة 5: إعداد ESLint و Prettier

قم بإنشاء ملف `.prettierrc`:

```json
{
  "semi": true,
  "tabWidth": 2,
  "printWidth": 100,
  "singleQuote": true,
  "trailingComma": "es5",
  "endOfLine": "auto"
}
```

قم بتحديث ملف `.eslintrc.json`:

```json
{
  "extends": ["next/core-web-vitals", "prettier"],
  "plugins": ["tailwindcss"],
  "rules": {
    "tailwindcss/no-custom-classname": "warn",
    "tailwindcss/enforces-shorthand": "warn"
  }
}
```

## الخطوة 6: إعداد Zustand لإدارة الحالة

قم بإنشاء ملف `src/store/useAuthStore.js`:

```javascript
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      login: (userData, token) => set({ 
        user: userData, 
        token, 
        isAuthenticated: true 
      }),
      logout: () => set({ 
        user: null, 
        token: null, 
        isAuthenticated: false 
      }),
      updateUser: (userData) => set((state) => ({ 
        user: { ...state.user, ...userData } 
      })),
    }),
    {
      name: 'auth-storage',
    }
  )
);

export default useAuthStore;
```

## الخطوة 7: إعداد مكون الإطار العام

قم بإنشاء ملف `src/components/layouts/MainLayout.jsx`:

```jsx
import { useRouter } from 'next/router';
import Head from 'next/head';
import Header from '../ui/Header';
import Footer from '../ui/Footer';

const MainLayout = ({ children, title = 'فعالياتي', description = 'منصة فعالياتي لإدارة الفعاليات' }) => {
  const router = useRouter();

  return (
    <>
      <Head>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">{children}</main>
        <Footer />
      </div>
    </>
  );
};

export default MainLayout;
```

## الخطوة 8: تكوين خاص بدعم اللغة العربية و RTL

قم بإنشاء ملف `src/utils/rtl.js`:

```javascript
import dayjs from 'dayjs';
import 'dayjs/locale/ar';

// تكوين dayjs للغة العربية
dayjs.locale('ar');

// دالة مساعدة لتحويل التنسيق من LTR إلى RTL
export const convertToRTLFormat = (format) => {
  return format.replace(/[A-Za-z]/g, (match) => {
    switch (match) {
      case 'Y': return 'س';
      case 'M': return 'ش';
      case 'D': return 'ي';
      // يمكن إضافة المزيد من التحويلات حسب الحاجة
      default: return match;
    }
  });
};

// مساعدة لتحديد اتجاه النص
export const getTextDirection = (text) => {
  const rtlChars = /[\u0591-\u07FF\u200F\u202B\u202E\uFB1D-\uFDFD\uFE70-\uFEFC]/;
  return rtlChars.test(text) ? 'rtl' : 'ltr';
};
```

## الخطوة 9: تكوين _app.js لدعم RTL

قم بتحديث ملف `src/pages/_app.js`:

```jsx
import '../styles/globals.css';
import { useEffect } from 'react';
import { useRouter } from 'next/router';

function MyApp({ Component, pageProps }) {
  const router = useRouter();
  
  useEffect(() => {
    // تعيين اتجاه الوثيقة للغة العربية
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
  }, []);

  // استخدام التخطيط المخصص للصفحة إذا كان متاحًا
  const getLayout = Component.getLayout || ((page) => page);

  return getLayout(<Component {...pageProps} />);
}

export default MyApp;
```

## الخطوة 10: البدء في التطوير

1. قم بتشغيل خادم التطوير:

```bash
npm run dev
```

2. افتح المتصفح على العنوان: `http://localhost:3000`

## توجيهات إضافية

### العمل مع النماذج

استخدم React Hook Form مع Zod للتحقق من صحة النماذج:

```jsx
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

// مخطط التحقق من صحة البيانات
const loginSchema = z.object({
  email: z.string().email('البريد الإلكتروني غير صالح'),
  password: z.string().min(8, 'كلمة المرور يجب أن تتكون من 8 أحرف على الأقل'),
});

// مكون النموذج
export default function LoginForm() {
  const { 
    register, 
    handleSubmit, 
    formState: { errors, isSubmitting } 
  } = useForm({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data) => {
    // إرسال البيانات إلى API
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="mb-4">
        <label htmlFor="email" className="block mb-2 font-medium">البريد الإلكتروني</label>
        <input
          id="email"
          type="email"
          {...register('email')}
          className={`w-full p-2 border rounded ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
        />
        {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email.message}</p>}
      </div>
      
      <div className="mb-4">
        <label htmlFor="password" className="block mb-2 font-medium">كلمة المرور</label>
        <input
          id="password"
          type="password"
          {...register('password')}
          className={`w-full p-2 border rounded ${errors.password ? 'border-red-500' : 'border-gray-300'}`}
        />
        {errors.password && <p className="mt-1 text-sm text-red-500">{errors.password.message}</p>}
      </div>
      
      <button 
        type="submit" 
        className="w-full py-2 text-white bg-primary rounded hover:bg-primary-dark"
        disabled={isSubmitting}
      >
        {isSubmitting ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
      </button>
    </form>
  );
}
```

### إدارة التاريخ والوقت

استخدم Day.js للتعامل مع التاريخ والوقت:

```javascript
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/ar';

// إضافة البرنامج المساعد للوقت النسبي
dayjs.extend(relativeTime);
// تعيين اللغة العربية
dayjs.locale('ar');

// أمثلة للاستخدام
const now = dayjs();
const eventDate = dayjs('2024-07-15');
const formattedDate = eventDate.format('D MMMM YYYY'); // 15 يوليو 2024
const timeFromNow = eventDate.fromNow(); // بعد شهرين
```

هذا يغطي الإعداد الأساسي للمشروع وكيفية البدء باستخدام الحزم الموصى بها. يمكن تطوير وتوسيع هذا الإعداد وفقًا لمتطلبات المشروع المحددة.