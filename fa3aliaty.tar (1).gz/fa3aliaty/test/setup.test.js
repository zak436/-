const request = require('supertest');
const app = require('../server');

describe('API Setup Tests', () => {
  test('Health check endpoint should work', async () => {
    const response = await request(app)
      .get('/api/health')
      .expect(200);

    expect(response.body).toHaveProperty('status', 'OK');
    expect(response.body).toHaveProperty('message', 'Feaalyati API is running');
  });

  test('Should return 404 for non-existent endpoints', async () => {
    const response = await request(app)
      .get('/api/non-existent')
      .expect(404);

    expect(response.body).toHaveProperty('error', 'API endpoint not found');
  });

  test('Should handle CORS properly', async () => {
    const response = await request(app)
      .options('/api/health')
      .expect(204);

    expect(response.headers).toHaveProperty('access-control-allow-origin');
  });
});

describe('Authentication Endpoints', () => {
  test('Should require email and password for login', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({})
      .expect(400);

    expect(response.body).toHaveProperty('error', 'Validation failed');
  });

  test('Should require valid email format', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'invalid-email',
        password: 'password123'
      })
      .expect(400);

    expect(response.body).toHaveProperty('error', 'Validation failed');
  });
});

describe('Events Endpoints', () => {
  test('Should get events without authentication', async () => {
    const response = await request(app)
      .get('/api/events')
      .expect(200);

    expect(response.body).toHaveProperty('events');
    expect(response.body).toHaveProperty('pagination');
  });

  test('Should get event categories', async () => {
    const response = await request(app)
      .get('/api/events/categories')
      .expect(200);

    expect(response.body).toHaveProperty('categories');
    expect(Array.isArray(response.body.categories)).toBe(true);
  });

  test('Should require authentication for creating events', async () => {
    const response = await request(app)
      .post('/api/events')
      .send({
        title_ar: 'فعالية تجريبية',
        description_ar: 'وصف الفعالية التجريبية',
        event_type: 'conference',
        start_date: '2024-12-01T10:00:00Z',
        end_date: '2024-12-01T18:00:00Z'
      })
      .expect(401);

    expect(response.body).toHaveProperty('error', 'Access token required');
  });
});
