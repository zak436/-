document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const registrationForm = document.getElementById('registration-form');
    const successMessage = document.getElementById('success-message');
    const ticketTypes = document.querySelectorAll('.ticket-type');
    const termsCheckbox = document.getElementById('terms');
    const submitButton = document.getElementById('submit-btn');
    
    // Initialize form validation state
    let isFormValid = false;
    
    // Add event listeners to ticket type options
    ticketTypes.forEach(ticket => {
        ticket.addEventListener('click', function() {
            // Remove selected class from all tickets
            ticketTypes.forEach(t => {
                t.classList.remove('selected');
                t.querySelector('input[type="radio"]').checked = false;
            });
            
            // Add selected class to clicked ticket
            this.classList.add('selected');
            this.querySelector('input[type="radio"]').checked = true;
            
            // Validate form
            validateForm();
        });
    });
    
    // Add event listener to terms checkbox
    termsCheckbox.addEventListener('change', validateForm);
    
    // Add event listeners to form inputs
    const formInputs = registrationForm.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"]');
    formInputs.forEach(input => {
        input.addEventListener('input', function() {
            // Remove error class if input has value
            if (this.value.trim() !== '') {
                this.classList.remove('error');
            }
            
            // Validate form
            validateForm();
        });
        
        input.addEventListener('blur', function() {
            // Add error class if input is empty
            if (this.value.trim() === '' && this.hasAttribute('required')) {
                this.classList.add('error');
            }
        });
    });
    
    // Form validation function
    function validateForm() {
        // Check if all required fields are filled
        let requiredFieldsFilled = true;
        formInputs.forEach(input => {
            if (input.hasAttribute('required') && input.value.trim() === '') {
                requiredFieldsFilled = false;
            }
        });
        
        // Check if a ticket type is selected
        const ticketSelected = document.querySelector('input[name="ticket_type"]:checked') !== null;
        
        // Check if terms are accepted
        const termsAccepted = termsCheckbox.checked;
        
        // Update form validity state
        isFormValid = requiredFieldsFilled && ticketSelected && termsAccepted;
        
        // Update submit button state
        submitButton.disabled = !isFormValid;
    }
    
    // Form submission
    registrationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!isFormValid) {
            return;
        }
        
        // Show success message
        registrationForm.classList.add('hidden');
        successMessage.classList.remove('hidden');
        
        // Scroll to success message
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
        
        // In a real application, you would submit the form data to a server here
        console.log('Form submitted successfully');
    });
});