const express = require('express');
const router = express.Router();
const EventController = require('../controllers/eventController');
const { authenticateToken, requireOrganizer, requireOwnership, optionalAuth } = require('../middleware/auth');
const { uploadEventImages, handleUploadError } = require('../utils/upload');
const {
  validateEventCreation,
  validateEventUpdate,
  validateId,
  validateEventQuery
} = require('../middleware/validation');

// Public routes
router.get('/', validateEventQuery, EventController.getMany);
router.get('/categories', EventController.getCategories);
router.get('/venues', EventController.getVenues);
router.get('/:id', validateId, optionalAuth, EventController.getById);

// Protected routes - require authentication
router.use(authenticateToken);
router.use(requireOrganizer);

// Organizer event management
router.get('/organizer/events', validateEventQuery, EventController.getOrganizerEvents);
router.get('/organizer/upcoming', EventController.getUpcomingEvents);

// Event CRUD operations
router.post('/', 
  uploadEventImages.array('images', 5), 
  handleUploadError,
  validateEventCreation, 
  EventController.create
);

router.put('/:id', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  uploadEventImages.array('images', 5),
  handleUploadError,
  validateEventUpdate, 
  EventController.update
);

router.delete('/:id', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.delete
);

// Event registrations management
router.get('/:id/registrations', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.getEventRegistrations
);

router.get('/:id/stats', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.getEventStats
);

router.put('/:id/registrations/:registrationId/status', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.updateRegistrationStatus
);

router.get('/:id/registrations/export', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.exportRegistrations
);

router.get('/:id/analytics', 
  validateId,
  requireOwnership('id', 'events', 'organizer_id'),
  EventController.getEventAnalytics
);

module.exports = router;
