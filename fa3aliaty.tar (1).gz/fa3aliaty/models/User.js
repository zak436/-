const { getOne, getMany, insert, update, remove } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

class User {
  // Create a new user
  static async create(userData) {
    const {
      email,
      password,
      first_name,
      last_name,
      phone,
      organization_name,
      organization_type = 'individual',
      bio,
      website
    } = userData;

    // Hash password
    const password_hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    
    // Generate email verification token
    const email_verification_token = uuidv4();

    const query = `
      INSERT INTO users (
        email, password_hash, first_name, last_name, phone, 
        organization_name, organization_type, bio, website, 
        email_verification_token
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const userId = await insert(query, [
      email,
      password_hash,
      first_name,
      last_name,
      phone,
      organization_name,
      organization_type,
      bio,
      website,
      email_verification_token
    ]);

    return { id: userId, email_verification_token };
  }

  // Find user by email
  static async findByEmail(email) {
    const query = `
      SELECT id, email, password_hash, first_name, last_name, phone,
             organization_name, organization_type, profile_image, bio, 
             website, social_media, email_verified, status, created_at
      FROM users 
      WHERE email = ?
    `;
    return await getOne(query, [email]);
  }

  // Find user by ID
  static async findById(id) {
    const query = `
      SELECT id, email, first_name, last_name, phone,
             organization_name, organization_type, profile_image, bio, 
             website, social_media, email_verified, status, created_at, updated_at
      FROM users 
      WHERE id = ? AND status = 'active'
    `;
    return await getOne(query, [id]);
  }

  // Verify password
  static async verifyPassword(plainPassword, hashedPassword) {
    return await bcrypt.compare(plainPassword, hashedPassword);
  }

  // Update user profile
  static async updateProfile(userId, updateData) {
    const allowedFields = [
      'first_name', 'last_name', 'phone', 'organization_name', 
      'organization_type', 'bio', 'website', 'social_media'
    ];

    const updates = [];
    const values = [];

    Object.keys(updateData).forEach(key => {
      if (allowedFields.includes(key) && updateData[key] !== undefined) {
        updates.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });

    if (updates.length === 0) {
      throw new Error('No valid fields to update');
    }

    values.push(userId);

    const query = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    const affectedRows = await update(query, values);
    
    return affectedRows > 0;
  }

  // Update password
  static async updatePassword(userId, newPassword) {
    const password_hash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 12);
    
    const query = 'UPDATE users SET password_hash = ? WHERE id = ?';
    const affectedRows = await update(query, [password_hash, userId]);
    
    return affectedRows > 0;
  }

  // Verify email
  static async verifyEmail(token) {
    const query = `
      UPDATE users 
      SET email_verified = TRUE, email_verification_token = NULL 
      WHERE email_verification_token = ? AND email_verified = FALSE
    `;
    const affectedRows = await update(query, [token]);
    
    return affectedRows > 0;
  }

  // Set password reset token
  static async setPasswordResetToken(email) {
    const token = uuidv4();
    const expires = new Date(Date.now() + 3600000); // 1 hour from now

    const query = `
      UPDATE users 
      SET password_reset_token = ?, password_reset_expires = ? 
      WHERE email = ? AND status = 'active'
    `;
    const affectedRows = await update(query, [token, expires, email]);
    
    if (affectedRows > 0) {
      return token;
    }
    return null;
  }

  // Reset password with token
  static async resetPassword(token, newPassword) {
    // First check if token is valid and not expired
    const user = await getOne(
      'SELECT id FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW()',
      [token]
    );

    if (!user) {
      return false;
    }

    // Hash new password
    const password_hash = await bcrypt.hash(newPassword, parseInt(process.env.BCRYPT_ROUNDS) || 12);

    // Update password and clear reset token
    const query = `
      UPDATE users 
      SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL 
      WHERE id = ?
    `;
    const affectedRows = await update(query, [password_hash, user.id]);
    
    return affectedRows > 0;
  }

  // Get user statistics
  static async getStats(userId) {
    const stats = await getOne(`
      SELECT 
        COUNT(e.id) as total_events,
        COUNT(CASE WHEN e.status = 'published' THEN 1 END) as published_events,
        COUNT(CASE WHEN e.status = 'draft' THEN 1 END) as draft_events,
        COALESCE(SUM(e.registration_count), 0) as total_registrations,
        COALESCE(SUM(e.views_count), 0) as total_views
      FROM events e 
      WHERE e.organizer_id = ?
    `, [userId]);

    return stats || {
      total_events: 0,
      published_events: 0,
      draft_events: 0,
      total_registrations: 0,
      total_views: 0
    };
  }

  // Update profile image
  static async updateProfileImage(userId, imagePath) {
    const query = 'UPDATE users SET profile_image = ? WHERE id = ?';
    const affectedRows = await update(query, [imagePath, userId]);
    
    return affectedRows > 0;
  }

  // Deactivate user account
  static async deactivate(userId) {
    const query = 'UPDATE users SET status = "inactive" WHERE id = ?';
    const affectedRows = await update(query, [userId]);
    
    return affectedRows > 0;
  }

  // Check if email exists
  static async emailExists(email, excludeUserId = null) {
    let query = 'SELECT id FROM users WHERE email = ?';
    let params = [email];

    if (excludeUserId) {
      query += ' AND id != ?';
      params.push(excludeUserId);
    }

    const user = await getOne(query, params);
    return !!user;
  }
}

module.exports = User;
