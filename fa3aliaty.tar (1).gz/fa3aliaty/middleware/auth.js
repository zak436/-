const { verifyToken, extractToken } = require('../config/auth');
const { getOne } = require('../config/database');

// Middleware to authenticate JWT token
async function authenticateToken(req, res, next) {
  try {
    const token = extractToken(req);
    
    if (!token) {
      return res.status(401).json({
        error: 'Access token required',
        message_ar: 'رمز الوصول مطلوب'
      });
    }

    // Verify the token
    const decoded = verifyToken(token);
    
    // Get user from database to ensure they still exist and are active
    const user = await getOne(
      'SELECT id, email, first_name, last_name, organization_name, status FROM users WHERE id = ? AND status = "active"',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({
        error: 'Invalid token or user not found',
        message_ar: 'رمز غير صالح أو المستخدم غير موجود'
      });
    }

    // Add user info to request object
    req.user = user;
    req.userId = user.id;
    
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    
    if (error.message === 'Invalid or expired token') {
      return res.status(401).json({
        error: 'Invalid or expired token',
        message_ar: 'رمز غير صالح أو منتهي الصلاحية'
      });
    }
    
    return res.status(500).json({
      error: 'Authentication failed',
      message_ar: 'فشل في التحقق من الهوية'
    });
  }
}

// Middleware to check if user is organizer (optional since all users are organizers)
async function requireOrganizer(req, res, next) {
  try {
    // Since all users in the system are organizers, just check if authenticated
    if (!req.user) {
      return res.status(401).json({
        error: 'Organizer access required',
        message_ar: 'مطلوب صلاحية منظم'
      });
    }
    
    next();
  } catch (error) {
    console.error('Organizer check error:', error);
    return res.status(500).json({
      error: 'Authorization check failed',
      message_ar: 'فشل في التحقق من الصلاحية'
    });
  }
}

// Middleware to check if user owns the resource
function requireOwnership(resourceIdParam = 'id', resourceTable = 'events', ownerColumn = 'organizer_id') {
  return async (req, res, next) => {
    try {
      const resourceId = req.params[resourceIdParam];
      const userId = req.userId;
      
      if (!resourceId) {
        return res.status(400).json({
          error: 'Resource ID required',
          message_ar: 'معرف المورد مطلوب'
        });
      }
      
      // Check if user owns the resource
      const resource = await getOne(
        `SELECT ${ownerColumn} FROM ${resourceTable} WHERE id = ?`,
        [resourceId]
      );
      
      if (!resource) {
        return res.status(404).json({
          error: 'Resource not found',
          message_ar: 'المورد غير موجود'
        });
      }
      
      if (resource[ownerColumn] !== userId) {
        return res.status(403).json({
          error: 'Access denied - you do not own this resource',
          message_ar: 'الوصول مرفوض - لا تملك هذا المورد'
        });
      }
      
      next();
    } catch (error) {
      console.error('Ownership check error:', error);
      return res.status(500).json({
        error: 'Ownership check failed',
        message_ar: 'فشل في التحقق من الملكية'
      });
    }
  };
}

// Optional authentication (for public endpoints that can benefit from user context)
async function optionalAuth(req, res, next) {
  try {
    const token = extractToken(req);
    
    if (token) {
      try {
        const decoded = verifyToken(token);
        const user = await getOne(
          'SELECT id, email, first_name, last_name, organization_name, status FROM users WHERE id = ? AND status = "active"',
          [decoded.userId]
        );
        
        if (user) {
          req.user = user;
          req.userId = user.id;
        }
      } catch (error) {
        // Ignore token errors for optional auth
        console.log('Optional auth token error (ignored):', error.message);
      }
    }
    
    next();
  } catch (error) {
    // For optional auth, we continue even if there's an error
    console.error('Optional auth error (ignored):', error);
    next();
  }
}

module.exports = {
  authenticateToken,
  requireOrganizer,
  requireOwnership,
  optionalAuth
};
