const express = require('express');
const router = express.Router();
const RegistrationController = require('../controllers/registrationController');
const { authenticateToken, requireOrganizer } = require('../middleware/auth');
const {
  validateEventRegistration,
  validateId
} = require('../middleware/validation');

// Public routes
router.post('/events/:id/register', validateId, validateEventRegistration, RegistrationController.register);
router.get('/token/:token', RegistrationController.getByToken);
router.get('/confirm/:token', RegistrationController.confirm);
router.get('/email/:email', RegistrationController.getByEmail);

// Registration management
router.get('/:id', validateId, RegistrationController.getRegistration);
router.put('/:id/cancel', validateId, RegistrationController.cancel);
router.put('/:id/payment-status', validateId, RegistrationController.updatePaymentStatus);

// Protected routes - for organizers
router.use(authenticateToken);
router.use(requireOrganizer);

// Bulk operations for organizers
router.put('/bulk/check-in', RegistrationController.bulkCheckIn);

module.exports = router;
